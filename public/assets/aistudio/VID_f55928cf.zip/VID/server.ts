import express, { Request, Response } from "express";
import path from "path";
import { fileURLToPath } from "url";
import { spawn } from "child_process";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import * as cheerio from "cheerio";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

app.use(express.json({ limit: "15mb" }));

// Server-side Gemini client
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
};

// API: Distraction-free Web Novel & Article Scraper / Reader Mode with Cloudflare Detection
app.post("/api/novel/scrape", async (req: Request, res: Response) => {
  try {
    const { url, cookies, userAgent } = req.body;
    if (!url || typeof url !== "string") {
      res.status(400).json({ error: "A valid URL string is required" });
      return;
    }

    let parsedUrl: URL;
    try {
      parsedUrl = new URL(url);
    } catch {
      res.status(400).json({ error: "Invalid URL format" });
      return;
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 14000);

    const requestHeaders: Record<string, string> = {
      "User-Agent":
        userAgent ||
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
      Accept:
        "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
      "Accept-Language": "en-US,en;q=0.9",
      "Cache-Control": "no-cache",
      "Sec-Ch-Ua": '"Not-A.Brand";v="99", "Chromium";v="124"',
      "Sec-Ch-Ua-Mobile": "?1",
      "Sec-Ch-Ua-Platform": '"Android"',
      "Sec-Fetch-Dest": "document",
      "Sec-Fetch-Mode": "navigate",
      "Sec-Fetch-Site": "none",
      "Sec-Fetch-User": "?1",
      "Upgrade-Insecure-Requests": "1",
    };

    if (cookies && typeof cookies === "string") {
      requestHeaders["Cookie"] = cookies;
    }

    let fetchResponse: any;
    try {
      fetchResponse = await fetch(parsedUrl.toString(), {
        signal: controller.signal,
        headers: requestHeaders,
      });
    } catch (fetchErr: any) {
      clearTimeout(timeout);
      res.status(502).json({
        error: `Could not connect to ${parsedUrl.hostname}: ${fetchErr?.message || "Connection failed"}`,
        isConnectionError: true,
      });
      return;
    }
    clearTimeout(timeout);

    const html = await fetchResponse.text();

    // Comprehensive Cloudflare DDoS and Turnstile captcha detection
    const isCloudflare =
      fetchResponse.status === 403 ||
      fetchResponse.status === 503 ||
      html.includes("challenges.cloudflare.com") ||
      html.includes("cf-turnstile") ||
      html.includes("cf-browser-verification") ||
      html.includes("Checking your browser before accessing") ||
      html.includes("<title>Just a moment...</title>") ||
      html.includes("Attention Required! | Cloudflare") ||
      html.includes("Enable JavaScript and cookies to continue");

    if (isCloudflare) {
      res.status(403).json({
        error: "Cloudflare protection challenge detected",
        isCloudflare: true,
        siteName: parsedUrl.hostname.replace(/^www\./, ""),
        url: parsedUrl.toString(),
        message:
          "This novel site is protected by Cloudflare. Solve the captcha verification in WebView to continue.",
      });
      return;
    }

    if (!fetchResponse.ok) {
      res.status(fetchResponse.status).json({
        error: `Failed to fetch website (HTTP ${fetchResponse.status}: ${fetchResponse.statusText})`,
      });
      return;
    }
    const $ = cheerio.load(html);

    // Remove noise, banners, scripts, ads, social bars
    $(
      "script, style, noscript, iframe, link, svg, nav, footer, header, aside, " +
        ".ad, .ads, .advertisement, .ad-container, .google-auto-placed, .sidebar, " +
        ".social-share, .cookie-banner, .cookie-notice, .comments, #comments, " +
        ".disqus, .newsletter, .popup, .modal, .menu, .nav-bar, .top-bar"
    ).remove();

    // Extract Title
    let title =
      $('meta[property="og:title"]').attr("content") ||
      $('meta[name="twitter:title"]').attr("content") ||
      $("h1").first().text().trim() ||
      $("title").text().trim() ||
      "Untitled Chapter";

    // Clean title suffixes like " - Read Online Free", " | Royal Road", etc.
    title = title
      .replace(/\s*[-|–—:]\s*(Read Online|Novel Updates|Royal Road|WuxiaWorld|Light Novel Pub|ReadNovelFull).*$/i, "")
      .trim();

    // Extract Author
    const author =
      $('meta[name="author"]').attr("content") ||
      $('meta[property="article:author"]').attr("content") ||
      $('.author, .byline, [rel="author"]').first().text().trim() ||
      "Unknown Author";

    // Identify primary content container with novel selectors or highest paragraph score
    const candidateSelectors = [
      ".chapter-content",
      ".entry-content",
      ".chapter-inner",
      ".text-content",
      ".reading-content",
      ".read-content",
      "#chapter-content",
      "#content",
      ".post-content",
      "article",
      "main",
    ];

    let bestContainer: cheerio.Cheerio<any> | null = null;
    let maxParagraphs = 0;

    for (const selector of candidateSelectors) {
      const match = $(selector);
      if (match.length > 0) {
        const pCount = match.find("p").length;
        if (pCount > maxParagraphs) {
          maxParagraphs = pCount;
          bestContainer = match.first();
        }
      }
    }

    // Fallback: evaluate all div and section elements
    if (!bestContainer || maxParagraphs < 2) {
      $("div, section").each((_, elem) => {
        const pCount = $(elem).children("p").length;
        if (pCount > maxParagraphs) {
          maxParagraphs = pCount;
          bestContainer = $(elem);
        }
      });
    }

    let cleanedHtml = "";
    let cleanText = "";

    if (bestContainer && bestContainer.length > 0) {
      // Clean up internal wrappers
      bestContainer.find("script, style, iframe, button, input").remove();
      bestContainer.find("a").each((_, a) => {
        // Strip spam link anchors but keep inner text
        $(a).replaceWith($(a).text());
      });

      // Extract cleaned paragraphs
      const paragraphs: string[] = [];
      bestContainer.find("p, h2, h3, h4, blockquote").each((_, el) => {
        const node = $(el);
        const text = node.text().trim();
        // Ignore very short watermark/ad lines
        if (
          text.length > 5 &&
          !/please read this novel at|find the original on|all rights reserved/i.test(
            text
          )
        ) {
          const tagName = el.tagName.toLowerCase();
          if (tagName.startsWith("h")) {
            paragraphs.push(`<h3>${text}</h3>`);
          } else if (tagName === "blockquote") {
            paragraphs.push(`<blockquote>${text}</blockquote>`);
          } else {
            paragraphs.push(`<p>${text}</p>`);
          }
        }
      });

      cleanedHtml = paragraphs.join("\n");
      cleanText = bestContainer.text().replace(/\s+/g, " ").trim();
    }

    // Secondary fallback if container detection was sparse
    if (!cleanedHtml || cleanText.length < 50) {
      const bodyParagraphs: string[] = [];
      $("p").each((_, p) => {
        const text = $(p).text().trim();
        if (text.length > 30) {
          bodyParagraphs.push(`<p>${text}</p>`);
        }
      });
      cleanedHtml = bodyParagraphs.join("\n");
      cleanText = $("p")
        .map((_, p) => $(p).text().trim())
        .get()
        .join("\n\n");
    }

    const words = cleanText.split(/\s+/).filter(Boolean);
    const wordCount = words.length;
    const readingTimeMin = Math.max(1, Math.ceil(wordCount / 220));

    res.json({
      title,
      author,
      siteName: parsedUrl.hostname.replace(/^www\./, ""),
      url: parsedUrl.toString(),
      cleanedHtml,
      text: cleanText,
      wordCount,
      readingTimeMin,
      publishedDate: $('meta[property="article:published_time"]').attr("content") || null,
    });
  } catch (error: any) {
    console.error("Scraper error:", error);
    res.status(500).json({
      error: error?.message || "Failed to extract clean reader content",
    });
  }
});

// API: Smart AI Chapter & Article Summarizer (Gemini 3.8 Flash)
app.post("/api/novel/summarize", async (req: Request, res: Response) => {
  try {
    const { title, chapterTitle, text, type = "recap" } = req.body;
    if (!text || typeof text !== "string") {
      res.status(400).json({ error: "Text content is required for summarization" });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      // Graceful local summary generator if API key is not yet set
      const lines = text.split("\n").filter((l) => l.trim().length > 40);
      const excerpt = lines.slice(0, 3).join(" ");
      res.json({
        summary: `[Local Summary] In this chapter of ${title || "the novel"}, the narrative unfolds: ${excerpt.slice(0, 240)}...`,
        keyPoints: [
          `Opening sequence focuses on: "${lines[0]?.slice(0, 60) || "the setting"}"`,
          `Mid-chapter developments: ${lines[Math.floor(lines.length / 2)]?.slice(0, 60) || "Plot progression"}`,
          `Current cliffhanger / status: ${lines[lines.length - 1]?.slice(0, 60) || "Conclusion of section"}`,
        ],
        characters: ["Protagonist", "Supporting Cast"],
        takeaways: "Configure GEMINI_API_KEY in Settings > Secrets for deep narrative synthesis.",
      });
      return;
    }

    // Limit text sample for fast low-latency response
    const trimmedText = text.slice(0, 10000);

    const systemPrompt = `You are an expert light novel and literature reading assistant.
Your goal is to provide a compelling, accurate, and concise summary of the provided chapter or web article.
Do NOT reveal spoilers beyond this text.
Highlight:
1. "recap": A 2-3 sentence 'Previously On' style narrative recap of what happens in this chapter.
2. "keyPoints": 3 to 5 concise bullet points of pivotal events or lore developments.
3. "characters": Mention notable characters active in this chapter and their actions.
4. "mood": Emotional tone (e.g. Tense, Whimsical, Climactic, Cultivation Breakthrough, Mystery).

Format your response as valid JSON with keys: recap (string), keyPoints (array of strings), characters (array of strings), mood (string).`;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: `Novel: ${title || "Web Novel"}
Chapter: ${chapterTitle || "Current Chapter"}
Text:
${trimmedText}`,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        temperature: 0.7,
      },
    });

    const outputText = response.text || "{}";
    let parsedData: any = {};
    try {
      parsedData = JSON.parse(outputText);
    } catch {
      parsedData = { recap: outputText, keyPoints: [], characters: [], mood: "Engaging" };
    }

    res.json(parsedData);
  } catch (error: any) {
    console.error("Gemini summarizer error:", error);
    res.status(500).json({ error: error?.message || "AI Summarizer failed" });
  }
});

// API: Smart AI Lore, Character Tracker & Terminology
app.post("/api/novel/ai-lore", async (req: Request, res: Response) => {
  try {
    const { title, chapterTitle, text } = req.body;
    if (!text || typeof text !== "string") {
      res.status(400).json({ error: "Text content is required" });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      res.json({
        characters: [
          { name: "Protagonist", role: "Main Character", description: "Navigating current challenges", allegiance: "Neutral" }
        ],
        terms: [
          { term: "Qi / Mana", explanation: "Supernatural energy circulating in the world or body", category: "Cultivation / Magic" }
        ],
        cliffhangerGuess: "The protagonist prepares for the impending revelation."
      });
      return;
    }

    const trimmedText = text.slice(0, 10000);
    const systemPrompt = `You are an expert novel reading lore assistant.
Analyze the provided chapter and extract:
1. "characters": list of objects { "name", "role", "description", "allegiance" }
2. "terms": list of fantasy/cultivation/sci-fi terms or slang explained in plain language { "term", "explanation", "category" }
3. "cliffhangerGuess": a fun, engaging 1-sentence prediction of what might happen next.
Return strictly valid JSON.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: `Novel: ${title || "Novel"}\nChapter: ${chapterTitle || "Chapter"}\nText:\n${trimmedText}`,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
      },
    });

    const parsed = JSON.parse(response.text || "{}");
    res.json(parsed);
  } catch (error: any) {
    console.error("AI lore error:", error);
    res.status(500).json({ error: error?.message || "AI Lore failed" });
  }
});

// API: AI Term & Phrase Explainer
app.post("/api/novel/ai-explain", async (req: Request, res: Response) => {
  try {
    const { phrase, context } = req.body;
    if (!phrase) {
      res.status(400).json({ error: "Phrase is required" });
      return;
    }

    const ai = getGeminiClient();
    if (!ai) {
      res.json({
        explanation: `"${phrase}" represents a thematic element or term within the narrative context.`,
        category: "Literature",
      });
      return;
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: `Explain this term, idiom, or fantasy jargon clearly in 1-2 concise sentences for a reader:
Term: "${phrase}"
Context sentence: "${context || phrase}"`,
      config: {
        systemInstruction: "You are a concise reading dictionary and fantasy lore glossary assistant.",
      },
    });

    res.json({ explanation: response.text?.trim() || "No explanation available." });
  } catch (error: any) {
    console.error("AI explain error:", error);
    res.status(500).json({ error: error?.message || "Explanation failed" });
  }
});

// Digital Asset Links for Android App Links / TWA / Google Play verification
app.get("/.well-known/assetlinks.json", (_req: Request, res: Response) => {
  res.setHeader("Content-Type", "application/json");
  res.sendFile(path.join(__dirname, "public", ".well-known", "assetlinks.json"));
});

// Privacy Policy page required by Google Play Console and F-Droid
app.get("/privacy", (_req: Request, res: Response) => {
  res.sendFile(path.join(__dirname, "public", "privacy.html"));
});

// Direct Android APK Download endpoint
app.get(["/aethernovel.apk", "/download/aethernovel.apk"], (_req: Request, res: Response) => {
  const apkPath = path.join(__dirname, "public", "aethernovel.apk");
  res.setHeader("Content-Type", "application/vnd.android.package-archive");
  res.setHeader("Content-Disposition", 'attachment; filename="AetherNovel.apk"');
  res.sendFile(apkPath);
});

// Serve Generated Novel Site Provider APKs
app.use("/providers", express.static(path.join(__dirname, "public", "providers")));

// API: Generate Standalone Novel Site Provider APK
app.post("/api/provider/build-apk", async (req: Request, res: Response) => {
  try {
    const { siteName, siteUrl, selector, icon } = req.body;
    if (!siteName || !siteUrl) {
      res.status(400).json({ error: "Site name and URL are required" });
      return;
    }

    const pythonBin = "C:\\Users\\admin 3\\AppData\\Local\\Programs\\Python\\Python313\\python.exe";
    const scriptPath = path.join(__dirname, "android-build", "build_provider_apk.py");

    const proc = spawn(pythonBin, [
      scriptPath,
      siteName,
      siteUrl,
      selector || ".chapter-content",
      icon || "📖",
    ]);

    let stdout = "";
    let stderr = "";

    proc.stdout.on("data", (data) => {
      stdout += data.toString();
    });

    proc.stderr.on("data", (data) => {
      stderr += data.toString();
    });

    proc.on("close", (code) => {
      if (code !== 0) {
        console.error("Provider APK generation failed:", stderr);
        res.status(500).json({
          error: `APK generation failed with exit code ${code}: ${stderr || stdout}`,
        });
        return;
      }

      try {
        const jsonMatch = stdout.trim().match(/\{[\s\S]*\}$/);
        const result = jsonMatch ? JSON.parse(jsonMatch[0]) : { success: true };
        res.json(result);
      } catch (err) {
        res.status(500).json({ error: "Failed to parse APK builder output", raw: stdout });
      }
    });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || "Internal build error" });
  }
});

// Start server and mount Vite
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[AetherNovel] Server listening on port ${PORT}`);
  });
}

startServer();
