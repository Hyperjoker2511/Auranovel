export type NovelSourceType = 'epub' | 'extension' | 'web';

export type ReadingStatus = 'reading' | 'completed' | 'plan_to_read' | 'on_hold';

export interface ChapterMeta {
  id: string;
  novelId: string;
  index: number;
  title: string;
  href?: string;
  url?: string;
  isDownloaded?: boolean;
  wordCount?: number;
  releaseDate?: string;
}

export interface ChapterContent {
  id: string;
  novelId: string;
  index: number;
  title: string;
  contentHtml: string;
  text: string;
  wordCount: number;
  cachedAt: number;
}

export interface NovelReview {
  id: string;
  author: string;
  avatarUrl?: string;
  rating: number;
  date: string;
  content: string;
  likes?: number;
  source?: string;
  aspectRatings?: {
    story?: number;
    characters?: number;
    worldBuilding?: number;
    writingStyle?: number;
  };
}

export interface Novel {
  id: string;
  title: string;
  author: string;
  coverUrl?: string;
  description: string;
  genres: string[];
  sourceType: NovelSourceType;
  sourceName: string;
  sourceUrl?: string;
  status: ReadingStatus;
  currentChapterIndex: number;
  currentProgressPercent: number; // 0 to 100
  currentParagraphIndex?: number; // Exact paragraph where the user left off
  totalChapters: number;
  chapters: ChapterMeta[];
  lastReadAt: number;
  createdAt: number;
  rating?: number;
  ratingCount?: number;
  reviews?: NovelReview[];
  isFavorite?: boolean;
  tags?: string[];
  originalFileBlobKey?: string; // For EPUB files stored in IndexedDB
}

export interface ExtensionSource {
  id: string;
  name: string;
  version: string;
  icon: string;
  description: string;
  language: string;
  enabled: boolean;
  isCommunity: boolean;
  tags: string[];
  novels: Novel[];
  repoUrl?: string;
  author?: string;
  websiteUrl?: string;
}

export type ReaderTheme = 
  | 'liquid-glass'
  | 'oled' 
  | 'dark' 
  | 'midnight' 
  | 'nordic'
  | 'cyberpunk'
  | 'crimson-void'
  | 'mocha' 
  | 'rose'
  | 'sepia' 
  | 'parchment' 
  | 'matcha'
  | 'light';

export type ReaderFont = 
  | 'Inter' 
  | 'Literata' 
  | 'Lora' 
  | 'Merriweather' 
  | 'JetBrains Mono' 
  | 'Cinzel'
  | 'system-ui'
  | 'Atkinson';

export type AccentColor = 'amber' | 'emerald' | 'cyan' | 'violet' | 'rose' | 'orange' | 'neon-pink' | 'lime-gold';

export interface ReaderSettings {
  theme: ReaderTheme;
  accentColor: AccentColor;
  appWideTheme?: boolean; // Apply theme & glass across the whole app shell
  glassBlurIntensity?: 'low' | 'medium' | 'high'; // Frost blur strength for liquid-glass
  ambientAura?: boolean; // Glowing radial aura orbs for liquid-glass & dark themes
  fontFamily: ReaderFont;
  fontSize: number; // in px: 13 to 38
  fontWeight: 'light' | 'normal' | 'medium' | 'bold';
  lineHeight: number; // 1.2 to 2.6
  letterSpacing: number; // -0.5 to 3
  maxWidth: number; // in px: 600 to 1400 or 0 for full
  textAlign: 'left' | 'justify' | 'center';
  paragraphSpacing: number; // 0.6 to 2.5
  indentParagraphs: boolean;
  dropCaps: boolean;
  readingMode: 'paginated' | 'scroll';
  pageTransition: 'slide' | 'fade' | 'instant' | 'curl';
  twoColumnTablet: boolean; // 2-page book spread on tablets/large screens
  readingRuler: boolean; // Translucent focus guide line following reading
  warmScreenTint: number; // 0 to 60 percentage warm candlelight amber filter
  soundEffects: boolean; // Synthetic paper rustle flip sound via Web Audio
  hapticFeedback: boolean; // Subtle mobile vibration on page flip/actions
  tapZoneMode: 'standard' | 'invert' | 'edges'; // Left/Right page tap zone orientation
  volumeKeyNavigation: boolean; // Use volume buttons to flip pages
  autoLoadNextChapter: boolean; // Seamlessly progress to next chapter at end of scroll
  lowSpecMode: boolean; // optimizations for older devices (Android 7-9)
  brightness: number; // 10 to 100
  autoScrollSpeed: number; // 1 to 10
  bionicReading: boolean;
  bionicStrength: number; // 30 to 70%
  oledPureBlack: boolean;
  ttsVoiceUri?: string;
  ttsSpeed: number; // 0.5 to 2.5
  ttsPitch: number; // 0.8 to 1.5
  wpmReadingSpeed: number; // default 240
  aiModelProvider: 'gemini-3.8-flash' | 'gemini-3.1-flash-lite' | 'local-offline';
}

export interface Bookmark {
  id: string;
  novelId: string;
  chapterIndex: number;
  chapterTitle: string;
  percentage: number;
  snippet: string;
  note?: string;
  createdAt: number;
}

export interface ReadingStats {
  totalSecondsRead: number;
  chaptersCompleted: number;
  booksFinished: number;
  lastActiveDate: string;
  weeklyActivity: Record<string, number>; // date "YYYY-MM-DD" -> seconds read
  currentStreak: number;
}

export interface UserLevelProgression {
  level: number;
  currentXp: number;
  nextLevelXp: number;
  rankTitle: string;
  nextRankTitle: string;
  unlockedPerks: string[];
  recentLevelUp?: boolean;
}

export interface AISummaryResult {
  recap: string;
  keyPoints: string[];
  characters: string[];
  mood?: string;
  takeaways?: string;
}

export interface AILoreResult {
  characters: Array<{ name: string; role: string; description: string; allegiance?: string }>;
  terms: Array<{ term: string; explanation: string; category: string }>;
  cliffhangerGuess: string;
}

export interface UserProfile {
  name: string;
  avatarUrl: string;
  bio: string;
  joinedDate: string;
  customTitle?: string;
}

export interface ReadingHistoryEntry {
  id: string; // Unique ID (e.g. `${novelId}_ch_${chapterIndex}`)
  novelId: string;
  novelTitle: string;
  novelCoverUrl?: string;
  novelAuthor?: string;
  chapterIndex: number;
  chapterTitle: string;
  progressPercent: number; // 0 to 100
  paragraphIndex?: number;
  timestamp: number; // Epoch timestamp in ms
}


