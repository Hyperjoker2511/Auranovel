import { ExtensionSource, Novel, ChapterContent } from '../types/novel';

export interface CommunityRepoListing {
  id: string;
  name: string;
  author: string;
  icon: string;
  description: string;
  url: string;
  sourceCount: number;
  languages: string[];
  tags: string[];
  isInstalled?: boolean;
}

// Curated list of popular community extension repositories
export const POPULAR_COMMUNITY_REPOS: CommunityRepoListing[] = [
  {
    id: 'repo_quicknovel_master',
    name: 'QuickNovel Master Extension Repo',
    author: 'Community Core',
    icon: '⚡',
    description: 'Universal multi-source repository indexing 150+ international novel sources, aggregators, and original serials.',
    url: 'https://raw.githubusercontent.com/quicknovel/extensions/master/repo.json',
    sourceCount: 160,
    languages: ['English', 'Spanish', 'French', 'Portuguese'],
    tags: ['Multi-Source', 'Aggregator', 'Popular', 'Fast'],
  },
  {
    id: 'repo_lnreader_multi',
    name: 'LNReader Community Registry',
    author: 'LNReader Team',
    icon: '📚',
    description: 'Premier light novel and web novel repository with support for English, Japanese, Chinese, and Korean translations.',
    url: 'https://raw.githubusercontent.com/lnreader/lnreader-sources/main/dist/plugins.json',
    sourceCount: 95,
    languages: ['English', 'Japanese', 'Korean', 'Chinese'],
    tags: ['Light Novels', 'Translations', 'Wuxia', 'Clean Text'],
  },
  {
    id: 'repo_royal_road',
    name: 'Royal Road Syndicate Feed',
    author: 'Royal Road Community',
    icon: '🏰',
    description: 'Direct high-fidelity catalog of top-rated Progression, LitRPG, and fantasy web serials.',
    url: 'https://raw.githubusercontent.com/aethernovel/repos/main/royalroad.json',
    sourceCount: 45,
    languages: ['English'],
    tags: ['LitRPG', 'Progression', 'Isekai', 'Originals'],
  },
  {
    id: 'repo_wuxia_nexus',
    name: 'Wuxia & Cultivation Hub',
    author: 'Daoist Sect Devs',
    icon: '⚔️',
    description: 'Dedicated Eastern fantasy feed: Xianxia, Xuanhuan, cultivation sects, and martial realm sagas.',
    url: 'https://raw.githubusercontent.com/aethernovel/repos/main/wuxia.json',
    sourceCount: 30,
    languages: ['English Translation'],
    tags: ['Cultivation', 'Xianxia', 'Martial Arts', 'Alchemy'],
  },
  {
    id: 'repo_korean_dungeon',
    name: 'K-Novel Hunter & Dungeon Hub',
    author: 'Seoul Guild Registry',
    icon: '🏹',
    description: 'Korean modern fantasy, hunter guilds, dungeon breaks, constellation systems, and tower ascension.',
    url: 'https://raw.githubusercontent.com/aethernovel/repos/main/knovels.json',
    sourceCount: 25,
    languages: ['English Translation', 'Korean'],
    tags: ['Hunters', 'Dungeons', 'Systems', 'Necromancy'],
  },
  {
    id: 'repo_scribble_hub',
    name: 'ScribbleHub Original Showcase',
    author: 'Scribble Community',
    icon: '✨',
    description: 'Vibrant collection of creative original serials: slice of life, villainess reincarnation, romance, and comedy.',
    url: 'https://raw.githubusercontent.com/aethernovel/repos/main/scribblehub.json',
    sourceCount: 40,
    languages: ['English'],
    tags: ['Romance', 'Comedy', 'Reincarnation', 'Slice of Life'],
  },
  {
    id: 'repo_gutenberg_classics',
    name: 'Gutenberg & Standard Ebooks Archive',
    author: 'Public Domain Alliance',
    icon: '📜',
    description: 'Over 70,000 public domain literary classics, historical masterworks, Gothic horrors, and philosophical epics.',
    url: 'https://raw.githubusercontent.com/aethernovel/repos/main/gutenberg.json',
    sourceCount: 50,
    languages: ['English', 'French', 'German', 'Multi-lingual'],
    tags: ['Classics', 'Historical', 'Public Domain', 'Gothic'],
  },
  {
    id: 'repo_syosetu_jp',
    name: 'Syosetu Shousetsuka ni Narou Mirror',
    author: 'Narou Japanese Translators',
    icon: '🌸',
    description: 'Japanese web novel source registry for isekai, otome game villainesses, slow life, and fantasy adventures.',
    url: 'https://raw.githubusercontent.com/aethernovel/repos/main/syosetu.json',
    sourceCount: 20,
    languages: ['English Translation', 'Japanese'],
    tags: ['Japanese', 'Isekai', 'Slow Life', 'Fantasy'],
  },
];

export const INITIAL_EXTENSIONS: ExtensionSource[] = [
  // 1. Royal Road Community
  {
    id: 'ext_royal_road',
    name: 'Royal Road Community',
    version: '2.5.0',
    icon: '🏰',
    description: 'Premier repository for original English web serials, LitRPG, Progression Fantasy, and Isekai.',
    language: 'English',
    enabled: true,
    isCommunity: true,
    tags: ['LitRPG', 'Fantasy', 'Progression', 'Isekai', 'Sci-Fi'],
    websiteUrl: 'https://www.royalroad.com',
    novels: [
      {
        id: 'rr_mother_of_learning',
        title: 'Mother of Learning',
        author: 'nobody103',
        coverUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=500&auto=format&fit=crop&q=80',
        description: 'Zorian is a teenage mage of humble birth and slightly above-average skill attending Cyoria’s magical academy. Just as the annual summer festival approaches, he finds himself trapped in a time loop, forced to relive the month over and over again while an impending disaster looms over the city.',
        genres: ['Fantasy', 'Time Loop', 'Progression', 'Magic Academy', 'Mystery'],
        sourceType: 'extension',
        sourceName: 'Royal Road Community',
        sourceUrl: 'https://www.royalroad.com/fiction/21220/mother-of-learning',
        status: 'reading',
        currentChapterIndex: 0,
        currentProgressPercent: 78,
        currentParagraphIndex: 12,
        totalChapters: 4,
        rating: 4.92,
        ratingCount: 1840,
        lastReadAt: Date.now() - 1000 * 60 * 18,
        createdAt: Date.now() - 86400000 * 3,
        reviews: [
          {
            id: 'rev_mol_1',
            author: 'AetherMage',
            avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&auto=format&fit=crop&q=80',
            rating: 5,
            date: '3 days ago',
            source: 'Royal Road Verified Reader',
            content: 'One of the greatest time loop fantasy masterworks ever written. Zorian’s progression feels thoroughly earned, the magic mechanics are deeply logical, and the worldbuilding is stellar.',
            likes: 342,
            aspectRatings: { story: 5, characters: 5, worldBuilding: 5, writingStyle: 4.8 },
          },
          {
            id: 'rev_mol_2',
            author: 'SpellWeaver99',
            rating: 5,
            date: '1 week ago',
            source: 'Royal Road Reviewer',
            content: 'The mystery keeps you guessing right up until the final arc. The mind magic duels and soul-sight training sequences are second to none.',
            likes: 188,
            aspectRatings: { story: 5, characters: 4.8, worldBuilding: 4.9, writingStyle: 4.7 },
          },
          {
            id: 'rev_mol_3',
            author: 'Bibliophile_Dan',
            rating: 4,
            date: '2 weeks ago',
            source: 'Community Member',
            content: 'Pacing starts slightly methodical, but once the loop mechanics click, it is genuinely unputdownable. Highly recommended!',
            likes: 95,
            aspectRatings: { story: 4.5, characters: 4.5, worldBuilding: 5, writingStyle: 4.5 },
          },
        ],
        chapters: [
          {
            id: 'rr_mol_1',
            novelId: 'rr_mother_of_learning',
            index: 0,
            title: 'Chapter 01: Good Morning, Brother',
            wordCount: 3820,
            releaseDate: '2024-01-10',
          },
          {
            id: 'rr_mol_2',
            novelId: 'rr_mother_of_learning',
            index: 1,
            title: 'Chapter 02: Train Ride to Cyoria',
            wordCount: 4120,
            releaseDate: '2024-01-17',
          },
          {
            id: 'rr_mol_3',
            novelId: 'rr_mother_of_learning',
            index: 2,
            title: 'Chapter 03: The Classroom and the Spider',
            wordCount: 3950,
            releaseDate: '2024-01-24',
          },
          {
            id: 'rr_mol_4',
            novelId: 'rr_mother_of_learning',
            index: 3,
            title: 'Chapter 04: The Red Robe Incident',
            wordCount: 4400,
            releaseDate: '2024-01-31',
          },
        ],
      },
      {
        id: 'rr_beware_of_chicken',
        title: 'Beware of Chicken',
        author: 'CasualFarmer',
        coverUrl: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=500&auto=format&fit=crop&q=80',
        description: 'Jin Rou wanted to be a cultivator. He really did. But after a duel left his soul nearly shattered and his body bruised, he made a decision: cultivation sects are cutthroat madhouses. He heads to the far reaches of the Azure Hills to buy an overgrown farm, grow cabbages, and live in peaceful solitude. Unfortunately, the local rooster seems to be learning martial arts.',
        genres: ['Xianxia', 'Slice of Life', 'Comedy', 'Farming', 'Animals'],
        sourceType: 'extension',
        sourceName: 'Royal Road Community',
        sourceUrl: 'https://www.royalroad.com/fiction/39408/beware-of-chicken',
        status: 'plan_to_read',
        currentChapterIndex: 0,
        currentProgressPercent: 0,
        totalChapters: 3,
        rating: 4.88,
        ratingCount: 1120,
        lastReadAt: Date.now() - 7200000,
        createdAt: Date.now() - 86400000 * 5,
        reviews: [
          {
            id: 'rev_boc_1',
            author: 'DaoistFarmer',
            rating: 5,
            date: 'Yesterday',
            source: 'Royal Road Verified Reader',
            content: 'Pure wholesome soul food! A hilarious, cozy subversion of bloody cultivation sect tropes. Big D the martial rooster is an absolute legend.',
            likes: 412,
            aspectRatings: { story: 5, characters: 5, worldBuilding: 4.9, writingStyle: 4.9 },
          },
          {
            id: 'rev_boc_2',
            author: 'MapleLeafReader',
            rating: 5,
            date: '5 days ago',
            source: 'ScribbleHub Reader',
            content: 'The character relationships feel so warm and genuine. Jin Rou just wanting to farm cabbages while accidentally founding a legendary sect is comedic gold.',
            likes: 167,
            aspectRatings: { story: 4.8, characters: 5, worldBuilding: 4.8, writingStyle: 4.9 },
          },
        ],
        chapters: [
          {
            id: 'rr_boc_1',
            novelId: 'rr_beware_of_chicken',
            index: 0,
            title: 'Chapter 01: Leaving the Cloudy Sword Sect',
            wordCount: 3100,
            releaseDate: '2024-02-01',
          },
          {
            id: 'rr_boc_2',
            novelId: 'rr_beware_of_chicken',
            index: 1,
            title: 'Chapter 02: The Spirit Herb Garden & Big D',
            wordCount: 3450,
            releaseDate: '2024-02-08',
          },
          {
            id: 'rr_boc_3',
            novelId: 'rr_beware_of_chicken',
            index: 2,
            title: 'Chapter 03: The Awakening of the Crimson Crest',
            wordCount: 3600,
            releaseDate: '2024-02-15',
          },
        ],
      },
      {
        id: 'rr_defiance_fall',
        title: 'Defiance of the Fall',
        author: 'TheFirstDefier',
        coverUrl: 'https://images.unsplash.com/photo-1514539079130-25950c84af65?w=500&auto=format&fit=crop&q=80',
        description: 'Zac was alone in the wilderness on a camping trip when the multiverse converged. Suddenly, Earth merged with a mystical realm governed by an unforgiving System. Stuck on a dangerous island crawling with demonic beasts, Zac has only his camping axe and relentless determination to survive.',
        genres: ['LitRPG', 'Cultivation', 'Apocalypse', 'Action', 'Survival'],
        sourceType: 'extension',
        sourceName: 'Royal Road Community',
        sourceUrl: 'https://www.royalroad.com/fiction/24709/defiance-of-the-fall',
        status: 'reading',
        currentChapterIndex: 0,
        currentProgressPercent: 0,
        totalChapters: 3,
        rating: 4.78,
        ratingCount: 2450,
        lastReadAt: Date.now() - 14400000,
        createdAt: Date.now() - 86400000 * 2,
        reviews: [
          {
            id: 'rev_dotf_1',
            author: 'AxeGrinderZ',
            avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80',
            rating: 5,
            date: '4 days ago',
            source: 'Royal Road Top Reviewer',
            content: 'Incredible scale of worldbuilding and satisfying cosmic progression. Zac is a relentless juggernaut who earns every Dao seed and cosmic bloodline improvement.',
            likes: 278,
            aspectRatings: { story: 4.8, characters: 4.6, worldBuilding: 5.0, writingStyle: 4.7 },
          },
        ],
        chapters: [
          {
            id: 'rr_dotf_1',
            novelId: 'rr_defiance_fall',
            index: 0,
            title: 'Chapter 01: The Cosmic Integration',
            wordCount: 3300,
            releaseDate: '2024-03-01',
          },
          {
            id: 'rr_dotf_2',
            novelId: 'rr_defiance_fall',
            index: 1,
            title: 'Chapter 02: Hatchet against the Beast',
            wordCount: 3650,
            releaseDate: '2024-03-05',
          },
          {
            id: 'rr_dotf_3',
            novelId: 'rr_defiance_fall',
            index: 2,
            title: 'Chapter 03: First Level Up & Attributes',
            wordCount: 3900,
            releaseDate: '2024-03-10',
          },
        ],
      },
      {
        id: 'rr_primal_hunter',
        title: 'The Primal Hunter',
        author: 'Zogarth',
        coverUrl: 'https://images.unsplash.com/photo-1511447333015-45b65e60f6d5?w=500&auto=format&fit=crop&q=80',
        description: 'Jake, an office worker suffering from quiet apathy, is dragged into an ancient Tutorial alongside his coworkers. But in this savage trial of bowmanship and beast hunting, Jake finds something he never had in modern society: true purpose and an insatiable bloodline instinct.',
        genres: ['LitRPG', 'Archery', 'Alchemy', 'Solo Progression', 'Action'],
        sourceType: 'extension',
        sourceName: 'Royal Road Community',
        sourceUrl: 'https://www.royalroad.com/fiction/36049/the-primal-hunter',
        status: 'plan_to_read',
        currentChapterIndex: 0,
        currentProgressPercent: 0,
        totalChapters: 2,
        rating: 4.82,
        ratingCount: 3100,
        createdAt: Date.now() - 86400000 * 4,
        lastReadAt: Date.now(),
        reviews: [
          {
            id: 'rev_ph_1',
            author: 'ViperArcher',
            rating: 5,
            date: '1 week ago',
            source: 'Royal Road Verified Reader',
            content: 'Jake’s bloodline perception and the alchemy system make this one of the absolute best LitRPGs around. Pure fun and exhilarating archery combat.',
            likes: 314,
            aspectRatings: { story: 4.8, characters: 4.9, worldBuilding: 4.8, writingStyle: 4.8 },
          },
        ],
        chapters: [
          {
            id: 'rr_ph_1',
            novelId: 'rr_primal_hunter',
            index: 0,
            title: 'Chapter 01: The Primordial Initiation',
            wordCount: 3400,
            releaseDate: '2024-02-20',
          },
          {
            id: 'rr_ph_2',
            novelId: 'rr_primal_hunter',
            index: 1,
            title: 'Chapter 02: Instinct of the Viper',
            wordCount: 3600,
            releaseDate: '2024-02-22',
          },
        ],
      },
    ],
  },

  // 2. Project Gutenberg Archive
  {
    id: 'ext_project_gutenberg',
    name: 'Project Gutenberg Archive',
    version: '3.1.0',
    icon: '📜',
    description: 'Over 70,000 free public domain masterworks, classical literature, and historical epics.',
    language: 'Multi-lingual',
    enabled: true,
    isCommunity: true,
    tags: ['Classics', 'Gothic', 'Mystery', 'Adventure', 'Public Domain'],
    websiteUrl: 'https://www.gutenberg.org',
    novels: [
      {
        id: 'pg_frankenstein',
        title: 'Frankenstein; or, The Modern Prometheus',
        author: 'Mary Wollstonecraft Shelley',
        coverUrl: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=500&auto=format&fit=crop&q=80',
        description: 'Victor Frankenstein, an ambitious young natural philosopher, discovers the secret of imparting life to inanimate matter. Galvanized by pride and desire to conquer mortality, he crafts a creature from charnel house remnants—only to flee in horror when the spark of vitality opens the beings yellow, watery eyes.',
        genres: ['Gothic Fiction', 'Horror', 'Classics', 'Science Fiction'],
        sourceType: 'extension',
        sourceName: 'Project Gutenberg Archive',
        sourceUrl: 'https://www.gutenberg.org/ebooks/84',
        status: 'reading',
        currentChapterIndex: 0,
        currentProgressPercent: 100,
        currentParagraphIndex: 18,
        totalChapters: 4,
        rating: 4.84,
        ratingCount: 8420,
        lastReadAt: Date.now() - 1000 * 60 * 60 * 3.5,
        createdAt: Date.now() - 86400000 * 10,
        reviews: [
          {
            id: 'rev_frank_1',
            author: 'GothicScholar',
            avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
            rating: 5,
            date: 'May 12, 2024',
            source: 'Project Gutenberg Archive',
            content: 'Mary Shelley created modern science fiction at nineteen years old. The philosophical questions about scientific hubris, societal ostracization, and responsibility for creation remain profoundly relevant today.',
            likes: 1250,
            aspectRatings: { story: 4.9, characters: 4.8, worldBuilding: 4.7, writingStyle: 5.0 },
          },
          {
            id: 'rev_frank_2',
            author: 'VictorK',
            rating: 5,
            date: 'April 3, 2024',
            source: 'Literary Society Review',
            content: 'The creature’s eloquent monologue in the Mer de Glace is heart-wrenching. A foundational classic that everyone should read in full text rather than relying on movie caricatures.',
            likes: 640,
            aspectRatings: { story: 4.8, characters: 4.9, worldBuilding: 4.6, writingStyle: 4.8 },
          },
        ],
        chapters: [
          {
            id: 'pg_frank_1',
            novelId: 'pg_frankenstein',
            index: 0,
            title: 'Letter 1 - 4: Robert Walton to Mrs. Saville',
            wordCount: 4200,
            releaseDate: '1818-01-01',
          },
          {
            id: 'pg_frank_2',
            novelId: 'pg_frankenstein',
            index: 1,
            title: 'Chapter 1: Geneva and Youth',
            wordCount: 3200,
            releaseDate: '1818-01-01',
          },
          {
            id: 'pg_frank_3',
            novelId: 'pg_frankenstein',
            index: 2,
            title: 'Chapter 4: The Secret of Animation',
            wordCount: 3600,
            releaseDate: '1818-01-01',
          },
          {
            id: 'pg_frank_4',
            novelId: 'pg_frankenstein',
            index: 3,
            title: 'Chapter 5: It Was on a Dreary Night of November',
            wordCount: 3800,
            releaseDate: '1818-01-01',
          },
        ],
      },
      {
        id: 'pg_sherlock_holmes',
        title: 'The Adventures of Sherlock Holmes',
        author: 'Arthur Conan Doyle',
        coverUrl: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=500&auto=format&fit=crop&q=80',
        description: 'Venture into 221B Baker Street alongside Dr. John Watson as the brilliant consulting detective Sherlock Holmes unravels perplexing crimes across Victorian London, from the royal scandal of Irene Adler to the bizarre Red-Headed League.',
        genres: ['Mystery', 'Detective', 'Classics', 'Historical Fiction'],
        sourceType: 'extension',
        sourceName: 'Project Gutenberg Archive',
        sourceUrl: 'https://www.gutenberg.org/ebooks/1661',
        status: 'plan_to_read',
        currentChapterIndex: 0,
        currentProgressPercent: 0,
        totalChapters: 3,
        rating: 4.9,
        lastReadAt: Date.now() - 90000000,
        createdAt: Date.now() - 86400000 * 15,
        chapters: [
          {
            id: 'pg_sh_1',
            novelId: 'pg_sherlock_holmes',
            index: 0,
            title: 'A Scandal in Bohemia - Part I',
            wordCount: 3400,
            releaseDate: '1892-10-14',
          },
          {
            id: 'pg_sh_2',
            novelId: 'pg_sherlock_holmes',
            index: 1,
            title: 'A Scandal in Bohemia - Part II',
            wordCount: 3600,
            releaseDate: '1892-10-14',
          },
          {
            id: 'pg_sh_3',
            novelId: 'pg_sherlock_holmes',
            index: 2,
            title: 'The Red-Headed League',
            wordCount: 4200,
            releaseDate: '1892-10-14',
          },
        ],
      },
      {
        id: 'pg_dracula',
        title: 'Dracula',
        author: 'Bram Stoker',
        coverUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=500&auto=format&fit=crop&q=80',
        description: 'Solicitor Jonathan Harker travels to the remote Carpathian Mountains to meet the eccentric Count Dracula in his crumbling Gothic castle. But as Harker uncovers the horrific nature of his host, a sinister shadow casts itself toward the foggy shores of Whitby.',
        genres: ['Gothic', 'Vampire', 'Horror', 'Epistolary'],
        sourceType: 'extension',
        sourceName: 'Project Gutenberg Archive',
        sourceUrl: 'https://www.gutenberg.org/ebooks/345',
        status: 'plan_to_read',
        currentChapterIndex: 0,
        currentProgressPercent: 0,
        totalChapters: 2,
        rating: 4.82,
        lastReadAt: Date.now(),
        createdAt: Date.now() - 86400000 * 7,
        chapters: [
          {
            id: 'pg_drac_1',
            novelId: 'pg_dracula',
            index: 0,
            title: 'Chapter 01: Jonathan Harker’s Journal (Borgo Pass)',
            wordCount: 3900,
            releaseDate: '1897-05-26',
          },
          {
            id: 'pg_drac_2',
            novelId: 'pg_dracula',
            index: 1,
            title: 'Chapter 02: Count Dracula’s Castle & Secrets',
            wordCount: 4100,
            releaseDate: '1897-05-26',
          },
        ],
      },
    ],
  },

  // 3. Dao & Cultivation Nexus (WuxiaWorld / Webnovel)
  {
    id: 'ext_wuxia_realm',
    name: 'Dao & Cultivation Nexus',
    version: '2.1.0',
    icon: '⚔️',
    description: 'Eastern fantasy, immortal cultivation, alchemy, sect rivalries, and martial arts progression.',
    language: 'English Translation',
    enabled: true,
    isCommunity: true,
    tags: ['Xianxia', 'Wuxia', 'Martial Arts', 'Cultivation', 'Reincarnation'],
    websiteUrl: 'https://www.wuxiaworld.com',
    novels: [
      {
        id: 'wx_martial_peak',
        title: 'Martial Peak',
        author: 'Momo',
        coverUrl: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=500&auto=format&fit=crop&q=80',
        description: 'Yang Kai was a lowly sweeper disciple at High Heaven Pavilion, ridiculed for his slow progress and meager meridians. Everything changes when he stumbles upon a mysterious Black Book hidden beneath an ancient stone pavilion.',
        genres: ['Xianxia', 'Martial Arts', 'Alchemy', 'Cultivation', 'Action'],
        sourceType: 'extension',
        sourceName: 'Dao & Cultivation Nexus',
        status: 'reading',
        currentChapterIndex: 0,
        currentProgressPercent: 0,
        totalChapters: 3,
        rating: 4.7,
        lastReadAt: Date.now() - 10000000,
        createdAt: Date.now() - 86400000 * 4,
        chapters: [
          {
            id: 'wx_mp_1',
            novelId: 'wx_martial_peak',
            index: 0,
            title: 'Chapter 01: The Sweeper Disciple',
            wordCount: 2800,
            releaseDate: '2024-01-01',
          },
          {
            id: 'wx_mp_2',
            novelId: 'wx_martial_peak',
            index: 1,
            title: 'Chapter 02: The Wordless Black Book',
            wordCount: 3100,
            releaseDate: '2024-01-02',
          },
          {
            id: 'wx_mp_3',
            novelId: 'wx_martial_peak',
            index: 2,
            title: 'Chapter 03: The Golden Skeleton Merge',
            wordCount: 3300,
            releaseDate: '2024-01-03',
          },
        ],
      },
      {
        id: 'wx_coiling_dragon',
        title: 'Coiling Dragon',
        author: 'I Eat Tomatoes',
        coverUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=500&auto=format&fit=crop&q=80',
        description: 'Linley Baruch, the scion of the once-mighty Dragonblood Warrior clan in the Yulan Continent, finds a ring with a carved dragon during his exploration of the ruined ancestral hall. Within resides the soul of a grand Saint-level magus who guides him on his rise to godhood.',
        genres: ['Fantasy', 'Cultivation', 'Dragons', 'Magic', 'Adventure'],
        sourceType: 'extension',
        sourceName: 'Dao & Cultivation Nexus',
        status: 'plan_to_read',
        currentChapterIndex: 0,
        currentProgressPercent: 0,
        totalChapters: 2,
        rating: 4.88,
        createdAt: Date.now() - 86400000 * 6,
        lastReadAt: Date.now(),
        chapters: [
          {
            id: 'wx_cd_1',
            novelId: 'wx_coiling_dragon',
            index: 0,
            title: 'Chapter 01: The Twilight of the Baruch Clan',
            wordCount: 3200,
            releaseDate: '2024-01-15',
          },
          {
            id: 'wx_cd_2',
            novelId: 'wx_coiling_dragon',
            index: 1,
            title: 'Chapter 02: Discovery of the Dragon Ring',
            wordCount: 3500,
            releaseDate: '2024-01-16',
          },
        ],
      },
    ],
  },

  // 4. Korean Webnovel Hub (K-Novels / Munpia)
  {
    id: 'ext_korean_hub',
    name: 'K-Novel Hunter & Dungeon Hub',
    version: '1.8.4',
    icon: '🏹',
    description: 'Korean modern urban fantasy, hunter awakenings, dungeon gates, constellations, and shadows.',
    language: 'English Translation',
    enabled: true,
    isCommunity: true,
    tags: ['Hunters', 'Dungeons', 'Constellations', 'Necromancy', 'Modern Fantasy'],
    websiteUrl: 'https://munpia.com',
    novels: [
      {
        id: 'kn_solo_leveling',
        title: 'Solo Leveling (Only I Level Up)',
        author: 'Chugong',
        coverUrl: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=500&auto=format&fit=crop&q=80',
        description: 'Known derisively as the "Weakest Hunter of All Mankind", E-rank Sung Jin-Woo risks his life in low-grade dungeons to pay his mother’s medical bills. After being left to die inside a nightmarish double dungeon, he awakens to a mysterious Player quest screen visible only to him.',
        genres: ['Urban Fantasy', 'Hunter', 'Dungeons', 'Necromancy', 'Action'],
        sourceType: 'extension',
        sourceName: 'K-Novel Hunter & Dungeon Hub',
        status: 'reading',
        currentChapterIndex: 0,
        currentProgressPercent: 35,
        totalChapters: 3,
        rating: 4.95,
        ratingCount: 12500,
        createdAt: Date.now() - 86400000 * 8,
        lastReadAt: Date.now() - 3600000 * 2,
        reviews: [
          {
            id: 'rev_sl_1',
            author: 'ShadowMonarch',
            avatarUrl: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=100&auto=format&fit=crop&q=80',
            rating: 5,
            date: '2 days ago',
            source: 'Munpia / Webnovel Verified Reader',
            content: 'The definitive modern dungeon hunter power fantasy! Sung Jin-Woo’s progression from bottom-feeder E-rank to the undisputed Shadow Sovereign is adrenaline-pumping from start to finish.',
            likes: 1890,
            aspectRatings: { story: 4.8, characters: 4.9, worldBuilding: 4.9, writingStyle: 5.0 },
          },
          {
            id: 'rev_sl_2',
            author: 'HunterGuildMaster',
            rating: 5,
            date: '1 week ago',
            source: 'K-Novel Community',
            content: '“ARISE!” — Still gives chills every single time. Fast-paced, ruthless monster battles, and unforgettable moments.',
            likes: 920,
            aspectRatings: { story: 4.9, characters: 4.7, worldBuilding: 4.8, writingStyle: 4.9 },
          },
        ],
        chapters: [
          {
            id: 'kn_sl_1',
            novelId: 'kn_solo_leveling',
            index: 0,
            title: 'Chapter 01: The Weakest E-Rank Hunter',
            wordCount: 3400,
            releaseDate: '2024-02-01',
          },
          {
            id: 'kn_sl_2',
            novelId: 'kn_solo_leveling',
            index: 1,
            title: 'Chapter 02: The Double Dungeon Trial',
            wordCount: 3700,
            releaseDate: '2024-02-02',
          },
          {
            id: 'kn_sl_3',
            novelId: 'kn_solo_leveling',
            index: 2,
            title: 'Chapter 03: The Secret Quest Window',
            wordCount: 3900,
            releaseDate: '2024-02-03',
          },
        ],
      },
      {
        id: 'kn_orv',
        title: "Omniscient Reader's Viewpoint",
        author: 'Sing Shong',
        coverUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=500&auto=format&fit=crop&q=80',
        description: 'Kim Dokja was an ordinary contractor whose sole hobby was reading an unpopular web novel titled "Three Ways to Survive in a Ruined World" for over a decade. When the final chapter is published, reality suddenly shifts into the novel’s apocalyptic scenarios, and Dokja is the only reader who knows how the world will end.',
        genres: ['Apocalypse', 'Constellations', 'Psychological', 'System', 'Action'],
        sourceType: 'extension',
        sourceName: 'K-Novel Hunter & Dungeon Hub',
        status: 'reading',
        currentChapterIndex: 0,
        currentProgressPercent: 50,
        totalChapters: 2,
        rating: 4.96,
        createdAt: Date.now() - 86400000 * 6,
        lastReadAt: Date.now() - 3600000 * 5,
        chapters: [
          {
            id: 'kn_orv_1',
            novelId: 'kn_orv',
            index: 0,
            title: 'Episode 01: Starting the Paid Service',
            wordCount: 3600,
            releaseDate: '2024-02-10',
          },
          {
            id: 'kn_orv_2',
            novelId: 'kn_orv',
            index: 1,
            title: 'Episode 02: Main Scenario #1 Begins',
            wordCount: 3800,
            releaseDate: '2024-02-11',
          },
        ],
      },
    ],
  },

  // 5. LightNovelPub / Japanese Translations
  {
    id: 'ext_ln_pub',
    name: 'LightNovelPub & Japanese LN Hub',
    version: '2.0.1',
    icon: '📖',
    description: 'Premier Japanese light novel translations, official web novel adaptations, and fantasy epics.',
    language: 'English Translation',
    enabled: true,
    isCommunity: true,
    tags: ['Light Novels', 'Isekai', 'Overpowered', 'Fantasy', 'Anime Adaptation'],
    websiteUrl: 'https://www.lightnovelpub.vip',
    novels: [
      {
        id: 'ln_overlord',
        title: 'Overlord',
        author: 'Kugane Maruyama',
        coverUrl: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=500&auto=format&fit=crop&q=80',
        description: 'The final hour of the beloved virtual-reality game Yggdrasil has arrived. Momonga, a powerful skeletal wizard and guildmaster of Ainz Ooal Gown, decides to stay logged in until the servers shut down. But instead of disconnecting, the Great Tomb of Nazarick is transported into a real fantasy world.',
        genres: ['Dark Fantasy', 'Anti-Hero', 'Isekai', 'Strategy', 'Overpowered'],
        sourceType: 'extension',
        sourceName: 'LightNovelPub & Japanese LN Hub',
        status: 'plan_to_read',
        currentChapterIndex: 0,
        currentProgressPercent: 0,
        totalChapters: 2,
        rating: 4.9,
        createdAt: Date.now() - 86400000 * 9,
        lastReadAt: Date.now(),
        chapters: [
          {
            id: 'ln_ov_1',
            novelId: 'ln_overlord',
            index: 0,
            title: 'Chapter 01: The End and the Beginning',
            wordCount: 4200,
            releaseDate: '2024-01-20',
          },
          {
            id: 'ln_ov_2',
            novelId: 'ln_overlord',
            index: 1,
            title: 'Chapter 02: Floor Guardians Assemble',
            wordCount: 4500,
            releaseDate: '2024-01-22',
          },
        ],
      },
      {
        id: 'ln_slime',
        title: 'That Time I Got Reincarnated as a Slime',
        author: 'Fuse',
        coverUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?w=500&auto=format&fit=crop&q=80',
        description: 'Lonely thirty-seven-year-old corporate worker Satoru Mikami is stabbed by a random assailant on the street. Reborn into a magical realm as a blind, gelatinous slime named Rimuru, he gains the unique skill "Predator" and begins founding a federation of peaceful monsters.',
        genres: ['Isekai', 'Kingdom Building', 'Magic', 'Comedy', 'Adventure'],
        sourceType: 'extension',
        sourceName: 'LightNovelPub & Japanese LN Hub',
        status: 'reading',
        currentChapterIndex: 0,
        currentProgressPercent: 20,
        totalChapters: 2,
        rating: 4.86,
        createdAt: Date.now() - 86400000 * 5,
        lastReadAt: Date.now() - 3600000 * 12,
        chapters: [
          {
            id: 'ln_sl_1',
            novelId: 'ln_slime',
            index: 0,
            title: 'Chapter 01: Reborn in the Sealed Cave',
            wordCount: 3500,
            releaseDate: '2024-01-25',
          },
          {
            id: 'ln_sl_2',
            novelId: 'ln_slime',
            index: 1,
            title: 'Chapter 02: The Storm Dragon Veldora',
            wordCount: 3900,
            releaseDate: '2024-01-28',
          },
        ],
      },
    ],
  },

  // 6. ScribbleHub Community
  {
    id: 'ext_scribble_hub',
    name: 'ScribbleHub Originals',
    version: '1.7.2',
    icon: '✨',
    description: 'Community-driven creative fiction: otome game villainesses, monster evolution, cozy slice of life, and comedy.',
    language: 'English',
    enabled: true,
    isCommunity: true,
    tags: ['Reincarnation', 'Comedy', 'Slice of Life', 'Villainess', 'Romance'],
    websiteUrl: 'https://www.scribblehub.com',
    novels: [
      {
        id: 'sh_chrysalis',
        title: 'Chrysalis: The Reincarnated Ant',
        author: 'RinoZ',
        coverUrl: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=500&auto=format&fit=crop&q=80',
        description: 'Anthony wakes up with six legs, two antennae, and a terrifying exoskeleton deep within the dangerous Pangera Dungeon. He has been reincarnated as an infant worker ant with zero combat stats, but an indomitable love for his new colony and giant mandibles.',
        genres: ['Monster Evolution', 'LitRPG', 'Dungeon', 'Comedy', 'Action'],
        sourceType: 'extension',
        sourceName: 'ScribbleHub Originals',
        sourceUrl: 'https://www.scribblehub.com/series/11797/chrysalis/',
        status: 'reading',
        currentChapterIndex: 0,
        currentProgressPercent: 0,
        totalChapters: 2,
        rating: 4.84,
        createdAt: Date.now() - 86400000 * 4,
        lastReadAt: Date.now(),
        chapters: [
          {
            id: 'sh_chrys_1',
            novelId: 'sh_chrysalis',
            index: 0,
            title: 'Chapter 01: Egg of the Underworld',
            wordCount: 3200,
            releaseDate: '2024-02-14',
          },
          {
            id: 'sh_chrys_2',
            novelId: 'sh_chrysalis',
            index: 1,
            title: 'Chapter 02: Biomass and Evolution Menu',
            wordCount: 3400,
            releaseDate: '2024-02-16',
          },
        ],
      },
    ],
  },
];

// Pre-loaded realistic chapter contents for instantaneous offline reading across all extensions
export const EXTENSION_CHAPTER_CONTENTS: Record<string, string> = {
  // Mother of Learning
  'rr_mol_1': `
    <p>“Good morning, brother! Your morning routine is taking entirely too long, and mother says you will be late for the train!”</p>
    <p>Zorian grimaced, pulling his pillow over his ears. The high-pitched voice belonged to Kirielle, his younger sister, whose sole joy in life seemed to be terrorizing his morning sleep before the sun had even properly breached the eastern hills of Cirin.</p>
    <p>“Go away, Kirielle,” Zorian groaned, his voice muffled by wool and feathers. “The train does not depart until ten o'clock. It is barely seven.”</p>
    <p>“Seven fifteen!” a triumphant voice corrected through the wooden door, accompanied by three sharp, rhythmic raps. “And Mother made potato pancakes with apple butter! If you do not emerge in ten seconds, Father will eat your portion!”</p>
    <p>Zorian sighed, finally sitting up in his narrow bed. Today marked the beginning of his third year at the Royal Academy of Magical Arts in Cyoria. For Zorian, that meant leaving his overbearing parents behind for an entire year. That alone made the journey worthwhile.</p>
    <p>He dressed quickly in his charcoal apprentice tunic, fastened his brass spell-focus ring to his index finger, and packed the remainder of his notebooks into his traveling trunk.</p>
    <p>Little did he suspect that before the month of the Summer Festival would end, Cyoria would be engulfed in an eldritch storm, and this very morning would repeat for thousands of cycles to come.</p>
  `,

  'rr_mol_2': `
    <p>The steam locomotive hissed violently, expelling thick plumes of white vapor against the vaulted glass ceiling of the Cirin municipal station. Passengers bustled about with trunks and satchels of alchemical ingredients.</p>
    <p>Zorian leaned against the cushioned bench of his second-class compartment, watching the verdant farmland of northern Eldemar roll smoothly past the windowpane. Opposite him sat Taiven, his childhood friend and energetic battle-mage initiate wielding a spiked wooden training staff.</p>
    <p>“Still looking like someone murdered your favorite book, Zorian?” Taiven remarked with an impish smirk.</p>
    <p>As the locomotive banked along the great granite viaduct leading into Cyoria, Zorian noticed something strange on the horizon. High in the southern sky, above Mount Krene, hung an unnatural shimmering crimson line—like a hairline fracture in the blue sky itself.</p>
    <p>He blinked, but when he looked again, the sky was clear blue once more.</p>
  `,

  // Beware of Chicken
  'rr_boc_1': `
    <p>Jin Rou took a deep breath of the crisp mountain air. It smelled like fresh pines, loam, and sweet wild grass. It distinctly did not smell like burnt copper, spirit blood, or the sulfurous incense of the Cloudy Sword Sect.</p>
    <p>“Freedom,” he whispered, patting the weathered neck of his ox, who was pulling a rickety wooden cart piled high with hoes, bags of rice grain, turnip seeds, and an iron cooking cauldron.</p>
    <p>Jin had spent four years in the inner courts of the Cloudy Sword Sect trying to comprehend the Grand Dao of Heavenly Lightning. The result? He had been challenged to thirty-seven honor duels and had taken a palm strike that left his cultivation core cracked.</p>
    <p>“Cultivation is for lunatics,” Jin declared aloud to the quiet valley. “Look at me. I'm going to grow the plumpest cabbages in the province, brew sweet plum wine, and sit on my porch until I'm eighty years old.”</p>
    <p>From inside a wicker basket on the back of the cart, a small rooster with unusually vibrant crimson feathers poked his head out, golden eyes glowing with faint, crackling sparks.</p>
  `,

  // Defiance of the Fall
  'rr_dotf_1': `
    <p>[System Notification: Planetary Convergence initiated.]</p>
    <p>[Sector 42-Earth integrated into the World of the Great Abyss.]</p>
    <p>Zac woke up with his face pressed against damp pine needles. In front of him, hovering in translucent sapphire light, was an interface window that looked suspiciously like a high-end MMORPG screen.</p>
    <p>Twenty yards away, chewing noisily on the carcass of an antlered beast, stood a hound the size of a minivan with three pairs of glowing red eyes.</p>
    <p>Zac’s hand reached down into his tent flap and found the rubber grip of his heavy steel camping hatchet. “System or no system,” he thought grimly, “I am not dying in this damned forest.”</p>
  `,

  // The Primal Hunter
  'rr_ph_1': `
    <p>[The Primordial System has encompassed Realm 9042.]</p>
    <p>[Initiating Tutorial Scenario. All inhabitants will be distributed according to latent affinity.]</p>
    <p>Jake opened his eyes to the smell of humid, prehistoric jungle. Gone was the bland beige cubicle of the logistics firm. In his hands was a recurve yew bow and a quiver of twenty flint-tipped arrows.</p>
    <p>For the first time in ten years, the perpetual fog in Jake’s mind parted. A deep, dormant predatory instinct surged through his veins. Somewhere out in the green canopy, a predator was hunting. And for once, Jake wanted to hunt back.</p>
  `,

  // Frankenstein
  'pg_frank_1': `
    <p><em>To Mrs. Saville, England.</em></p>
    <p><strong>St. Petersburgh, Dec. 11th, 17—</strong></p>
    <p>You will rejoice to hear that no disaster has accompanied the commencement of an enterprise which you have regarded with such evil forebodings. I arrived here yesterday, and my first task is to assure my dear sister of my welfare and increasing confidence in the success of my undertaking.</p>
    <p>I am already far north of London, and as I walk in the streets of Petersburgh, I feel a cold northern breeze play upon my cheeks, which braces my nerves and fills me with delight.</p>
  `,

  // Sherlock Holmes
  'pg_sh_1': `
    <p>To Sherlock Holmes she is always <em>the</em> woman. I have seldom heard him mention her under any other name. In his eyes she eclipses and predominates the whole of her sex.</p>
    <p>One night—it was on the twentieth of March, 1888—I was returning from a journey to a patient, when my way led me through Baker Street. As I passed the well-remembered door, I saw his tall, spare figure pass twice in a dark silhouette against the blind.</p>
    <p>He was at work again. He had risen out of his drug-created dreams and was hot upon the scent of some new problem.</p>
  `,

  // Martial Peak
  'wx_mp_1': `
    <p>High Heaven Pavilion was situated within the boundless mountain ranges of the Han Dynasty. Misty peaks pierced through the clouds like jade pillars, shrouded in spiritual mist.</p>
    <p>At the base of the mountain, a youth dressed in a patched gray hemp robe held a coarse bamboo broom. Sweat dripped down his sun-bronzed forehead as he swept the massive stone steps leading to the main martial hall.</p>
    <p>His name was Yang Kai. Three years ago, he had entered High Heaven Pavilion as a trial disciple. Yet his meridians were abnormally narrow, and he remained stubbornly stuck at the Tempered Body 3rd Stage. But beneath the flagstones of the pavilion, a wordless Black Book was waiting for blood to awake.</p>
  `,

  // Coiling Dragon
  'wx_cd_1': `
    <p>The township of Wushan lay in the eastern territory of the Holy Union on the Yulan Continent. In the courtyard of the declining Baruch manor, eight-year-old Linley sat cross-legged atop a granite block, enduring the morning conditioning drills.</p>
    <p>“The Blood of the Dragonblood Warriors has flowed thin for five millennia,” his father, Hogg Baruch, lectured with somber gravity. “Yet our proud lineage will never kneel.”</p>
    <p>Later that afternoon, wandering into the crumbling back pavilion of their ancestors, Linley’s foot kicked against a blackened ring buried beneath decades of dust and moss.</p>
  `,

  // Solo Leveling
  'kn_sl_1': `
    <p>A Gate opened. Whenever an interdimensional Gate manifested, modern weapons proved useless against the beasts inside. Only Awakeners, known as Hunters, could breach the blue dungeon mist.</p>
    <p>“Jin-Woo! Make sure you stay behind Mr. Song!” the raid party leader called out.</p>
    <p>Sung Jin-Woo nodded with a wry smile, gripping his cheap steel dagger. As an E-rank hunter whose magical power was barely above an ordinary human’s, even a low-grade goblin could land him in the intensive care unit. But medical bills for his comatose mother left him with no choice.</p>
    <p>He stepped into the dungeon cavern, completely unaware that behind the boss room lay the dreaded Double Dungeon—and the stone statues that would change his fate forever.</p>
  `,

  // Omniscient Reader's Viewpoint
  'kn_orv_1': `
    <p>There are three ways to survive in a ruined world. Now, I have forgotten a few, but one thing is certain: the fact that you who are reading this will survive.</p>
    <p>My name is Kim Dokja. "Dokja" can mean either an only son or a reader. In my case, it was both.</p>
    <p>On the subway ride home on Line 3, I refreshed my phone screen. The web novel I had been following for over ten years, through middle school, military service, and contract employment, had just posted its final chapter: Chapter 3149.</p>
    <p>As the clock struck 7:00 PM, the subway lights flickered violently and died. A chilling voice echoed through the train car: [The free service of the planetary system has terminated. Main Scenario #1 has commenced.]</p>
  `,

  // Overlord
  'ln_ov_1': `
    <p>The year was 2138, and DMMO-RPG (Dive Massively Multiplayer Online Role Playing Game) had become the pinnacle of gaming technology. But tonight, the once-legendary Yggdrasil was shutting down its servers permanently.</p>
    <p>In the Throne Room of the Great Tomb of Nazarick, Momonga sat alone upon the Throne of Kings. Surrounding him were the impeccably designed NPC guardians created by his forty former guildmates, all standing motionless with bowed heads.</p>
    <p>00:00:00.</p>
    <p>Momonga closed his eyes, awaiting the forced logout screen. One second passed. Two seconds. The forced logout never came. Instead, the smell of burning incense filled his senses, and Albedo, the succubus overseer, lifted her head with a gentle, sentient smile.</p>
  `,

  // That Time I Got Reincarnated as a Slime
  'ln_sl_1': `
    <p>It was cold. Very cold. And then, surprisingly, it wasn't.</p>
    <p>Satoru Mikami tried to open his eyes, but he couldn't find them. In fact, he couldn't find his hands, his legs, or even his nose. When he attempted to take a step, his body squished forward with an elastic, watery wobble.</p>
    <p>“Wait… am I a round ball of jelly?”</p>
    <p>[Confirmed. Analysis complete. Race: Slime. Unique Skill: Great Sage acquired. Unique Skill: Predator acquired.]</p>
    <p>A tranquil, synthesized voice resonated directly within his mind. Surrounded by glowing magical crystals in a subterranean cavern, Rimuru Tempest’s new life had officially begun.</p>
  `,

  // Chrysalis
  'sh_chrys_1': `
    <p>Darkness. Cramped, claustrophobic darkness.</p>
    <p>Anthony pushed outward against the curved, leathery wall that enclosed him. With a sharp crack, the shell gave way, and he tumbled out onto damp, bioluminescent moss.</p>
    <p>“Wait… why do I have six jointed legs? And what are these twitching antennae on my head?”</p>
    <p>A translucent blue screen flashed in his multifaceted eyes: [Level 1 Worker Ant. Core Affinity: Earth. Welcome to the Pangera Dungeon.]</p>
    <p>Anthony stared down at his shiny red exoskeleton and clacked his razor-sharp mandibles together. “Well,” he thought cheerfully, “at least I don't have to pay rent anymore!”</p>
  `,
};
