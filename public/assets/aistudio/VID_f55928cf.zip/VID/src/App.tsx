import React, { useState, useEffect, useCallback } from 'react';
import {
  BookMarked,
  Compass,
  Globe,
  Settings as SettingsIcon,
  FileUp,
  Moon,
  Sparkles,
  Zap,
  User,
  History,
  Smartphone,
  Download,
} from 'lucide-react';
import { Novel, ReaderSettings, ChapterContent, ReadingStats } from './types/novel';
import {
  getAllNovels,
  saveNovel,
  deleteNovel,
  loadReaderSettings,
  saveReaderSettings,
  getEpubBlob,
  getReadingStats,
  recordReadingHistory,
} from './utils/storage';
import { INITIAL_EXTENSIONS } from './data/extensions';
import { parseEpubFile } from './utils/epubParser';
import { LibraryView } from './components/LibraryView';
import { ExtensionsView } from './components/ExtensionsView';
import { ReaderModeBrowser } from './components/ReaderModeBrowser';
import { SettingsView } from './components/SettingsView';
import { ReaderView } from './components/ReaderView';
import { EpubUploadModal } from './components/EpubUploadModal';
import { SharedNovelModal } from './components/SharedNovelModal';
import { MeView } from './components/MeView';
import { ReadingHistoryView } from './components/ReadingHistoryView';
import { AndroidPublishModal } from './components/AndroidPublishModal';
import { usePWAInstall } from './utils/usePWAInstall';
import { parseSharedNovelFromUrl, clearShareParamFromUrl } from './utils/shareUtils';
import { THEME_STYLES, ACCENT_HEX_MAP } from './utils/themeConfig';
import {
  isAndroidNative,
  setNativeStatusBarTheme,
  getPendingEpubFromIntent,
} from './utils/androidBridge';

export default function App() {
  const [activeTab, setActiveTab] = useState<'library' | 'history' | 'discover' | 'browser' | 'me' | 'settings'>('library');
  const [novels, setNovels] = useState<Novel[]>([]);
  const [settings, setSettings] = useState<ReaderSettings | null>(null);
  const [stats, setStats] = useState<ReadingStats>(getReadingStats());

  // Active Reader state
  const [readingNovel, setReadingNovel] = useState<Novel | null>(null);
  const [readingChapterIndex, setReadingChapterIndex] = useState(0);
  const [epubGetter, setEpubGetter] = useState<((idx: number) => Promise<ChapterContent>) | undefined>();

  // EPUB Import Modal
  const [isEpubModalOpen, setIsEpubModalOpen] = useState(false);

  // Android Native & Store Publishing Studio Modal
  const [isAndroidPublishModalOpen, setIsAndroidPublishModalOpen] = useState(false);
  const { isInstallable, isInstalled } = usePWAInstall();
  const isNative = isAndroidNative();

  // Shared Novel link handler modal
  const [sharedNovelFromUrl, setSharedNovelFromUrl] = useState<Novel | null>(null);

  // Check for shared novel parameter on mount
  useEffect(() => {
    const shared = parseSharedNovelFromUrl();
    if (shared) {
      setSharedNovelFromUrl(shared);
    }
  }, []);

  // Load Library & Settings on mount
  const refreshLibrary = useCallback(async () => {
    const loadedNovels = await getAllNovels();
    if (loadedNovels.length === 0) {
      // Seed with initial sample novels from Royal Road & Gutenberg
      const sample1 = INITIAL_EXTENSIONS[0].novels[0]; // Mother of Learning
      const sample2 = INITIAL_EXTENSIONS[1].novels[0]; // Frankenstein
      await saveNovel(sample1);
      await saveNovel(sample2);
      setNovels([sample1, sample2]);
    } else {
      setNovels(loadedNovels);
    }
    setStats(getReadingStats());
  }, []);

  useEffect(() => {
    loadReaderSettings().then((s) => setSettings(s));
    refreshLibrary();
  }, [refreshLibrary]);

  const handleUpdateSettings = useCallback((newSettings: ReaderSettings) => {
    setSettings(newSettings);
    saveReaderSettings(newSettings);
  }, []);

  const handleNovelAddedToLibrary = (novel: Novel) => {
    setNovels((prev) => {
      const existing = prev.find((n) => n.id === novel.id);
      if (existing) {
        return prev.map((n) => (n.id === novel.id ? novel : n));
      }
      return [novel, ...prev];
    });
  };

  const handleAddToLibraryFromShare = async (novel: Novel) => {
    await saveNovel(novel);
    handleNovelAddedToLibrary(novel);
    clearShareParamFromUrl();
  };

  const handleReadSharedImmediately = async (novel: Novel) => {
    await saveNovel(novel);
    handleNovelAddedToLibrary(novel);
    clearShareParamFromUrl();
    setSharedNovelFromUrl(null);
    handleOpenReader(novel, 0);
  };

  const handleDeleteNovel = async (novelId: string) => {
    await deleteNovel(novelId);
    setNovels((prev) => prev.filter((n) => n.id !== novelId));
  };

  const handleUpdateNovelProgress = useCallback(
    (
      novelId: string,
      chapterIndex: number,
      progressPercent: number,
      paragraphIndex?: number
    ) => {
      setNovels((prev) => {
        const target = prev.find((n) => n.id === novelId);
        if (
          target &&
          target.currentChapterIndex === chapterIndex &&
          Math.abs((target.currentProgressPercent || 0) - progressPercent) < 2 &&
          target.currentParagraphIndex === paragraphIndex
        ) {
          // No significant change, return existing array reference to prevent re-renders
          return prev;
        }

        return prev.map((n) => {
          if (n.id === novelId) {
            const updated: Novel = {
              ...n,
              currentChapterIndex: chapterIndex,
              currentProgressPercent: progressPercent,
              currentParagraphIndex:
                paragraphIndex !== undefined ? paragraphIndex : n.currentParagraphIndex,
              lastReadAt: Date.now(),
            };
            saveNovel(updated);

            // Record in Reading History when chapter changes or on notable progress milestones
            if (
              !target ||
              target.currentChapterIndex !== chapterIndex ||
              Math.abs((target.currentProgressPercent || 0) - progressPercent) >= 15
            ) {
              const chMeta = n.chapters[chapterIndex];
              const chTitle = chMeta?.title || `Chapter ${chapterIndex + 1}`;
              recordReadingHistory({
                novelId: n.id,
                novelTitle: n.title,
                novelCoverUrl: n.coverUrl,
                novelAuthor: n.author,
                chapterIndex,
                chapterTitle: chTitle,
                progressPercent,
                paragraphIndex:
                  paragraphIndex !== undefined ? paragraphIndex : n.currentParagraphIndex,
              });
            }

            return updated;
          }
          return n;
        });
      });
    },
    []
  );

  // Open novel in reader (with auto-resume of EPUB if stored in IndexedDB)
  const handleOpenReader = async (novel: Novel, initialChapterIndex: number) => {
    if (novel.sourceType === 'epub') {
      try {
        const storedBlob = await getEpubBlob(novel.id);
        if (storedBlob) {
          const parsed = await parseEpubFile(storedBlob, novel.title);
          setEpubGetter(() => parsed.getChapterContent);
        }
      } catch (err) {
        console.warn('Could not re-parse EPUB blob:', err);
      }
    } else {
      setEpubGetter(undefined);
    }

    // Record open chapter in reading history
    const chMeta = novel.chapters[initialChapterIndex];
    const chTitle = chMeta?.title || `Chapter ${initialChapterIndex + 1}`;
    recordReadingHistory({
      novelId: novel.id,
      novelTitle: novel.title,
      novelCoverUrl: novel.coverUrl,
      novelAuthor: novel.author,
      chapterIndex: initialChapterIndex,
      chapterTitle: chTitle,
      progressPercent:
        novel.currentChapterIndex === initialChapterIndex ? novel.currentProgressPercent || 0 : 0,
      paragraphIndex:
        novel.currentChapterIndex === initialChapterIndex ? novel.currentParagraphIndex : 0,
    });

    setReadingNovel(novel);
    setReadingChapterIndex(initialChapterIndex);
  };

  const handleEpubImported = useCallback(
    (novel: Novel, chapterGetter: (idx: number) => Promise<ChapterContent>) => {
      handleNovelAddedToLibrary(novel);
      setEpubGetter(() => chapterGetter);
      setReadingNovel(novel);
      setReadingChapterIndex(0);
    },
    []
  );

  // Android Native Intent handler for opening .epub files directly from file managers
  useEffect(() => {
    const processPendingEpub = async () => {
      const pending = getPendingEpubFromIntent();
      if (pending && pending.blob) {
        try {
          const cleanTitle = pending.fileName.replace(/\.epub$/i, '').trim();
          const parsed = await parseEpubFile(pending.blob, cleanTitle || 'Imported EPUB');
          handleEpubImported(parsed.novel, parsed.getChapterContent);
        } catch (err) {
          console.error('Error parsing Android Intent EPUB:', err);
        }
      }
    };

    processPendingEpub();
    window.__onAndroidBridgeReady = processPendingEpub;
    window.__handleAndroidEpubImport = (_fileName: string) => {
      processPendingEpub();
    };

    return () => {
      window.__onAndroidBridgeReady = undefined;
      window.__handleAndroidEpubImport = undefined;
    };
  }, [handleEpubImported]);

  // Android System Back Button Intercept
  useEffect(() => {
    window.__androidHandleBack = () => {
      if (readingNovel) {
        setReadingNovel(null);
        refreshLibrary();
        return true;
      }
      if (isAndroidPublishModalOpen) {
        setIsAndroidPublishModalOpen(false);
        return true;
      }
      if (isEpubModalOpen) {
        setIsEpubModalOpen(false);
        return true;
      }
      return false;
    };

    return () => {
      window.__androidHandleBack = undefined;
    };
  }, [readingNovel, isAndroidPublishModalOpen, isEpubModalOpen, refreshLibrary]);

  const savedNovelIds = new Set(novels.map((n) => n.id));

  if (!settings) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // Active Reader Fullscreen View
  if (readingNovel) {
    return (
      <ReaderView
        novel={readingNovel}
        initialChapterIndex={readingChapterIndex}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        onUpdateNovelProgress={handleUpdateNovelProgress}
        onClose={() => {
          setReadingNovel(null);
          refreshLibrary();
        }}
        epubChapterGetter={epubGetter}
      />
    );
  }

  const activeTheme = settings?.theme || 'liquid-glass';
  const themeStyle = THEME_STYLES[activeTheme] || THEME_STYLES['liquid-glass'];
  const accentHex = ACCENT_HEX_MAP[settings?.accentColor || 'cyan'] || '#06b6d4';
  const isGlassApp = settings?.appWideTheme && (activeTheme === 'liquid-glass' || themeStyle.isGlass);

  return (
    <div
      className={`min-h-screen text-neutral-100 flex flex-col transition-colors duration-200 relative overflow-x-hidden ${
        isGlassApp ? 'bg-[#0b0f1c]' : 'bg-neutral-950'
      }`}
      style={{
        backgroundImage:
          isGlassApp
            ? 'radial-gradient(circle at 10% 20%, rgba(56, 189, 248, 0.08) 0%, transparent 40%), radial-gradient(circle at 90% 80%, rgba(139, 92, 246, 0.08) 0%, transparent 40%)'
            : undefined,
      }}
    >
      {/* Ambient background glow orbs for Liquid Glass */}
      {isGlassApp && settings?.ambientAura !== false && (
        <>
          <div className="fixed -top-24 -left-24 w-96 h-96 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none -z-10" />
          <div className="fixed -bottom-24 -right-24 w-96 h-96 rounded-full bg-purple-500/10 blur-3xl pointer-events-none -z-10" />
        </>
      )}

      {/* Top Main Navigation Header */}
      <header
        className={`sticky top-0 z-40 px-4 sm:px-6 py-3 border-b transition-all duration-200 safe-top-padding ${
          isGlassApp
            ? 'bg-neutral-950/70 backdrop-blur-xl border-white/10 shadow-lg shadow-black/20'
            : 'bg-neutral-950/80 backdrop-blur-md border-neutral-900'
        }`}
      >
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center font-bold shadow-lg transition active:scale-95 cursor-pointer"
              style={{
                backgroundColor: isGlassApp ? 'rgba(56, 189, 248, 0.2)' : accentHex,
                border: isGlassApp ? '1px solid rgba(255, 255, 255, 0.2)' : undefined,
                color: isGlassApp ? accentHex : '#000',
              }}
              onClick={() => setActiveTab('library')}
            >
              <Zap className="w-5 h-5 fill-current" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-base tracking-tight text-neutral-100 cursor-pointer" onClick={() => setActiveTab('library')}>
                  Aether<span style={{ color: accentHex }}>Novel</span>
                </span>
                <span
                  className="hidden sm:inline-block px-2 py-0.5 rounded-full border text-[10px] font-mono"
                  style={{
                    backgroundColor: isGlassApp ? 'rgba(255, 255, 255, 0.05)' : '#171717',
                    borderColor: isGlassApp ? 'rgba(255, 255, 255, 0.1)' : '#262626',
                    color: isGlassApp ? '#38bdf8' : '#a3a3a3',
                  }}
                >
                  {isGlassApp ? 'Liquid Glass' : 'QuickNovel Core'}
                </span>
              </div>
              <p className="text-[10px] text-neutral-500 hidden sm:block">
                EPUB & Web Novel Reader • History & Offline Reading
              </p>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav
            className={`hidden md:flex items-center gap-1 p-1 rounded-xl border text-xs ${
              isGlassApp
                ? 'bg-white/5 backdrop-blur-md border-white/10'
                : 'bg-neutral-900/90 border-neutral-800'
            }`}
          >
            {[
              { id: 'library', label: 'Library', icon: BookMarked, badge: novels.length },
              { id: 'history', label: 'History', icon: History },
              { id: 'discover', label: 'Discover', icon: Compass },
              { id: 'browser', label: 'Web to Book', icon: Globe },
              { id: 'me', label: 'Me', icon: User },
              { id: 'settings', label: 'Settings', icon: SettingsIcon },
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 font-medium transition ${
                    isActive
                      ? 'font-bold shadow-sm'
                      : 'text-neutral-400 hover:text-neutral-200'
                  }`}
                  style={{
                    backgroundColor: isActive ? accentHex : undefined,
                    color: isActive ? '#09090b' : undefined,
                  }}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                  {tab.badge !== undefined && tab.badge > 0 && (
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                        isActive ? 'bg-neutral-950/20 text-neutral-950' : 'bg-neutral-800 text-neutral-400'
                      }`}
                    >
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Action Buttons: Import EPUB & Android App / Publishing Hub */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsAndroidPublishModalOpen(true)}
              className={`px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition active:scale-95 shadow-sm ${
                isNative
                  ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                  : isInstalled
                  ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                  : isGlassApp
                  ? 'bg-white/5 hover:bg-white/10 border-white/15 text-cyan-300'
                  : 'bg-neutral-900 hover:bg-neutral-800 border-neutral-800 text-neutral-300'
              }`}
              title="Android Native App, Google Play AAB & F-Droid Publishing Hub"
            >
              <Smartphone className="w-4 h-4 text-amber-400" />
              <span className="hidden sm:inline">
                {isNative ? 'Native Android' : isInstalled ? 'Installed App' : 'Android & Stores'}
              </span>
            </button>

            <button
              onClick={() => setIsEpubModalOpen(true)}
              className={`px-3 py-1.5 sm:py-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition active:scale-95 shadow-sm ${
                isGlassApp
                  ? 'bg-white/5 hover:bg-white/10 border-white/15 text-cyan-300'
                  : 'bg-neutral-900 hover:bg-neutral-800 border-neutral-800 text-amber-400'
              }`}
              title="Upload EPUB E-Book file"
            >
              <FileUp className="w-4 h-4" />
              <span className="hidden sm:inline">Import EPUB</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Body Content */}
      <main className="flex-1 pb-20 md:pb-8 flex flex-col">
        {activeTab === 'library' && (
          <LibraryView
            novels={novels}
            stats={stats}
            settings={settings}
            onOpenReader={handleOpenReader}
            onDeleteNovel={handleDeleteNovel}
            onUpdateNovel={(updated) => {
              setNovels((prev) => prev.map((n) => (n.id === updated.id ? updated : n)));
            }}
            onNavigateTab={setActiveTab}
            onTriggerEpubUpload={() => setIsEpubModalOpen(true)}
          />
        )}

        {activeTab === 'history' && (
          <ReadingHistoryView
            novels={novels}
            settings={settings}
            stats={stats}
            onOpenReader={handleOpenReader}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'discover' && (
          <ExtensionsView
            onOpenReader={handleOpenReader}
            onNovelAddedToLibrary={handleNovelAddedToLibrary}
            savedNovelIds={savedNovelIds}
          />
        )}

        {activeTab === 'browser' && (
          <ReaderModeBrowser
            onOpenReader={handleOpenReader}
            onNovelAddedToLibrary={handleNovelAddedToLibrary}
          />
        )}

        {activeTab === 'me' && (
          <MeView
            stats={stats}
            novels={novels}
            settings={settings}
            onOpenReader={handleOpenReader}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
            onRefreshLibrary={refreshLibrary}
            onOpenPwaModal={() => setIsAndroidPublishModalOpen(true)}
          />
        )}
      </main>

      {/* Mobile Bottom Navigation Bar */}
      <nav
        className={`md:hidden fixed bottom-0 left-0 right-0 z-40 px-2 py-1.5 flex items-center justify-around border-t transition-all duration-200 safe-bottom-padding ${
          isGlassApp
            ? 'bg-neutral-950/80 backdrop-blur-xl border-white/10 shadow-lg shadow-black/30'
            : 'bg-neutral-950/95 backdrop-blur-lg border-neutral-900'
        }`}
      >
        {[
          { id: 'library', label: 'Library', icon: BookMarked },
          { id: 'history', label: 'History', icon: History },
          { id: 'discover', label: 'Discover', icon: Compass },
          { id: 'browser', label: 'Web', icon: Globe },
          { id: 'me', label: 'Me', icon: User },
          { id: 'settings', label: 'Settings', icon: SettingsIcon },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className="flex flex-col items-center gap-0.5 p-1 rounded-lg text-xs transition flex-1 min-w-0"
              style={{
                color: isActive ? accentHex : '#737373',
                fontWeight: isActive ? 600 : 400,
              }}
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              <span className="text-[9px] truncate max-w-full">{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* EPUB Upload Modal */}
      <EpubUploadModal
        isOpen={isEpubModalOpen}
        onClose={() => setIsEpubModalOpen(false)}
        onNovelImported={handleEpubImported}
      />

      {/* Android Native & App Store Publishing Studio Modal */}
      <AndroidPublishModal
        isOpen={isAndroidPublishModalOpen}
        onClose={() => setIsAndroidPublishModalOpen(false)}
      />

      {/* Shared Novel from URL Modal */}
      {sharedNovelFromUrl && (
        <SharedNovelModal
          sharedNovel={sharedNovelFromUrl}
          onClose={() => {
            setSharedNovelFromUrl(null);
            clearShareParamFromUrl();
          }}
          onAddToLibrary={handleAddToLibraryFromShare}
          onReadImmediately={handleReadSharedImmediately}
        />
      )}
    </div>
  );
}
