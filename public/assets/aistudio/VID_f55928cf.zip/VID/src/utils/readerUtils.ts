// Bionic reading converts words so the first 40-50% of each word is bolded
export function applyBionicReading(html: string): string {
  // Use a temporary parser to avoid breaking HTML tags
  const tempDiv = document.createElement('div');
  tempDiv.innerHTML = html;

  function processNode(node: Node) {
    if (node.nodeType === Node.TEXT_NODE && node.nodeValue) {
      const text = node.nodeValue;
      if (!text.trim()) return;

      const words = text.split(/(\s+)/);
      const span = document.createElement('span');

      words.forEach((word) => {
        if (/^\s+$/.test(word) || word.length === 0) {
          span.appendChild(document.createTextNode(word));
        } else {
          const splitLen = Math.ceil(word.length * 0.45);
          const boldPart = word.substring(0, splitLen);
          const restPart = word.substring(splitLen);

          const b = document.createElement('b');
          b.className = 'font-bold tracking-tight';
          b.textContent = boldPart;

          span.appendChild(b);
          span.appendChild(document.createTextNode(restPart));
        }
      });

      node.parentNode?.replaceChild(span, node);
    } else if (node.nodeType === Node.ELEMENT_NODE) {
      const elem = node as HTMLElement;
      // Do not touch headings, scripts or code
      if (['SCRIPT', 'STYLE', 'CODE', 'PRE'].includes(elem.tagName)) return;
      Array.from(node.childNodes).forEach(processNode);
    }
  }

  Array.from(tempDiv.childNodes).forEach(processNode);
  return tempDiv.innerHTML;
}

// Format seconds into readable "X hrs Y mins"
export function formatReadingTime(seconds: number): string {
  if (seconds < 60) return `${Math.floor(seconds)}s`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes} min${minutes > 1 ? 's' : ''}`;
  const hours = Math.floor(minutes / 60);
  const remMinutes = minutes % 60;
  return `${hours}h ${remMinutes}m`;
}
