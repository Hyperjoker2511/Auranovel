import { ReaderTheme, AccentColor } from '../types/novel';

export interface ThemeColors {
  bg: string;
  text: string;
  accent: string;
  secondaryText: string;
  border: string;
  controlBg: string;
  headerBg: string;
  isGlass?: boolean;
  cardBg?: string;
  glowShadow?: string;
}

export const THEME_STYLES: Record<ReaderTheme, ThemeColors> = {
  'liquid-glass': {
    bg: 'rgba(11, 15, 28, 0.85)',
    text: '#f3f4f6',
    accent: '#38bdf8',
    secondaryText: '#94a3b8',
    border: 'rgba(255, 255, 255, 0.15)',
    controlBg: 'rgba(255, 255, 255, 0.08)',
    headerBg: 'rgba(11, 15, 28, 0.65)',
    isGlass: true,
    cardBg: 'rgba(255, 255, 255, 0.06)',
    glowShadow: '0 8px 32px 0 rgba(0, 0, 0, 0.37), inset 0 1px 1px 0 rgba(255, 255, 255, 0.15)',
  },
  oled: {
    bg: '#000000',
    text: '#d4d4d8',
    accent: '#38bdf8',
    secondaryText: '#71717a',
    border: '#222225',
    controlBg: '#09090b',
    headerBg: '#000000',
  },
  dark: {
    bg: '#14161b',
    text: '#e2e8f0',
    accent: '#60a5fa',
    secondaryText: '#94a3b8',
    border: '#1e2430',
    controlBg: '#1a1f2c',
    headerBg: '#14161b',
  },
  midnight: {
    bg: '#0a0f1d',
    text: '#c9d3e6',
    accent: '#818cf8',
    secondaryText: '#64748b',
    border: '#151e36',
    controlBg: '#10182b',
    headerBg: '#0a0f1d',
  },
  nordic: {
    bg: '#181e29',
    text: '#e2e8f0',
    accent: '#38bdf8',
    secondaryText: '#78889e',
    border: '#242e3f',
    controlBg: '#1f2736',
    headerBg: '#181e29',
  },
  cyberpunk: {
    bg: '#080811',
    text: '#38bdf8',
    accent: '#ec4899',
    secondaryText: '#7c8ba1',
    border: '#231b3e',
    controlBg: '#130d24',
    headerBg: '#080811',
  },
  'crimson-void': {
    bg: '#0e0507',
    text: '#fecdd3',
    accent: '#f43f5e',
    secondaryText: '#9f7179',
    border: '#2c1017',
    controlBg: '#1a080d',
    headerBg: '#0e0507',
  },
  mocha: {
    bg: '#1c1715',
    text: '#ebdcd3',
    accent: '#d97706',
    secondaryText: '#8f7b73',
    border: '#2e2622',
    controlBg: '#251e1b',
    headerBg: '#1c1715',
  },
  rose: {
    bg: '#1c1216',
    text: '#ebd5dc',
    accent: '#f43f5e',
    secondaryText: '#876973',
    border: '#2e1e24',
    controlBg: '#25171d',
    headerBg: '#1c1216',
  },
  sepia: {
    bg: '#f7eedc',
    text: '#3d2e1e',
    accent: '#b45309',
    secondaryText: '#786550',
    border: '#e4d4ba',
    controlBg: '#eee2cb',
    headerBg: '#f7eedc',
  },
  parchment: {
    bg: '#fdf6e2',
    text: '#2f281e',
    accent: '#d97706',
    secondaryText: '#6b5e4d',
    border: '#ebdcb9',
    controlBg: '#f3e8cb',
    headerBg: '#fdf6e2',
  },
  matcha: {
    bg: '#f2f6ee',
    text: '#243322',
    accent: '#15803d',
    secondaryText: '#5f755d',
    border: '#dbe5d4',
    controlBg: '#e6ede0',
    headerBg: '#f2f6ee',
  },
  light: {
    bg: '#fafafa',
    text: '#18181b',
    accent: '#2563eb',
    secondaryText: '#71717a',
    border: '#e4e4e7',
    controlBg: '#f4f4f5',
    headerBg: '#fafafa',
  },
};

export const ACCENT_HEX_MAP: Record<AccentColor, string> = {
  amber: '#f59e0b',
  emerald: '#10b981',
  cyan: '#06b6d4',
  violet: '#8b5cf6',
  rose: '#f43f5e',
  orange: '#f97316',
  'neon-pink': '#ec4899',
  'lime-gold': '#84cc16',
};
