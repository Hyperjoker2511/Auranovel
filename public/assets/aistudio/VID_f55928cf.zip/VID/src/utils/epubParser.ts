import JSZip from 'jszip';
import { Novel, ChapterMeta, ChapterContent } from '../types/novel';

export interface ParsedEpub {
  novel: Novel;
  getChapterContent: (chapterIndex: number) => Promise<ChapterContent>;
}

export async function parseEpubFile(file: File | Blob | ArrayBuffer, fileName: string): Promise<ParsedEpub> {
  const zip = new JSZip();
  const loadedZip = await zip.loadAsync(file);

  // 1. Locate container.xml to find OPF path
  const containerFile = loadedZip.file('META-INF/container.xml');
  if (!containerFile) {
    throw new Error('Invalid EPUB: META-INF/container.xml not found.');
  }

  const containerXml = await containerFile.async('text');
  const domParser = new DOMParser();
  const containerDoc = domParser.parseFromString(containerXml, 'application/xml');
  const rootfile = containerDoc.querySelector('rootfile');
  const opfPath = rootfile?.getAttribute('full-path');

  if (!opfPath) {
    throw new Error('Invalid EPUB: Rootfile OPF path not found in container.xml.');
  }

  // Determine base folder of OPF
  const opfDir = opfPath.includes('/') ? opfPath.substring(0, opfPath.lastIndexOf('/') + 1) : '';

  // 2. Load OPF Package document
  const opfFile = loadedZip.file(opfPath);
  if (!opfFile) {
    throw new Error(`Invalid EPUB: OPF file not found at ${opfPath}`);
  }

  const opfXml = await opfFile.async('text');
  const opfDoc = domParser.parseFromString(opfXml, 'application/xml');

  // Metadata extraction
  const title =
    opfDoc.querySelector('title, dc\\:title')?.textContent?.trim() ||
    fileName.replace(/\.epub$/i, '') ||
    'Untitled EPUB';

  const author =
    opfDoc.querySelector('creator, dc\\:creator')?.textContent?.trim() ||
    'Unknown Author';

  const description =
    opfDoc.querySelector('description, dc\\:description')?.textContent?.trim() ||
    'No description available in EPUB metadata.';

  // Build manifest map: id -> { href, mediaType }
  const manifestItems = new Map<string, { href: string; mediaType: string; fullPath: string }>();
  const items = opfDoc.querySelectorAll('manifest > item');
  let coverHref: string | null = null;
  let coverId: string | null = null;

  // Check for meta[name="cover"]
  const coverMeta = opfDoc.querySelector('meta[name="cover"]');
  if (coverMeta) {
    coverId = coverMeta.getAttribute('content');
  }

  items.forEach((item) => {
    const id = item.getAttribute('id') || '';
    const href = item.getAttribute('href') || '';
    const mediaType = item.getAttribute('media-type') || '';
    const properties = item.getAttribute('properties') || '';
    const fullPath = opfDir + href;

    manifestItems.set(id, { href, mediaType, fullPath });

    if (id === coverId || properties.includes('cover-image') || href.toLowerCase().includes('cover')) {
      if (!coverHref && (mediaType.startsWith('image/') || /\.(jpe?g|png|webp|gif)$/i.test(href))) {
        coverHref = fullPath;
      }
    }
  });

  // Extract cover image as persistent Data URL if available
  let coverUrl: string | undefined = undefined;
  if (coverHref) {
    const coverZipFile = loadedZip.file(coverHref) || loadedZip.file(decodeURIComponent(coverHref));
    if (coverZipFile) {
      try {
        const base64 = await coverZipFile.async('base64');
        const lower = coverHref.toLowerCase();
        const mime = lower.endsWith('.png')
          ? 'image/png'
          : lower.endsWith('.webp')
          ? 'image/webp'
          : lower.endsWith('.gif')
          ? 'image/gif'
          : 'image/jpeg';
        coverUrl = `data:${mime};base64,${base64}`;
      } catch (err) {
        console.warn('Failed to load EPUB cover image:', err);
      }
    }
  }

  // 3. Process TOC (NCX or Nav)
  const tocTitles = new Map<string, string>();
  const ncxItem = Array.from(manifestItems.values()).find(
    (item) => item.mediaType === 'application/x-dtbncx+xml' || item.href.endsWith('.ncx')
  );

  if (ncxItem) {
    const ncxZipFile = loadedZip.file(ncxItem.fullPath);
    if (ncxZipFile) {
      const ncxXml = await ncxZipFile.async('text');
      const ncxDoc = domParser.parseFromString(ncxXml, 'application/xml');
      const navPoints = ncxDoc.querySelectorAll('navPoint');
      navPoints.forEach((np) => {
        const navLabel = np.querySelector('navLabel > text')?.textContent?.trim();
        const contentSrc = np.querySelector('content')?.getAttribute('src');
        if (navLabel && contentSrc) {
          // Normalize href by stripping hash
          const cleanSrc = contentSrc.split('#')[0];
          tocTitles.set(cleanSrc, navLabel);
        }
      });
    }
  }

  // 4. Parse Spine to get sequential chapter reading list
  const spineItemRefs = opfDoc.querySelectorAll('spine > itemref');
  const chapters: ChapterMeta[] = [];
  const novelId = 'epub_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);

  let chapterIndex = 0;
  for (let i = 0; i < spineItemRefs.length; i++) {
    const idref = spineItemRefs[i].getAttribute('idref');
    if (!idref) continue;

    const manifestItem = manifestItems.get(idref);
    if (!manifestItem) continue;

    // Filter out obvious cover pages or non-reading documents if empty
    const href = manifestItem.href;
    const cleanHref = href.split('#')[0];
    const fullPath = manifestItem.fullPath;

    let titleText = tocTitles.get(cleanHref) || tocTitles.get(href);
    if (!titleText) {
      // Create provisional title from index
      titleText = `Chapter ${chapterIndex + 1}`;
    }

    chapters.push({
      id: `${novelId}_ch_${chapterIndex}`,
      novelId,
      index: chapterIndex,
      title: titleText,
      href: fullPath,
      isDownloaded: true, // Local EPUBs are intrinsically offline!
    });

    chapterIndex++;
  }

  // Cache of extracted chapter content
  const chapterCache = new Map<number, ChapterContent>();

  const getChapterContent = async (index: number): Promise<ChapterContent> => {
    if (chapterCache.has(index)) {
      return chapterCache.get(index)!;
    }

    const meta = chapters[index];
    if (!meta || !meta.href) {
      throw new Error(`Chapter ${index} not found in EPUB.`);
    }

    const chapterFile = loadedZip.file(meta.href) || loadedZip.file(decodeURIComponent(meta.href));
    if (!chapterFile) {
      throw new Error(`Chapter file ${meta.href} missing from EPUB zip.`);
    }

    const rawHtml = await chapterFile.async('text');
    const chapterDoc = domParser.parseFromString(rawHtml, 'text/html');

    // Extract better title if present in h1/h2
    const h1 = chapterDoc.querySelector('h1, h2, h3, title');
    if (h1 && h1.textContent?.trim() && meta.title.startsWith('Chapter ')) {
      const extractedTitle = h1.textContent.trim();
      if (extractedTitle.length < 100) {
        meta.title = extractedTitle;
      }
    }

    // Resolve internal images to inline Blob URLs
    const chapterDir = meta.href.includes('/')
      ? meta.href.substring(0, meta.href.lastIndexOf('/') + 1)
      : '';

    const imgElements = chapterDoc.querySelectorAll('img, image');
    for (let i = 0; i < imgElements.length; i++) {
      const img = imgElements[i];
      const src = img.getAttribute('src') || img.getAttribute('xlink:href');
      if (src && !src.startsWith('data:') && !src.startsWith('http')) {
        const normalizedSrc = (chapterDir + src).replace(/\/\.\//g, '/');
        const imgZip = loadedZip.file(normalizedSrc) || loadedZip.file(decodeURIComponent(normalizedSrc));
        if (imgZip) {
          try {
            const blob = await imgZip.async('blob');
            const blobUrl = URL.createObjectURL(blob);
            img.setAttribute('src', blobUrl);
          } catch (e) {
            console.warn('Failed to resolve EPUB embedded image:', src, e);
          }
        }
      }
    }

    // Strip style tags or script tags that could break layout
    chapterDoc.querySelectorAll('script, style, link[rel="stylesheet"]').forEach((el) => el.remove());

    const bodyContent = chapterDoc.body?.innerHTML || rawHtml;
    const cleanText = chapterDoc.body?.textContent?.replace(/\s+/g, ' ').trim() || '';
    const wordCount = cleanText.split(/\s+/).filter(Boolean).length;

    const result: ChapterContent = {
      id: meta.id,
      novelId,
      index,
      title: meta.title,
      contentHtml: bodyContent,
      text: cleanText,
      wordCount,
      cachedAt: Date.now(),
    };

    chapterCache.set(index, result);
    return result;
  };

  const novel: Novel = {
    id: novelId,
    title,
    author,
    coverUrl,
    description,
    genres: ['EPUB', 'E-Book'],
    sourceType: 'epub',
    sourceName: 'Local EPUB File',
    status: 'reading',
    currentChapterIndex: 0,
    currentProgressPercent: 0,
    totalChapters: chapters.length,
    chapters,
    lastReadAt: Date.now(),
    createdAt: Date.now(),
  };

  return {
    novel,
    getChapterContent,
  };
}
