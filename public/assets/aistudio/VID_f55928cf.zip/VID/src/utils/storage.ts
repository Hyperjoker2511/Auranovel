import { Novel, ChapterContent, ReaderSettings, Bookmark, ReadingStats, UserProfile, ReadingHistoryEntry } from '../types/novel';

const DB_NAME = 'AetherNovelDB';
const DB_VERSION = 2;
const STORE_NOVELS = 'novels';
const STORE_CHAPTERS = 'chapter_contents';
const STORE_FILES = 'epub_files';
const STORE_SETTINGS = 'settings';

export const DEFAULT_SETTINGS: ReaderSettings = {
  theme: 'liquid-glass',
  accentColor: 'cyan',
  appWideTheme: true,
  glassBlurIntensity: 'high',
  ambientAura: true,
  fontFamily: 'Literata',
  fontSize: 18,
  fontWeight: 'normal',
  lineHeight: 1.7,
  letterSpacing: 0,
  maxWidth: 780,
  textAlign: 'left',
  paragraphSpacing: 1.2,
  indentParagraphs: true,
  dropCaps: false,
  readingMode: 'scroll',
  pageTransition: 'slide',
  twoColumnTablet: true,
  readingRuler: false,
  warmScreenTint: 0,
  soundEffects: true,
  hapticFeedback: true,
  tapZoneMode: 'standard',
  volumeKeyNavigation: false,
  autoLoadNextChapter: true,
  lowSpecMode: false,
  brightness: 100,
  autoScrollSpeed: 3,
  bionicReading: false,
  bionicStrength: 45,
  oledPureBlack: false,
  ttsSpeed: 1.0,
  ttsPitch: 1.0,
  wpmReadingSpeed: 240,
  aiModelProvider: 'gemini-3.8-flash',
};

let dbPromise: Promise<IDBDatabase> | null = null;

function getDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB not supported in this environment'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NOVELS)) {
        db.createObjectStore(STORE_NOVELS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_CHAPTERS)) {
        const chapterStore = db.createObjectStore(STORE_CHAPTERS, { keyPath: 'id' });
        chapterStore.createIndex('novelId', 'novelId', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_FILES)) {
        db.createObjectStore(STORE_FILES);
      }
      if (!db.objectStoreNames.contains(STORE_SETTINGS)) {
        db.createObjectStore(STORE_SETTINGS);
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => {
      console.error('IndexedDB open error:', request.error);
      reject(request.error);
    };
  });

  return dbPromise;
}

// ---------------- NOVELS CRUD ----------------

export async function saveNovel(novel: Novel): Promise<void> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NOVELS, 'readwrite');
      tx.objectStore(STORE_NOVELS).put(novel);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // LocalStorage fallback
    const key = `aether_novel_${novel.id}`;
    localStorage.setItem(key, JSON.stringify(novel));
  }
}

export async function getAllNovels(): Promise<Novel[]> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NOVELS, 'readonly');
      const req = tx.objectStore(STORE_NOVELS).getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  } catch {
    const novels: Novel[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key?.startsWith('aether_novel_')) {
        try {
          novels.push(JSON.parse(localStorage.getItem(key)!));
        } catch {}
      }
    }
    return novels;
  }
}

export async function getNovelById(id: string): Promise<Novel | null> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NOVELS, 'readonly');
      const req = tx.objectStore(STORE_NOVELS).get(id);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  } catch {
    const raw = localStorage.getItem(`aether_novel_${id}`);
    return raw ? JSON.parse(raw) : null;
  }
}

export async function deleteNovel(id: string): Promise<void> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction([STORE_NOVELS, STORE_CHAPTERS, STORE_FILES], 'readwrite');
      tx.objectStore(STORE_NOVELS).delete(id);

      // Delete associated chapters
      const chapterStore = tx.objectStore(STORE_CHAPTERS);
      const index = chapterStore.index('novelId');
      const req = index.getAllKeys(id);
      req.onsuccess = () => {
        const keys = req.result;
        keys.forEach((k) => chapterStore.delete(k));
      };

      tx.objectStore(STORE_FILES).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    localStorage.removeItem(`aether_novel_${id}`);
  }
}

// ---------------- CHAPTER CONTENTS & OFFLINE CACHING ----------------

export async function saveChapterContent(content: ChapterContent): Promise<void> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_CHAPTERS, 'readwrite');
      const store = tx.objectStore(STORE_CHAPTERS);
      store.put(content);
      const standardKey = `${content.novelId}_ch_${content.index}`;
      if (content.id !== standardKey) {
        store.put({ ...content, id: standardKey });
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    localStorage.setItem(`aether_ch_${content.id}`, JSON.stringify(content));
    localStorage.setItem(`aether_ch_${content.novelId}_ch_${content.index}`, JSON.stringify(content));
  }
}

export async function getChapterContent(novelId: string, chapterIndex: number): Promise<ChapterContent | null> {
  const chapterId = `${novelId}_ch_${chapterIndex}`;
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_CHAPTERS, 'readonly');
      const store = tx.objectStore(STORE_CHAPTERS);
      const req = store.get(chapterId);
      req.onsuccess = () => {
        if (req.result) {
          resolve(req.result);
          return;
        }
        // Fallback: search via novelId index
        try {
          const index = store.index('novelId');
          const idxReq = index.getAll(novelId);
          idxReq.onsuccess = () => {
            const list: ChapterContent[] = idxReq.result || [];
            const match = list.find((c) => c.index === chapterIndex);
            resolve(match || null);
          };
          idxReq.onerror = () => resolve(null);
        } catch {
          resolve(null);
        }
      };
      req.onerror = () => resolve(null);
    });
  } catch {
    const raw = localStorage.getItem(`aether_ch_${chapterId}`);
    return raw ? JSON.parse(raw) : null;
  }
}

export async function isChapterCached(novelId: string, chapterIndex: number): Promise<boolean> {
  const ch = await getChapterContent(novelId, chapterIndex);
  return ch !== null;
}

export async function getDownloadedChapterIndices(novelId: string): Promise<Set<number>> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_CHAPTERS, 'readonly');
      const index = tx.objectStore(STORE_CHAPTERS).index('novelId');
      const req = index.getAll(novelId);
      req.onsuccess = () => {
        const results: ChapterContent[] = req.result || [];
        resolve(new Set(results.map((r) => r.index)));
      };
      req.onerror = () => reject(req.error);
    });
  } catch {
    return new Set();
  }
}

export async function saveEpubBlob(novelId: string, fileBlob: Blob | ArrayBuffer): Promise<void> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_FILES, 'readwrite');
      tx.objectStore(STORE_FILES).put(fileBlob, novelId);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.error('Failed to store EPUB blob:', err);
  }
}

export async function getEpubBlob(novelId: string): Promise<Blob | ArrayBuffer | null> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_FILES, 'readonly');
      const req = tx.objectStore(STORE_FILES).get(novelId);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  } catch {
    return null;
  }
}

// ---------------- SETTINGS & PREFERENCES ----------------

export async function loadReaderSettings(): Promise<ReaderSettings> {
  try {
    const raw = localStorage.getItem('aether_reader_settings');
    if (raw) {
      return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
    }
  } catch {}
  return DEFAULT_SETTINGS;
}

export function saveReaderSettings(settings: ReaderSettings): void {
  try {
    localStorage.setItem('aether_reader_settings', JSON.stringify(settings));
  } catch (err) {
    console.error('Failed to save settings:', err);
  }
}

// ---------------- BOOKMARKS ----------------

export function getBookmarks(): Bookmark[] {
  try {
    const raw = localStorage.getItem('aether_bookmarks');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveBookmark(bookmark: Bookmark): void {
  const bookmarks = getBookmarks();
  bookmarks.unshift(bookmark);
  localStorage.setItem('aether_bookmarks', JSON.stringify(bookmarks));
}

export function removeBookmark(id: string): void {
  const bookmarks = getBookmarks().filter((b) => b.id !== id);
  localStorage.setItem('aether_bookmarks', JSON.stringify(bookmarks));
}

// ---------------- STATS ----------------

export function getReadingStats(): ReadingStats {
  try {
    const raw = localStorage.getItem('aether_stats');
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        totalSecondsRead: parsed.totalSecondsRead || 0,
        chaptersCompleted: parsed.chaptersCompleted || 0,
        booksFinished: parsed.booksFinished || 0,
        lastActiveDate: parsed.lastActiveDate || new Date().toISOString().split('T')[0],
        weeklyActivity: parsed.weeklyActivity || {},
        currentStreak: parsed.currentStreak || 1,
      };
    }
  } catch {}
  return {
    totalSecondsRead: 0,
    chaptersCompleted: 0,
    booksFinished: 0,
    lastActiveDate: new Date().toISOString().split('T')[0],
    weeklyActivity: {},
    currentStreak: 1,
  };
}

export function updateReadingTime(seconds: number): void {
  const stats = getReadingStats();
  stats.totalSecondsRead += seconds;
  const todayKey = new Date().toISOString().split('T')[0];

  if (!stats.weeklyActivity) stats.weeklyActivity = {};
  stats.weeklyActivity[todayKey] = (stats.weeklyActivity[todayKey] || 0) + seconds;

  // Streak logic
  if (stats.lastActiveDate !== todayKey) {
    const lastDate = new Date(stats.lastActiveDate);
    const currentDate = new Date(todayKey);
    const diffDays = Math.round((currentDate.getTime() - lastDate.getTime()) / (1000 * 3600 * 24));

    if (diffDays === 1) {
      stats.currentStreak = (stats.currentStreak || 1) + 1;
    } else if (diffDays > 1) {
      stats.currentStreak = 1;
    }
    stats.lastActiveDate = todayKey;
  }

  localStorage.setItem('aether_stats', JSON.stringify(stats));
}

export function incrementChapterCompleted(): void {
  const stats = getReadingStats();
  stats.chaptersCompleted += 1;
  localStorage.setItem('aether_stats', JSON.stringify(stats));
}

// ---------------- STORAGE MANAGEMENT & BACKUP ----------------

export async function getStorageEstimate(): Promise<{ totalBytes: number; chapterCount: number }> {
  try {
    const db = await getDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_CHAPTERS, 'readonly');
      const req = tx.objectStore(STORE_CHAPTERS).getAll();
      req.onsuccess = () => {
        const chapters: ChapterContent[] = req.result || [];
        let bytes = 0;
        chapters.forEach((c) => {
          bytes += (c.contentHtml?.length || 0) + (c.text?.length || 0);
        });
        resolve({ totalBytes: bytes, chapterCount: chapters.length });
      };
      req.onerror = () => resolve({ totalBytes: 0, chapterCount: 0 });
    });
  } catch {
    return { totalBytes: 0, chapterCount: 0 };
  }
}

export async function clearAllCachedChapters(): Promise<void> {
  try {
    const db = await getDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_CHAPTERS, 'readwrite');
      tx.objectStore(STORE_CHAPTERS).clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {}
}

export async function exportAllData(): Promise<string> {
  const novels = await getAllNovels();
  const settings = await loadReaderSettings();
  const bookmarks = getBookmarks();
  const stats = getReadingStats();

  const backupObj = {
    version: 1,
    exportedAt: new Date().toISOString(),
    novels,
    settings,
    bookmarks,
    stats,
  };

  return JSON.stringify(backupObj, null, 2);
}

export async function importAllData(jsonStr: string): Promise<{ success: boolean; novelCount: number }> {
  try {
    const data = JSON.parse(jsonStr);
    if (!data.novels || !Array.isArray(data.novels)) {
      throw new Error('Invalid backup file structure');
    }

    for (const novel of data.novels) {
      await saveNovel(novel);
    }

    if (data.settings) {
      saveReaderSettings(data.settings);
    }
    if (data.bookmarks) {
      localStorage.setItem('aether_bookmarks', JSON.stringify(data.bookmarks));
    }
    if (data.stats) {
      localStorage.setItem('aether_stats', JSON.stringify(data.stats));
    }

    return { success: true, novelCount: data.novels.length };
  } catch (err: any) {
    throw new Error(err.message || 'Failed to import backup data');
  }
}

// ---------------- USER PROFILE ----------------

export const DEFAULT_USER_PROFILE: UserProfile = {
  name: 'Aether Wanderer',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=240&auto=format&fit=crop&q=80',
  bio: 'Wandering through infinite realms, one chapter at a time.',
  joinedDate: 'Joined Oct 2026',
  customTitle: 'Seeker of Tomes',
};

export const PRESET_AVATARS = [
  {
    id: 'avatar_scholar',
    label: 'Arcane Scholar',
    url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=240&auto=format&fit=crop&q=80',
  },
  {
    id: 'avatar_cultivator',
    label: 'Celestial Cultivator',
    url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=240&auto=format&fit=crop&q=80',
  },
  {
    id: 'avatar_mage',
    label: 'Mystic Mage',
    url: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=240&auto=format&fit=crop&q=80',
  },
  {
    id: 'avatar_cyber',
    label: 'Cyberpunk Reader',
    url: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=240&auto=format&fit=crop&q=80',
  },
  {
    id: 'avatar_sage',
    label: 'Grand Sage',
    url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=240&auto=format&fit=crop&q=80',
  },
  {
    id: 'avatar_alchemist',
    label: 'Night Alchemist',
    url: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=240&auto=format&fit=crop&q=80',
  },
];

export function getUserProfile(): UserProfile {
  try {
    const raw = localStorage.getItem('aether_user_profile');
    if (raw) {
      return { ...DEFAULT_USER_PROFILE, ...JSON.parse(raw) };
    }
  } catch {}
  return DEFAULT_USER_PROFILE;
}

export function saveUserProfile(profile: UserProfile): void {
  try {
    localStorage.setItem('aether_user_profile', JSON.stringify(profile));
  } catch (err) {
    console.error('Failed to save user profile:', err);
  }
}

// ---------------- READING HISTORY ----------------

const HISTORY_STORAGE_KEY = 'aether_reading_history';

export function getReadingHistory(): ReadingHistoryEntry[] {
  try {
    const raw = localStorage.getItem(HISTORY_STORAGE_KEY);
    if (raw) {
      const parsed: ReadingHistoryEntry[] = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.sort((a, b) => b.timestamp - a.timestamp);
      }
    }
  } catch (e) {
    console.warn('Error reading reading history from storage:', e);
  }

  // Initial seed reading history so users immediately see recent entries & jump buttons
  const now = Date.now();
  const initialHistory: ReadingHistoryEntry[] = [
    {
      id: 'rr_mol_ch_0',
      novelId: 'rr_mol',
      novelTitle: 'Mother of Learning',
      novelAuthor: 'nobody103',
      novelCoverUrl: 'https://images.unsplash.com/photo-1532012164546-f432f2e3dd77?w=400&auto=format&fit=crop&q=80',
      chapterIndex: 0,
      chapterTitle: 'Chapter 1: Good Morning Brother',
      progressPercent: 78,
      paragraphIndex: 12,
      timestamp: now - 1000 * 60 * 18, // 18 minutes ago
    },
    {
      id: 'gut_frankenstein_ch_0',
      novelId: 'gut_frankenstein',
      novelTitle: 'Frankenstein; Or, The Modern Prometheus',
      novelAuthor: 'Mary Wollstonecraft Shelley',
      novelCoverUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400&auto=format&fit=crop&q=80',
      chapterIndex: 0,
      chapterTitle: 'Letter 1 - St. Petersburgh, Dec. 11th, 17—',
      progressPercent: 100,
      paragraphIndex: 18,
      timestamp: now - 1000 * 60 * 60 * 3.5, // 3.5 hours ago
    },
    {
      id: 'rr_mol_ch_1',
      novelId: 'rr_mol',
      novelTitle: 'Mother of Learning',
      novelAuthor: 'nobody103',
      novelCoverUrl: 'https://images.unsplash.com/photo-1532012164546-f432f2e3dd77?w=400&auto=format&fit=crop&q=80',
      chapterIndex: 1,
      chapterTitle: 'Chapter 2: The Academy of Magical Arts',
      progressPercent: 45,
      paragraphIndex: 8,
      timestamp: now - 1000 * 60 * 60 * 22, // Yesterday
    },
  ];

  try {
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(initialHistory));
  } catch {}
  return initialHistory;
}

export function recordReadingHistory(entry: {
  novelId: string;
  novelTitle: string;
  novelCoverUrl?: string;
  novelAuthor?: string;
  chapterIndex: number;
  chapterTitle: string;
  progressPercent: number;
  paragraphIndex?: number;
  timestamp?: number;
}): void {
  try {
    const list = getReadingHistory();
    const entryId = `${entry.novelId}_ch_${entry.chapterIndex}`;
    const timestamp = entry.timestamp || Date.now();

    const newEntry: ReadingHistoryEntry = {
      id: entryId,
      novelId: entry.novelId,
      novelTitle: entry.novelTitle,
      novelCoverUrl: entry.novelCoverUrl,
      novelAuthor: entry.novelAuthor,
      chapterIndex: entry.chapterIndex,
      chapterTitle: entry.chapterTitle,
      progressPercent: Math.max(0, Math.min(100, Math.round(entry.progressPercent))),
      paragraphIndex: entry.paragraphIndex,
      timestamp,
    };

    // Filter out previous entry for the same chapter so it moves to top with latest progress
    const filtered = list.filter((item) => item.id !== entryId);
    filtered.unshift(newEntry);

    // Limit to 100 entries
    const trimmed = filtered.slice(0, 100);
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(trimmed));
  } catch (err) {
    console.error('Failed to record reading history:', err);
  }
}

export function removeReadingHistoryEntry(id: string): ReadingHistoryEntry[] {
  try {
    const list = getReadingHistory().filter((item) => item.id !== id);
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(list));
    return list;
  } catch {
    return [];
  }
}

export function clearReadingHistory(): void {
  try {
    localStorage.removeItem(HISTORY_STORAGE_KEY);
  } catch {}
}

