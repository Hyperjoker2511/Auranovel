// Native Android Interface & PWA / WebAPK Bridge
// Seamlessly delegates to Android native Java/Kotlin AndroidBridge when available,
// with automatic graceful web standard fallbacks.

interface AndroidBridgeInterface {
  isNativeApp: () => boolean;
  getAppVersion: () => string;
  triggerHaptic: (type: string) => void;
  setKeepScreenOn: (keepOn: boolean) => void;
  setStatusBarTheme: (darkIcons: boolean, hexColor: string) => void;
  shareNovel: (title: string, url: string) => void;
  showToast: (message: string) => void;
  getPendingEpub: () => string;
  clearPendingEpub: () => void;
  startAudioPlayback?: (title: string, chapter: string) => void;
  stopAudioPlayback?: () => void;
  hasNativeAudioService?: () => boolean;
  openCloudflareResolver?: (url: string) => void;
  hasCloudflareResolver?: () => boolean;
}

declare global {
  interface Window {
    AndroidBridge?: AndroidBridgeInterface;
    __isAndroidNative?: boolean;
    __onAndroidBridgeReady?: () => void;
    __androidHandleBack?: () => boolean;
    __handleAndroidEpubImport?: (fileName: string) => void;
    __handleAndroidVolumeKey?: (direction: 'up' | 'down') => boolean;
    __onCloudflareSolved?: (url: string, cookies: string) => void;
  }
}

let activeWakeLock: any = null;

/**
 * Detect if running inside the native Android APK wrapper
 */
export function isAndroidNative(): boolean {
  if (typeof window === 'undefined') return false;
  return !!(window.__isAndroidNative || window.AndroidBridge?.isNativeApp?.());
}

/**
 * Detect if running as installed standalone app (Native APK or PWA WebAPK)
 */
export function isStandaloneApp(): boolean {
  if (typeof window === 'undefined') return false;
  if (isAndroidNative()) return true;
  return (
    window.matchMedia('(display-mode: standalone)').matches ||
    (window.navigator as any).standalone === true
  );
}

/**
 * Trigger native haptic feedback
 */
export function triggerNativeHaptic(type: 'light' | 'medium' | 'heavy' | 'success' = 'light'): void {
  try {
    if (window.AndroidBridge && typeof window.AndroidBridge.triggerHaptic === 'function') {
      window.AndroidBridge.triggerHaptic(type);
      return;
    }

    if (typeof window !== 'undefined' && 'vibrate' in navigator) {
      const patterns: Record<string, number | number[]> = {
        light: 12,
        medium: 24,
        heavy: 45,
        success: [15, 60, 25],
      };
      navigator.vibrate(patterns[type] || 15);
    }
  } catch {}
}

/**
 * Keep the device display awake while reading
 */
export async function setNativeScreenAwake(keepAwake: boolean): Promise<void> {
  try {
    if (window.AndroidBridge && typeof window.AndroidBridge.setKeepScreenOn === 'function') {
      window.AndroidBridge.setKeepScreenOn(keepAwake);
    }

    if ('wakeLock' in navigator) {
      if (keepAwake) {
        if (!activeWakeLock) {
          activeWakeLock = await (navigator as any).wakeLock.request('screen');
          activeWakeLock.addEventListener('release', () => {
            activeWakeLock = null;
          });
        }
      } else {
        if (activeWakeLock) {
          await activeWakeLock.release();
          activeWakeLock = null;
        }
      }
    }
  } catch (err) {
    // Ignore permissions or unsupported errors
  }
}

/**
 * Dynamically style the Android system status bar and navigation bar
 */
export function setNativeStatusBarTheme(darkIcons: boolean, hexColor: string): void {
  try {
    if (window.AndroidBridge && typeof window.AndroidBridge.setStatusBarTheme === 'function') {
      window.AndroidBridge.setStatusBarTheme(darkIcons, hexColor);
    }

    // Also update HTML meta theme-color
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) {
      meta.setAttribute('content', hexColor);
    }
  } catch {}
}

/**
 * Native Android or Web Share dialog
 */
export async function nativeShare(title: string, url: string): Promise<boolean> {
  try {
    if (window.AndroidBridge && typeof window.AndroidBridge.shareNovel === 'function') {
      window.AndroidBridge.shareNovel(title, url);
      return true;
    }

    if (navigator.share) {
      await navigator.share({
        title,
        text: `Read "${title}" on AetherNovel`,
        url,
      });
      return true;
    }
  } catch {}
  return false;
}

/**
 * Display a short native Android Toast message
 */
export function showNativeToast(message: string): void {
  try {
    if (window.AndroidBridge && typeof window.AndroidBridge.showToast === 'function') {
      window.AndroidBridge.showToast(message);
    }
  } catch {}
}

/**
 * Start background Android audio narration service
 */
export function startNativeAudioService(title: string, chapter: string): void {
  try {
    if (window.AndroidBridge && typeof window.AndroidBridge.startAudioPlayback === 'function') {
      window.AndroidBridge.startAudioPlayback(title, chapter);
    }
  } catch {}
}

/**
 * Stop background Android audio narration service
 */
export function stopNativeAudioService(): void {
  try {
    if (window.AndroidBridge && typeof window.AndroidBridge.stopAudioPlayback === 'function') {
      window.AndroidBridge.stopAudioPlayback();
    }
  } catch {}
}

/**
 * Checks if an EPUB was opened through Android Intent (Files, Email, Downloads)
 */
export function getPendingEpubFromIntent(): { fileName: string; blob: Blob } | null {
  try {
    if (!window.AndroidBridge || typeof window.AndroidBridge.getPendingEpub !== 'function') {
      return null;
    }

    const raw = window.AndroidBridge.getPendingEpub();
    if (!raw) return null;

    const parsed = JSON.parse(raw);
    if (!parsed.base64 || parsed.base64.length === 0) return null;

    // Convert Base64 to Blob
    const binary = atob(parsed.base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }

    const blob = new Blob([bytes], { type: 'application/epub+zip' });
    const fileName = parsed.fileName || 'imported.epub';

    // Clear after reading
    window.AndroidBridge.clearPendingEpub();

    return { fileName, blob };
  } catch (err) {
    console.error('Failed to parse pending Android EPUB intent:', err);
    return null;
  }
}

/**
 * Open native Android WebView Cloudflare captcha resolver dialog
 */
export function openNativeCloudflareResolver(url: string): boolean {
  try {
    if (window.AndroidBridge && typeof window.AndroidBridge.openCloudflareResolver === 'function') {
      window.AndroidBridge.openCloudflareResolver(url);
      return true;
    }
  } catch {}
  return false;
}

/**
 * Save solved Cloudflare clearance cookies for a domain
 */
export function saveCloudflareCookies(domain: string, cookies: string): void {
  try {
    const key = `cf_cookies_${domain.replace(/^www\./, '').toLowerCase()}`;
    localStorage.setItem(key, cookies);
  } catch {}
}

/**
 * Get stored Cloudflare clearance cookies for a domain
 */
export function getStoredCloudflareCookies(domain: string): string | null {
  try {
    const key = `cf_cookies_${domain.replace(/^www\./, '').toLowerCase()}`;
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}
