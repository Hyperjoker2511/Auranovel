import { triggerNativeHaptic } from './androidBridge';

// Procedural Web Audio API sound effects and haptics
// 100% offline, zero external dependencies, realistic acoustic response

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

/**
 * Procedural paper page rustle flip sound
 */
export function playPageFlipSound(): void {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const sampleRate = ctx.sampleRate;
    const duration = 0.07 + Math.random() * 0.03; // 70ms - 100ms
    const bufferSize = Math.floor(sampleRate * duration);
    const buffer = ctx.createBuffer(1, bufferSize, sampleRate);
    const output = buffer.getChannelData(0);

    // Filtered pink/white noise with smooth envelope
    for (let i = 0; i < bufferSize; i++) {
      const progress = i / bufferSize;
      // Exponential decay envelope with soft attack
      const envelope = progress < 0.15 
        ? progress / 0.15 
        : Math.pow(1 - progress, 2.5);
      // Soft noise
      output[i] = (Math.random() * 2 - 1) * envelope;
    }

    const whiteNoiseSource = ctx.createBufferSource();
    whiteNoiseSource.buffer = buffer;

    // Bandpass filter to simulate crisp paper texture
    const bandpass = ctx.createBiquadFilter();
    bandpass.type = 'bandpass';
    bandpass.frequency.value = 1800 + Math.random() * 600;
    bandpass.Q.value = 1.4;

    const gainNode = ctx.createGain();
    gainNode.gain.setValueAtTime(0.18, ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

    whiteNoiseSource.connect(bandpass);
    bandpass.connect(gainNode);
    gainNode.connect(ctx.destination);

    whiteNoiseSource.start();
  } catch {
    // Graceful fallback if audio is not permitted yet
  }
}

/**
 * Mobile vibration haptic feedback
 */
export function triggerHapticFeedback(pattern: number | number[] = 15): void {
  try {
    if (typeof pattern === 'number' && pattern > 30) {
      triggerNativeHaptic('heavy');
    } else if (Array.isArray(pattern)) {
      triggerNativeHaptic('success');
    } else {
      triggerNativeHaptic('light');
    }
  } catch {}
}
