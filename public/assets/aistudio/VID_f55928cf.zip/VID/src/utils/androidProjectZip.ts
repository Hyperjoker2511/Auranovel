import JSZip from 'jszip';

// Bundles the entire native Android Studio project and publishing metadata into a downloadable .zip archive.
export async function generateAndroidProjectZip(): Promise<Blob> {
  const zip = new JSZip();

  // Root project files
  zip.file(
    'build.gradle',
    `buildscript {
    ext {
        kotlin_version = '1.9.22'
        agp_version = '8.3.2'
    }
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath "com.android.tools.build:gradle:$agp_version"
        classpath "org.jetbrains.kotlin:kotlin-gradle-plugin:$kotlin_version"
    }
}

// allprojects repository block omitted to comply with dependencyResolutionManagement in settings.gradle

tasks.register('clean', Delete) {
    delete rootProject.buildDir
}
`
  );

  zip.file(
    'settings.gradle',
    `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "AetherNovel"
include ':app'
`
  );

  zip.file(
    'gradle.properties',
    `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.enableJetifier=false
android.nonTransitiveRClass=true
kotlin.code.style=official
`
  );

  // Gradle Wrapper
  zip.file(
    'gradle/wrapper/gradle-wrapper.properties',
    `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.4-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`
  );

  // App module build.gradle
  zip.file(
    'app/build.gradle',
    `plugins {
    id 'com.android.application'
    id 'org.jetbrains.kotlin.android'
}

android {
    namespace 'app.aethernovel'
    compileSdk 34

    defaultConfig {
        applicationId "app.aethernovel"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0.0"

        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary true
        }

        manifestPlaceholders = [
            hostName: "aethernovel.app",
            defaultUrl: "https://aethernovel.app"
        ]
    }

    signingConfigs {
        release {
            if (System.getenv("KEYSTORE_PATH") != null) {
                storeFile file(System.getenv("KEYSTORE_PATH"))
                storePassword System.getenv("KEYSTORE_PASSWORD")
                keyAlias System.getenv("KEY_ALIAS")
                keyPassword System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
            if (System.getenv("KEYSTORE_PATH") != null) {
                signingConfig signingConfigs.release
            } else {
                signingConfig signingConfigs.debug
            }
        }
        debug {
            applicationIdSuffix ".debug"
            debuggable true
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = '17'
    }

    packagingOptions {
        resources {
            excludes += '/META-INF/{AL2.0,LGPL2.1}'
        }
    }
}

dependencies {
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.webkit:webkit:1.10.0'
    implementation 'androidx.browser:browser:1.8.0'
    implementation 'androidx.activity:activity-ktx:1.8.2'
    implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3'
}
`
  );

  zip.file(
    'app/proguard-rules.pro',
    `-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class app.aethernovel.AndroidNativeBridge { *; }
-dontwarn androidx.webkit.**
-keepattributes *Annotation*
-keepattributes JavascriptInterface
`
  );

  // AndroidManifest.xml
  zip.file(
    'app/src/main/AndroidManifest.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

    <application
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher"
        android:supportsRtl="true"
        android:theme="@style/Theme.AetherNovel"
        android:hardwareAccelerated="true"
        android:usesCleartextTraffic="false"
        tools:targetApi="34">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|screenLayout|smallestScreenSize|uiMode"
            android:windowSoftInputMode="adjustResize"
            android:launchMode="singleTask">

            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>

            <!-- EPUB Association -->
            <intent-filter android:label="@string/open_epub_action">
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="content" />
                <data android:scheme="file" />
                <data android:mimeType="application/epub+zip" />
                <data android:mimeType="application/x-epub+zip" />
                <data android:mimeType="application/octet-stream" android:pathPattern=".*\\\\.epub" />
            </intent-filter>

            <!-- Verified App Links -->
            <intent-filter android:autoVerify="true">
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="https" android:host="\${hostName}" />
                <data android:scheme="http" android:host="\${hostName}" />
            </intent-filter>

            <meta-data
                android:name="android.app.shortcuts"
                android:resource="@xml/shortcuts" />
        </activity>

        <service
            android:name=".AudioService"
            android:enabled="true"
            android:exported="false"
            android:foregroundServiceType="mediaPlayback" />

        <provider
            android:name="androidx.core.content.FileProvider"
            android:authorities="\${applicationId}.fileprovider"
            android:exported="false"
            android:grantUriPermissions="true">
            <meta-data
                android:name="android.support.FILE_PROVIDER_PATHS"
                android:resource="@xml/file_paths" />
        </provider>

    </application>
</manifest>
`
  );

  // Kotlin files
  zip.file(
    'app/src/main/java/app/aethernovel/MainActivity.kt',
    `package app.aethernovel

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Base64
import android.view.View
import android.webkit.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.io.InputStream

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var nativeBridge: AndroidNativeBridge
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            val results: Array<Uri>? = when {
                data?.data != null -> arrayOf(data.data!!)
                data?.clipData != null -> {
                    val count = data.clipData!!.itemCount
                    Array(count) { i -> data.clipData!!.getItemAt(i).uri }
                }
                else -> null
            }
            filePathCallback?.onReceiveValue(results)
        } else {
            filePathCallback?.onReceiveValue(null)
        }
        filePathCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        webView = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#090D16"))
        }
        setContentView(webView)

        nativeBridge = AndroidNativeBridge(this)

        setupWebView()
        handleIncomingIntent(intent)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript(
                    "window.__androidHandleBack ? window.__androidHandleBack() : false"
                ) { result ->
                    if (result == "true") return@evaluateJavascript
                    if (webView.canGoBack()) {
                        webView.goBack()
                    } else {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        val defaultUrl = getString(R.string.default_web_url)
        webView.loadUrl(defaultUrl)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.cacheMode = WebSettings.LOAD_DEFAULT

        webView.addJavascriptInterface(nativeBridge, "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                webView.evaluateJavascript("window.__isAndroidNative = true; if(window.__onAndroidBridgeReady){ window.__onAndroidBridgeReady(); }", null)
                dispatchPendingEpubIfAny()
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    try {
                        view?.loadUrl("file:///android_asset/index.html")
                    } catch (_: Exception) {}
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                filePath: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = filePath
                val intent = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                }
                try {
                    filePickerLauncher.launch(intent)
                } catch (e: Exception) {
                    filePathCallback = null
                    return false
                }
                return true
            }
        }
    }

    private fun handleIncomingIntent(intent: Intent) {
        if (Intent.ACTION_VIEW == intent.action && intent.data != null) {
            readEpubFromUri(intent.data!!)
        }
    }

    private fun readEpubFromUri(uri: Uri) {
        Thread {
            try {
                var fileName = "imported.epub"
                val cursor = contentResolver.query(uri, null, null, null, null)
                cursor?.use {
                    if (it.moveToFirst()) {
                        val nameIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIndex != -1) {
                            fileName = it.getString(nameIndex) ?: fileName
                        }
                    }
                }
                val inputStream: InputStream? = contentResolver.openInputStream(uri)
                val bytes = inputStream?.readBytes()
                inputStream?.close()

                if (bytes != null && bytes.isNotEmpty()) {
                    val base64Data = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    nativeBridge.pendingEpubUri = uri.toString()
                    nativeBridge.pendingEpubFileName = fileName
                    nativeBridge.pendingEpubBase64 = base64Data

                    runOnUiThread {
                        dispatchPendingEpubIfAny()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }

    private fun dispatchPendingEpubIfAny() {
        if (nativeBridge.pendingEpubBase64 != null) {
            val fileName = nativeBridge.pendingEpubFileName ?: "imported.epub"
            webView.evaluateJavascript("if (window.__handleAndroidEpubImport) { window.__handleAndroidEpubImport('$fileName'); }", null)
        }
    }

    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (event.action == android.view.KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                android.view.KeyEvent.KEYCODE_VOLUME_DOWN -> {
                    webView.evaluateJavascript("window.__handleAndroidVolumeKey ? window.__handleAndroidVolumeKey('down') : false") { handled ->
                        if (handled != "true") super.dispatchKeyEvent(event)
                    }
                    return true
                }
                android.view.KeyEvent.KEYCODE_VOLUME_UP -> {
                    webView.evaluateJavascript("window.__handleAndroidVolumeKey ? window.__handleAndroidVolumeKey('up') : false") { handled ->
                        if (handled != "true") super.dispatchKeyEvent(event)
                    }
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onDestroy() {
        super.onDestroy()
        webView.destroy()
    }
}
`
  );

  zip.file(
    'app/src/main/java/app/aethernovel/AndroidNativeBridge.kt',
    `package app.aethernovel

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.widget.Toast
import androidx.core.view.WindowCompat

class AndroidNativeBridge(private val activity: Activity) {

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = activity.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        activity.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    var pendingEpubUri: String? = null
    var pendingEpubBase64: String? = null
    var pendingEpubFileName: String? = null

    @JavascriptInterface
    fun isNativeApp(): Boolean = true

    @JavascriptInterface
    fun getAppVersion(): String = "1.0.0"

    @JavascriptInterface
    fun triggerHaptic(type: String) {
        activity.runOnUiThread {
            if (vibrator?.hasVibrator() != true) return@runOnUiThread
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val effect = when (type.lowercase()) {
                    "light" -> VibrationEffect.createOneShot(12, 60)
                    "medium" -> VibrationEffect.createOneShot(24, 140)
                    "heavy" -> VibrationEffect.createOneShot(45, 255)
                    "success" -> VibrationEffect.createWaveform(longArrayOf(0, 15, 60, 25), intArrayOf(0, 100, 0, 180), -1)
                    else -> VibrationEffect.createOneShot(15, VibrationEffect.DEFAULT_AMPLITUDE)
                }
                vibrator.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(18)
            }
        }
    }

    @JavascriptInterface
    fun setKeepScreenOn(keepOn: Boolean) {
        activity.runOnUiThread {
            if (keepOn) {
                activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            } else {
                activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }

    @JavascriptInterface
    fun setStatusBarTheme(darkIcons: Boolean, hexColor: String) {
        activity.runOnUiThread {
            try {
                val color = Color.parseColor(hexColor)
                activity.window.statusBarColor = color
                activity.window.navigationBarColor = color
                val insets = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
                insets.isAppearanceLightStatusBars = darkIcons
                insets.isAppearanceLightNavigationBars = darkIcons
            } catch (_: Exception) {}
        }
    }

    @JavascriptInterface
    fun shareNovel(title: String, url: String) {
        activity.runOnUiThread {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, "Read \\"$title\\" on AetherNovel:\\n$url")
            }
            activity.startActivity(Intent.createChooser(intent, "Share Novel"))
        }
    }

    @JavascriptInterface
    fun showToast(message: String) {
        activity.runOnUiThread {
            Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
        }
    }

    @JavascriptInterface
    fun startAudioPlayback(title: String, chapter: String) {
        activity.runOnUiThread {
            try {
                val intent = Intent(activity, AudioService::class.java).apply {
                    action = AudioService.ACTION_PLAY
                    putExtra(AudioService.EXTRA_TITLE, title)
                    putExtra(AudioService.EXTRA_CHAPTER, chapter)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    activity.startForegroundService(intent)
                } else {
                    activity.startService(intent)
                }
            } catch (e: Exception) {}
        }
    }

    @JavascriptInterface
    fun stopAudioPlayback() {
        activity.runOnUiThread {
            try {
                val intent = Intent(activity, AudioService::class.java).apply {
                    action = AudioService.ACTION_STOP
                }
                activity.startService(intent)
            } catch (e: Exception) {}
        }
    }

    @JavascriptInterface
    fun hasNativeAudioService(): Boolean = true

    @JavascriptInterface
    fun getPendingEpub(): String {
        val json = """
            {
                "uri": "\${pendingEpubUri ?: ""}",
                "fileName": "\${pendingEpubFileName ?: ""}",
                "base64": "\${pendingEpubBase64 ?: ""}"
            }
        """.trimIndent()
        return json
    }

    @JavascriptInterface
    fun clearPendingEpub() {
        pendingEpubUri = null
        pendingEpubBase64 = null
        pendingEpubFileName = null
    }
}
`
  );

  // Res XMLs
  zip.file(
    'app/src/main/res/values/strings.xml',
    `<resources>
    <string name="app_name">AetherNovel</string>
    <string name="default_web_url">https://aethernovel.app/</string>
    <string name="open_epub_action">Read EPUB in AetherNovel</string>
    <string name="shortcut_resume_reading">Resume Reading</string>
    <string name="shortcut_import_epub">Import EPUB</string>
    <string name="shortcut_browse_novels">Browse Library</string>
</resources>
`
  );

  zip.file(
    'app/src/main/res/values/colors.xml',
    `<resources>
    <color name="primary">#06B6D4</color>
    <color name="primary_dark">#0891B2</color>
    <color name="accent">#F59E0B</color>
    <color name="background">#090D16</color>
</resources>
`
  );

  zip.file(
    'app/src/main/res/values/styles.xml',
    `<resources>
    <style name="Theme.AetherNovel" parent="Theme.MaterialComponents.DayNight.NoActionBar">
        <item name="colorPrimary">@color/primary</item>
        <item name="colorPrimaryDark">@color/primary_dark</item>
        <item name="colorAccent">@color/accent</item>
        <item name="android:windowBackground">@color/background</item>
        <item name="android:statusBarColor">@android:color/transparent</item>
        <item name="android:navigationBarColor">@android:color/transparent</item>
        <item name="android:windowDrawsSystemBarBackgrounds">true</item>
    </style>
</resources>
`
  );

  zip.file(
    'app/src/main/res/xml/file_paths.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<paths xmlns:android="http://schemas.android.com/apk/res/android">
    <external-path name="external_files" path="." />
    <cache-path name="cache_files" path="." />
    <files-path name="internal_files" path="." />
</paths>
`
  );

  zip.file(
    'app/src/main/res/xml/shortcuts.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<shortcuts xmlns:android="http://schemas.android.com/apk/res/android">
    <shortcut
        android:shortcutId="resume_reading"
        android:enabled="true"
        android:icon="@mipmap/ic_launcher"
        android:shortcutShortLabel="@string/shortcut_resume_reading">
        <intent
            android:action="android.intent.action.VIEW"
            android:targetPackage="app.aethernovel"
            android:targetClass="app.aethernovel.MainActivity"
            android:data="https://aethernovel.app/?action=resume" />
    </shortcut>
</shortcuts>
`
  );

  // Store metadata & F-Droid recipe
  zip.file(
    'metadata/app.aethernovel.yml',
    `Categories:
  - Reading
  - Education

License: Apache-2.0
AuthorName: AetherNovel Open Source Authors
SourceCode: https://github.com/aethernovel/aethernovel
WebSite: https://aethernovel.app

AutoName: AetherNovel
Summary: Distraction-free web novel and EPUB reader with OLED themes
Description: |-
  AetherNovel is a privacy-first, high-performance web novel and EPUB reader
  designed for Android devices.

RepoType: git
Repo: https://github.com/aethernovel/aethernovel.git

Builds:
  - versionName: 1.0.0
    versionCode: 1
    commit: v1.0.0
    subdir: android
    gradle:
      - assembleRelease
    output: app/build/outputs/apk/release/app-release-unsigned.apk

CurrentVersion: 1.0.0
CurrentVersionCode: 1
`
  );

  zip.file('fastlane/metadata/android/en-US/title.txt', 'AetherNovel - Novel & EPUB Reader');
  zip.file(
    'fastlane/metadata/android/en-US/short_description.txt',
    'Distraction-free web novel & EPUB reader with OLED themes and offline audio.'
  );
  zip.file(
    'fastlane/metadata/android/en-US/changelogs/1.txt',
    'Initial native Android release with OLED themes, EPUB parsing, and offline caching.'
  );

  // Build README with Terminal Commands
  zip.file(
    'README.md',
    `# AetherNovel Native Android Project

Production-ready native Android project for publishing on **Google Play Store** (via AAB) and **F-Droid** (via Standalone APK).

## 🚀 Quick Build Commands

### 1. Compile Release APK (for F-Droid or direct download):
\`\`\`bash
./gradlew assembleRelease
# Output: app/build/outputs/apk/release/app-release-unsigned.apk
\`\`\`

### 2. Compile Android App Bundle .aab (for Google Play Console):
\`\`\`bash
./gradlew bundleRelease
# Output: app/build/outputs/bundle/release/app-release.aab
\`\`\`

### 3. Generate Android Signing Keystore:
\`\`\`bash
keytool -genkey -v -keystore aethernovel-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias aethernovel
\`\`\`

### 4. Digital Asset Links Verification:
Deploy the contents of \`assetlinks.json\` to \`https://yourdomain.com/.well-known/assetlinks.json\`.
`
  );

  return await zip.generateAsync({ type: 'blob' });
}
