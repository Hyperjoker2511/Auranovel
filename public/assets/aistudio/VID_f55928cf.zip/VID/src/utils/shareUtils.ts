import { Novel } from '../types/novel';

export function generateNovelShareLink(novel: Novel): string {
  const minimalData = {
    id: novel.id,
    title: novel.title,
    author: novel.author,
    coverUrl: novel.coverUrl,
    description: novel.description?.slice(0, 500) || '',
    genres: novel.genres || [],
    sourceType: novel.sourceType,
    sourceName: novel.sourceName,
    sourceUrl: novel.sourceUrl,
    totalChapters: novel.totalChapters || novel.chapters?.length || 1,
    chapters: (novel.chapters || []).slice(0, 25).map((c) => ({
      id: c.id,
      index: c.index,
      title: c.title,
      url: c.url,
      wordCount: c.wordCount,
    })),
  };

  try {
    const jsonStr = JSON.stringify(minimalData);
    // Base64 encode safely for UTF-8
    const base64 = btoa(encodeURIComponent(jsonStr).replace(/%([0-9A-F]{2})/g, (_, p1) =>
      String.fromCharCode(parseInt(p1, 16))
    ));

    const origin = window.location.origin;
    const pathname = window.location.pathname;
    return `${origin}${pathname}?shared_novel=${encodeURIComponent(base64)}`;
  } catch (err) {
    console.error('Error generating share link:', err);
    return `${window.location.origin}${window.location.pathname}?novel_id=${encodeURIComponent(novel.id)}`;
  }
}

export function parseSharedNovelFromUrl(): Novel | null {
  if (typeof window === 'undefined') return null;

  const urlParams = new URLSearchParams(window.location.search);
  const sharedData = urlParams.get('shared_novel');

  if (!sharedData) return null;

  try {
    // Decode UTF-8 Base64
    const binaryStr = atob(decodeURIComponent(sharedData));
    const jsonStr = decodeURIComponent(
      Array.prototype.map
        .call(binaryStr, (c: string) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    );
    const parsed = JSON.parse(jsonStr);

    if (!parsed.title || !parsed.id) return null;

    const novel: Novel = {
      id: parsed.id.startsWith('shared_') ? parsed.id : `shared_${parsed.id}`,
      title: parsed.title,
      author: parsed.author || 'Unknown Author',
      coverUrl: parsed.coverUrl,
      description: parsed.description || '',
      genres: parsed.genres || ['Shared'],
      sourceType: parsed.sourceType || 'extension',
      sourceName: parsed.sourceName || 'Community Shared',
      sourceUrl: parsed.sourceUrl,
      status: 'reading',
      currentChapterIndex: 0,
      currentProgressPercent: 0,
      totalChapters: parsed.totalChapters || parsed.chapters?.length || 1,
      chapters: (parsed.chapters || []).map((ch: any, idx: number) => ({
        id: ch.id || `shared_${parsed.id}_ch_${idx}`,
        novelId: `shared_${parsed.id}`,
        index: idx,
        title: ch.title || `Chapter ${idx + 1}`,
        url: ch.url,
        wordCount: ch.wordCount,
      })),
      lastReadAt: Date.now(),
      createdAt: Date.now(),
    };

    return novel;
  } catch (err) {
    console.warn('Failed to parse shared novel link:', err);
    return null;
  }
}

export function clearShareParamFromUrl(): void {
  if (typeof window === 'undefined') return;
  const url = new URL(window.location.href);
  url.searchParams.delete('shared_novel');
  url.searchParams.delete('novel_id');
  window.history.replaceState({}, document.title, url.toString());
}
