import { ReadingStats, UserLevelProgression, Novel } from '../types/novel';

export interface TitleBadge {
  id: string;
  title: string;
  icon: string;
  category: 'hours' | 'chapters' | 'mastery';
  requirementText: string;
  isUnlocked: boolean;
  progressPercent: number;
  currentValue: number;
  targetValue: number;
  tierColor: string;
}

export const TITLE_BADGES_CONFIG = [
  // Hours Read Milestones
  {
    id: 'badge_novice',
    title: 'Novice Reader',
    icon: '🌱',
    category: 'hours' as const,
    targetHours: 0.25, // 15 mins
    targetValue: 15,
    unit: 'mins',
    tierColor: 'from-emerald-600 to-teal-400',
    requirementText: 'Read for at least 15 minutes',
  },
  {
    id: 'badge_bookworm',
    title: 'Bookworm',
    icon: '🐛',
    category: 'hours' as const,
    targetHours: 2,
    targetValue: 2,
    unit: 'hours',
    tierColor: 'from-amber-600 to-yellow-400',
    requirementText: 'Read for 2 total hours',
  },
  {
    id: 'badge_pageturner',
    title: 'Page Turner',
    icon: '📖',
    category: 'hours' as const,
    targetHours: 6,
    targetValue: 6,
    unit: 'hours',
    tierColor: 'from-sky-600 to-cyan-400',
    requirementText: 'Read for 6 total hours',
  },
  {
    id: 'badge_scholar',
    title: 'Literary Scholar',
    icon: '🎓',
    category: 'hours' as const,
    targetHours: 15,
    targetValue: 15,
    unit: 'hours',
    tierColor: 'from-indigo-600 to-violet-400',
    requirementText: 'Read for 15 total hours',
  },
  {
    id: 'badge_sage',
    title: 'Ethereal Sage',
    icon: '🔮',
    category: 'hours' as const,
    targetHours: 35,
    targetValue: 35,
    unit: 'hours',
    tierColor: 'from-purple-600 to-fuchsia-400',
    requirementText: 'Read for 35 total hours',
  },
  {
    id: 'badge_grandmaster',
    title: 'Grandmaster of Fiction',
    icon: '👑',
    category: 'hours' as const,
    targetHours: 80,
    targetValue: 80,
    unit: 'hours',
    tierColor: 'from-amber-500 via-rose-500 to-yellow-300',
    requirementText: 'Read for 80 total hours',
  },

  // Chapters Completed Milestones
  {
    id: 'badge_first_step',
    title: 'First Step',
    icon: '📜',
    category: 'chapters' as const,
    targetChapters: 1,
    targetValue: 1,
    unit: 'chapters',
    tierColor: 'from-blue-600 to-cyan-400',
    requirementText: 'Complete your first chapter',
  },
  {
    id: 'badge_avid',
    title: 'Avid Reader',
    icon: '⚡',
    category: 'chapters' as const,
    targetChapters: 10,
    targetValue: 10,
    unit: 'chapters',
    tierColor: 'from-orange-600 to-amber-400',
    requirementText: 'Complete 10 total chapters',
  },
  {
    id: 'badge_devourer',
    title: 'Chapter Devourer',
    icon: '🔥',
    category: 'chapters' as const,
    targetChapters: 30,
    targetValue: 30,
    unit: 'chapters',
    tierColor: 'from-rose-600 to-red-400',
    requirementText: 'Complete 30 total chapters',
  },
  {
    id: 'badge_sovereign',
    title: 'Sovereign of the Archive',
    icon: '🌌',
    category: 'chapters' as const,
    targetChapters: 100,
    targetValue: 100,
    unit: 'chapters',
    tierColor: 'from-yellow-400 via-amber-500 to-orange-600',
    requirementText: 'Complete 100 total chapters',
  },
];

export function getTitleBadges(stats: ReadingStats): TitleBadge[] {
  const totalHours = (stats.totalSecondsRead || 0) / 3600;
  const totalMins = (stats.totalSecondsRead || 0) / 60;
  const totalChapters = stats.chaptersCompleted || 0;

  return TITLE_BADGES_CONFIG.map((cfg) => {
    let currentVal = 0;
    let targetVal = cfg.targetValue;

    if (cfg.category === 'hours') {
      if (cfg.unit === 'mins') {
        currentVal = Math.round(totalMins);
      } else {
        currentVal = parseFloat(totalHours.toFixed(1));
      }
    } else {
      currentVal = totalChapters;
    }

    const isUnlocked = currentVal >= targetVal;
    const progressPercent = Math.min(100, Math.round((currentVal / targetVal) * 100));

    return {
      id: cfg.id,
      title: cfg.title,
      icon: cfg.icon,
      category: cfg.category,
      requirementText: cfg.requirementText,
      isUnlocked,
      progressPercent,
      currentValue: currentVal,
      targetValue: targetVal,
      tierColor: cfg.tierColor,
    };
  });
}

export function calculateUserProgression(stats: ReadingStats): UserLevelProgression {
  const totalHours = (stats.totalSecondsRead || 0) / 3600;
  const totalChapters = stats.chaptersCompleted || 0;

  // Calculate level based on combined hours read and chapters completed
  // Level threshold starts at 0, increases progressively
  const badges = getTitleBadges(stats);
  const unlockedBadges = badges.filter((b) => b.isUnlocked);

  // Derive active highest unlocked title
  const highestUnlockedTitle = unlockedBadges.length > 0 
    ? unlockedBadges[unlockedBadges.length - 1].title 
    : 'Novice Reader';

  const nextLockedBadge = badges.find((b) => !b.isUnlocked);
  const nextRankTitle = nextLockedBadge ? nextLockedBadge.title : 'Sovereign of Endless Stories';

  // XP calculation
  const totalXp = Math.floor((stats.totalSecondsRead || 0) / 10) + (stats.chaptersCompleted || 0) * 50 + (stats.booksFinished || 0) * 250;
  const level = Math.max(1, Math.floor(Math.sqrt(totalXp / 80)) + 1);

  const currentLevelBaseXp = Math.pow(level - 1, 2) * 80;
  const nextLevelBaseXp = Math.pow(level, 2) * 80;

  const currentXpInLevel = totalXp - currentLevelBaseXp;
  const xpNeededForNext = nextLevelBaseXp - currentLevelBaseXp;

  return {
    level,
    currentXp: currentXpInLevel,
    nextLevelXp: xpNeededForNext,
    rankTitle: highestUnlockedTitle,
    nextRankTitle,
    unlockedPerks: unlockedBadges.map((b) => `${b.icon} ${b.title}`),
  };
}

// Calculate remaining reading time in current book
export function estimateTimeRemaining(novel: Novel, wpm: number = 240): { minutes: number; formatted: string } {
  if (!novel || !novel.chapters || novel.chapters.length === 0) {
    return { minutes: 0, formatted: '0 mins' };
  }

  const currentChIndex = novel.currentChapterIndex || 0;
  let remainingWords = 0;

  for (let i = currentChIndex; i < novel.chapters.length; i++) {
    const ch = novel.chapters[i];
    const wordCount = ch.wordCount || 3200;
    if (i === currentChIndex) {
      const progressFactor = (100 - (novel.currentProgressPercent || 0)) / 100;
      remainingWords += Math.round(wordCount * progressFactor);
    } else {
      remainingWords += wordCount;
    }
  }

  const minutesRemaining = Math.max(1, Math.round(remainingWords / (wpm || 240)));

  let formatted = '';
  if (minutesRemaining < 60) {
    formatted = `${minutesRemaining} min${minutesRemaining > 1 ? 's' : ''}`;
  } else {
    const hours = Math.floor(minutesRemaining / 60);
    const mins = minutesRemaining % 60;
    formatted = mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
  }

  return { minutes: minutesRemaining, formatted };
}

// Get the last 7 days activity breakdown
export function getWeeklyActivityData(stats: ReadingStats): Array<{
  dayName: string;
  dateKey: string;
  minutes: number;
  isToday: boolean;
}> {
  const result = [];
  const today = new Date();
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  for (let i = 6; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    const dateKey = d.toISOString().split('T')[0];
    const dayName = dayNames[d.getDay()];

    const seconds = stats.weeklyActivity?.[dateKey] || 0;
    const minutes = Math.round(seconds / 60);

    result.push({
      dayName,
      dateKey,
      minutes,
      isToday: i === 0,
    });
  }

  return result;
}
