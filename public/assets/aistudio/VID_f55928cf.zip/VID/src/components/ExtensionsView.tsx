import React, { useState, useEffect } from 'react';
import {
  Compass,
  Download,
  BookOpen,
  Plus,
  Star,
  Search,
  Filter,
  Check,
  CheckCircle2,
  ExternalLink,
  Layers,
  ChevronRight,
  Sparkles,
  X,
  RefreshCw,
  FolderPlus,
  Settings,
  Package,
  ArrowRight,
  TrendingUp,
  Share2,
  Globe,
  Radio,
  PlusCircle,
  ShieldCheck,
} from 'lucide-react';
import { ExtensionSource, Novel } from '../types/novel';
import { INITIAL_EXTENSIONS, POPULAR_COMMUNITY_REPOS, CommunityRepoListing } from '../data/extensions';
import { saveNovel, isChapterCached } from '../utils/storage';
import { downloadBatchChapters } from '../utils/chapterDownloader';
import { generateNovelShareLink } from '../utils/shareUtils';
import { NovelDetailsModal } from './NovelDetailsModal';

interface ExtensionsViewProps {
  onOpenReader: (novel: Novel, initialChapterIndex: number) => void;
  onNovelAddedToLibrary: (novel: Novel) => void;
  savedNovelIds: Set<string>;
}

const STORAGE_KEY_EXTENSIONS = 'aether_installed_extensions';

export const ExtensionsView: React.FC<ExtensionsViewProps> = ({
  onOpenReader,
  onNovelAddedToLibrary,
  savedNovelIds,
}) => {
  // Load extensions from localStorage or fallback to INITIAL_EXTENSIONS
  const [extensions, setExtensions] = useState<ExtensionSource[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY_EXTENSIONS);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Merge to ensure novel catalogs are up-to-date
          const map = new Map<string, ExtensionSource>(INITIAL_EXTENSIONS.map((e) => [e.id, e]));
          parsed.forEach((custom: ExtensionSource) => {
            if (map.has(custom.id)) {
              map.set(custom.id, { ...map.get(custom.id)!, enabled: custom.enabled });
            } else {
              map.set(custom.id, custom);
            }
          });
          return Array.from(map.values());
        }
      }
    } catch {}
    return INITIAL_EXTENSIONS;
  });

  const [selectedProviderId, setSelectedProviderId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('All');
  const [selectedGenre, setSelectedGenre] = useState<string>('All');

  // Extension Repos Management Modal
  const [showRepoSettingsModal, setShowRepoSettingsModal] = useState(false);
  const [activeRepoTab, setActiveRepoTab] = useState<'installed' | 'community' | 'custom'>('community');
  const [customRepoUrl, setCustomRepoUrl] = useState('');
  const [customRepoName, setCustomRepoName] = useState('');
  const [repoSuccessMsg, setRepoSuccessMsg] = useState<string | null>(null);

  // Book Detail Modal
  const [inspectingNovel, setInspectingNovel] = useState<Novel | null>(null);

  // Batch downloading feedback
  const [downloadProgress, setDownloadProgress] = useState<{
    novelId: string;
    current: number;
    total: number;
    title: string;
  } | null>(null);

  const [shareToast, setShareToast] = useState<string | null>(null);

  // Persist extension state
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_EXTENSIONS, JSON.stringify(extensions));
    } catch {}
  }, [extensions]);

  const handleShareNovel = async (novel: Novel) => {
    const link = generateNovelShareLink(novel);
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(link);
      } else {
        prompt('Copy novel link to share:', link);
      }
      setShareToast(`Link copied! Friends clicking it can view & save "${novel.title}".`);
      setTimeout(() => setShareToast(null), 4000);
    } catch {
      prompt('Copy novel link to share:', link);
    }
  };

  const toggleExtension = (id: string) => {
    setExtensions((prev) =>
      prev.map((ext) => (ext.id === id ? { ...ext, enabled: !ext.enabled } : ext))
    );
  };

  const handleAddCustomRepo = () => {
    if (!customRepoUrl.trim()) return;

    const newExt: ExtensionSource = {
      id: 'ext_custom_' + Date.now(),
      name: customRepoName.trim() || 'Custom Provider Repository',
      version: '1.0.0',
      icon: '📦',
      description: `User-linked source repository from ${customRepoUrl}`,
      language: 'English',
      enabled: true,
      isCommunity: true,
      tags: ['Custom', 'Community', 'User-Linked'],
      novels: [],
      repoUrl: customRepoUrl.trim(),
    };

    setExtensions((prev) => [...prev, newExt]);
    setCustomRepoUrl('');
    setCustomRepoName('');
    setRepoSuccessMsg('Custom extension repository linked successfully!');
    setTimeout(() => setRepoSuccessMsg(null), 3000);
  };

  const handleInstallCommunityRepo = (repo: CommunityRepoListing) => {
    // Check if an extension with this ID or URL already exists
    const existing = extensions.find((e) => e.repoUrl === repo.url || e.id === repo.id);
    if (existing) {
      if (!existing.enabled) {
        toggleExtension(existing.id);
        setRepoSuccessMsg(`Enabled repository: "${repo.name}"!`);
      } else {
        setRepoSuccessMsg(`"${repo.name}" is already installed and active.`);
      }
      setTimeout(() => setRepoSuccessMsg(null), 3000);
      return;
    }

    // Create installed extension source from registry
    const newSource: ExtensionSource = {
      id: repo.id,
      name: repo.name,
      version: '1.2.0',
      icon: repo.icon,
      description: repo.description,
      language: repo.languages[0] || 'English',
      enabled: true,
      isCommunity: true,
      tags: repo.tags,
      repoUrl: repo.url,
      author: repo.author,
      novels: [],
    };

    setExtensions((prev) => [...prev, newSource]);
    setRepoSuccessMsg(`Installed community repository: "${repo.name}"!`);
    setTimeout(() => setRepoSuccessMsg(null), 3500);
  };

  // Aggregate novels from enabled extensions
  const availableNovels: Novel[] = extensions
    .filter((ext) => (selectedProviderId === 'all' ? ext.enabled : ext.id === selectedProviderId && ext.enabled))
    .flatMap((ext) => ext.novels);

  // Filter novels by language, genre, and search query
  const filteredNovels = availableNovels.filter((novel) => {
    const matchesSearch =
      novel.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      novel.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
      novel.genres.some((g) => g.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesGenre = selectedGenre === 'All' || novel.genres.includes(selectedGenre);

    // Language matching based on source extension
    const sourceExt = extensions.find((e) => e.name === novel.sourceName || e.novels.some((n) => n.id === novel.id));
    const matchesLanguage =
      selectedLanguage === 'All' ||
      (sourceExt && sourceExt.language.toLowerCase().includes(selectedLanguage.toLowerCase()));

    return matchesSearch && matchesGenre && matchesLanguage;
  });

  const allGenres = ['All', ...Array.from(new Set(availableNovels.flatMap((n) => n.genres)))].slice(0, 10);
  const allLanguages = ['All', 'English', 'Japanese Translation', 'Korean Translation', 'Multi-lingual'];

  // Featured Novel for Hero Recommendation
  const featuredNovel = availableNovels[0] || null;

  const handleAddToLibrary = async (novel: Novel) => {
    await saveNovel(novel);
    onNovelAddedToLibrary(novel);
  };

  const handleBatchDownload = async (novel: Novel) => {
    await saveNovel(novel);
    onNovelAddedToLibrary(novel);

    setDownloadProgress({
      novelId: novel.id,
      current: 0,
      total: novel.chapters.length,
      title: 'Preparing offline cache...',
    });

    await downloadBatchChapters(novel, 0, novel.chapters.length, (curr, tot, chTitle) => {
      setDownloadProgress({
        novelId: novel.id,
        current: curr,
        total: tot,
        title: chTitle,
      });
    });

    setTimeout(() => setDownloadProgress(null), 1500);
  };

  const enabledExtensionsCount = extensions.filter((e) => e.enabled).length;

  return (
    <div className="flex-1 w-full max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 flex flex-col gap-7 animate-fade-in">
      {/* Top Header: Title & Upper Right Extension Repo Manager Button */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-sky-500/15 border border-sky-500/30 text-sky-400 flex items-center justify-center shadow-inner">
              <Compass className="w-6 h-6 stroke-[2.2]" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-neutral-100 flex items-center gap-2.5">
                <span>Discover & Novel Repositories</span>
              </h1>
              <p className="text-xs text-neutral-400 mt-0.5">
                Explore curated web novels, classics, and installable community repository feeds.
              </p>
            </div>
          </div>
        </div>

        {/* Upper Right Corner: Extension Repos Option */}
        <div className="flex items-center gap-2 self-end sm:self-center">
          <button
            onClick={() => setShowRepoSettingsModal(true)}
            className="px-3.5 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-200 text-xs font-semibold flex items-center gap-2 transition active:scale-95 shadow-sm flex-shrink-0"
            title="Configure Extension Repositories & Community Feeds"
          >
            <Package className="w-4 h-4 text-sky-400" />
            <span>Extension Repos</span>
            <span className="w-5 h-5 rounded-full bg-sky-500/20 text-sky-300 text-[10px] flex items-center justify-center font-bold">
              {enabledExtensionsCount}
            </span>
          </button>
        </div>
      </div>

      {/* Featured Recommendation Hero Spotlight */}
      {featuredNovel && (
        <div className="relative rounded-3xl bg-gradient-to-r from-neutral-900 via-neutral-900 to-sky-950/40 border border-neutral-800/80 p-5 sm:p-7 shadow-2xl overflow-hidden flex flex-col md:flex-row items-center gap-6">
          <div className="relative w-32 sm:w-40 aspect-[2/3] rounded-2xl overflow-hidden shadow-2xl flex-shrink-0 border border-neutral-700/60">
            <img
              src={featuredNovel.coverUrl}
              alt={featuredNovel.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-amber-500 text-neutral-950 text-[10px] font-bold flex items-center gap-1 shadow">
              <Sparkles className="w-3 h-3 fill-neutral-950" /> Featured
            </div>
          </div>

          <div className="flex-1 flex flex-col justify-between text-center md:text-left">
            <div>
              <div className="flex items-center justify-center md:justify-start gap-2 mb-1.5">
                <span className="text-[11px] uppercase tracking-wider text-sky-400 font-bold">
                  {featuredNovel.sourceName}
                </span>
                <span className="text-neutral-500">•</span>
                <span className="text-[11px] text-amber-400 font-semibold flex items-center gap-1">
                  <Star className="w-3 h-3 fill-amber-400" /> {featuredNovel.rating || '4.9'}
                </span>
              </div>

              <h2 className="text-xl sm:text-2xl font-black text-neutral-100 tracking-tight">
                {featuredNovel.title}
              </h2>
              <p className="text-xs text-neutral-400 mt-0.5">By {featuredNovel.author}</p>
              <p className="text-xs sm:text-sm text-neutral-300 mt-2.5 line-clamp-3 leading-relaxed max-w-2xl">
                {featuredNovel.description}
              </p>

              <div className="flex flex-wrap items-center justify-center md:justify-start gap-1.5 mt-3">
                {featuredNovel.genres.map((g, i) => (
                  <span
                    key={i}
                    className="px-2.5 py-0.5 rounded-full bg-neutral-800/80 text-[10px] text-neutral-300 border border-neutral-700/60 font-medium"
                  >
                    {g}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-center md:justify-start gap-2.5 mt-5">
              <button
                onClick={() => {
                  handleAddToLibrary(featuredNovel);
                  onOpenReader(featuredNovel, 0);
                }}
                className="px-5 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-neutral-950 font-bold text-xs flex items-center gap-2 transition active:scale-95 shadow-lg shadow-sky-500/20"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Start Reading Now</span>
              </button>

              <button
                onClick={() => handleAddToLibrary(featuredNovel)}
                className="px-4 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-200 text-xs font-semibold flex items-center gap-1.5 transition active:scale-95"
              >
                {savedNovelIds.has(featuredNovel.id) ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>In Library</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add to Library</span>
                  </>
                )}
              </button>

              <button
                onClick={() => setInspectingNovel(featuredNovel)}
                className="px-3.5 py-2.5 rounded-xl bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 text-xs font-medium transition"
              >
                Chapter List ({featuredNovel.chapters.length})
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Novel Providers Grid */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-sky-400" />
            <h3 className="text-sm font-bold uppercase tracking-wider text-neutral-200">
              Active Repositories ({extensions.length})
            </h3>
          </div>
          <button
            onClick={() => setShowRepoSettingsModal(true)}
            className="text-xs text-sky-400 hover:text-sky-300 font-semibold flex items-center gap-1 transition"
          >
            <span>Manage & Add Repos</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {extensions.map((ext) => (
            <div
              key={ext.id}
              onClick={() => setSelectedProviderId(selectedProviderId === ext.id ? 'all' : ext.id)}
              className={`p-4 rounded-2xl border transition cursor-pointer flex items-center justify-between gap-3 ${
                selectedProviderId === ext.id
                  ? 'bg-sky-500/10 border-sky-500 shadow-md shadow-sky-500/10'
                  : 'bg-neutral-900/70 border-neutral-800 hover:border-neutral-700'
              } ${!ext.enabled ? 'opacity-50' : ''}`}
            >
              <div className="flex items-center gap-3.5 overflow-hidden">
                <span className="text-3xl p-2 rounded-xl bg-neutral-950 border border-neutral-800 flex-shrink-0">
                  {ext.icon}
                </span>
                <div className="overflow-hidden">
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-xs text-neutral-100 truncate">{ext.name}</h4>
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-neutral-800 text-neutral-400">
                      v{ext.version}
                    </span>
                  </div>
                  <p className="text-[11px] text-neutral-400 truncate mt-0.5">{ext.description}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[10px] text-sky-400 font-medium">
                      {ext.novels.length} novels
                    </span>
                    <span className="text-neutral-600">•</span>
                    <span className="text-[10px] text-neutral-500">{ext.language}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 flex-shrink-0">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleExtension(ext.id);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border transition ${
                    ext.enabled
                      ? 'bg-sky-500/20 text-sky-300 border-sky-500/40'
                      : 'bg-neutral-800 text-neutral-400 border-neutral-700'
                  }`}
                >
                  {ext.enabled ? 'Active' : 'Off'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Search, Language & Genre Filters Bar */}
      <div className="flex flex-col gap-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Search input */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
            <input
              type="text"
              placeholder="Search across all repositories..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-neutral-900/90 border border-neutral-800 rounded-xl text-xs sm:text-sm text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-sky-500 transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-neutral-300 text-xs"
              >
                Clear
              </button>
            )}
          </div>

          {/* Language Filter */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            {allLanguages.map((lang) => (
              <button
                key={lang}
                onClick={() => setSelectedLanguage(lang)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition whitespace-nowrap active:scale-95 ${
                  selectedLanguage === lang
                    ? 'bg-sky-500 text-neutral-950 shadow'
                    : 'bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-800 text-neutral-400'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>
        </div>

        {/* Genre Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {allGenres.map((genre) => (
            <button
              key={genre}
              onClick={() => setSelectedGenre(genre)}
              className={`px-3 py-1 rounded-full text-[11px] font-medium transition whitespace-nowrap ${
                selectedGenre === genre
                  ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 font-bold'
                  : 'bg-neutral-900/60 border border-neutral-800/80 text-neutral-400 hover:text-neutral-200'
              }`}
            >
              {genre}
            </button>
          ))}
        </div>
      </div>

      {/* Novels Grid */}
      {filteredNovels.length === 0 ? (
        <div className="p-12 border border-neutral-800 rounded-2xl bg-neutral-900/30 text-center flex flex-col items-center justify-center max-w-md mx-auto my-6">
          <div className="w-16 h-16 rounded-2xl bg-neutral-800/60 flex items-center justify-center mb-4 text-3xl">
            🔍
          </div>
          <h3 className="text-base font-bold text-neutral-200">No Novels Found</h3>
          <p className="text-xs text-neutral-400 mt-1 text-center">
            No novels matched your current filter criteria. Make sure the relevant repositories are enabled.
          </p>
          <div className="flex gap-2 mt-5">
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedGenre('All');
                setSelectedLanguage('All');
                setSelectedProviderId('all');
              }}
              className="px-4 py-2 rounded-xl bg-sky-500 text-neutral-950 font-bold text-xs"
            >
              Reset Filters
            </button>
            <button
              onClick={() => setShowRepoSettingsModal(true)}
              className="px-4 py-2 rounded-xl bg-neutral-800 text-neutral-200 font-semibold text-xs"
            >
              Check Enabled Repos
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-5">
          {filteredNovels.map((novel) => {
            const isSaved = savedNovelIds.has(novel.id);

            return (
              <div
                key={novel.id}
                className="group relative flex flex-col bg-neutral-900/80 border border-neutral-800 rounded-2xl overflow-hidden hover:border-neutral-700 transition shadow-lg hover:shadow-2xl"
              >
                {/* Cover & Badges */}
                <div
                  className="relative aspect-[2/3] w-full overflow-hidden bg-neutral-950 cursor-pointer"
                  onClick={() => setInspectingNovel(novel)}
                >
                  <img
                    src={novel.coverUrl}
                    alt={novel.title}
                    className="w-full h-full object-cover transition duration-300 group-hover:scale-105"
                    loading="lazy"
                  />

                  {/* Provider Pill Badge */}
                  <div className="absolute top-2 left-2 px-1.5 py-0.5 rounded-md bg-neutral-950/80 backdrop-blur-md text-sky-400 text-[9px] font-bold border border-white/10 shadow">
                    {novel.sourceName}
                  </div>

                  {/* Rating */}
                  {novel.rating && (
                    <div className="absolute top-2 right-2 px-1.5 py-0.5 rounded-md bg-neutral-950/80 backdrop-blur-md text-amber-400 text-[10px] font-bold flex items-center gap-0.5 shadow">
                      <Star className="w-2.5 h-2.5 fill-amber-400" />
                      <span>{novel.rating}</span>
                    </div>
                  )}

                  {/* Quick Read Overlay Button */}
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-3">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleAddToLibrary(novel);
                        onOpenReader(novel, 0);
                      }}
                      className="px-3.5 py-2 rounded-xl bg-sky-500 hover:bg-sky-400 text-neutral-950 text-xs font-bold flex items-center gap-1.5 shadow-lg active:scale-95 transition"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>Read Ch. 1</span>
                    </button>
                  </div>
                </div>

                {/* Details */}
                <div className="p-3 flex flex-col flex-1 justify-between">
                  <div>
                    <h4
                      onClick={() => setInspectingNovel(novel)}
                      className="text-xs font-bold text-neutral-200 line-clamp-1 group-hover:text-sky-400 transition cursor-pointer"
                      title={novel.title}
                    >
                      {novel.title}
                    </h4>
                    <p className="text-[11px] text-neutral-500 line-clamp-1 mt-0.5">{novel.author}</p>
                  </div>

                  <div className="mt-3 pt-2 border-t border-neutral-800/60 flex items-center justify-between text-[11px]">
                    <span className="text-neutral-400">{novel.chapters.length} chapters</span>

                    <button
                      onClick={() => handleAddToLibrary(novel)}
                      className={`p-1.5 rounded-lg border transition ${
                        isSaved
                          ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-400'
                          : 'bg-neutral-800 hover:bg-neutral-700 border-neutral-700 text-neutral-200'
                      }`}
                      title={isSaved ? 'Already saved in library' : 'Save novel to bookshelf'}
                    >
                      {isSaved ? <Check className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Novel Details, Chapters, Ratings & Provider Reviews Modal */}
      {inspectingNovel && (
        <NovelDetailsModal
          novel={inspectingNovel}
          isOpen={!!inspectingNovel}
          isInLibrary={savedNovelIds.has(inspectingNovel.id)}
          onClose={() => setInspectingNovel(null)}
          onOpenReader={onOpenReader}
          onToggleLibrary={(nov, status) => {
            const updated = status ? { ...nov, status } : nov;
            handleAddToLibrary(updated);
          }}
          onUpdateNovel={(updated) => {
            handleAddToLibrary(updated);
            setInspectingNovel(updated);
          }}
        />
      )}

      {/* Extension Repositories & Plugin Manager Modal */}
      {showRepoSettingsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-sm"
            onClick={() => setShowRepoSettingsModal(false)}
          />
          <div className="relative z-10 w-full max-w-xl bg-neutral-900 border border-neutral-800 rounded-3xl p-6 sm:p-7 shadow-2xl flex flex-col gap-5">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-sky-500/15 border border-sky-500/30 text-sky-400 flex items-center justify-center">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-neutral-100">
                    Extension Repositories & Feeds
                  </h3>
                  <p className="text-[11px] text-neutral-400">
                    Manage installed providers and subscribe to community novel repositories
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowRepoSettingsModal(false)}
                className="p-1 rounded-xl text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Notification alert */}
            {repoSuccessMsg && (
              <div className="p-3 bg-emerald-950/40 border border-emerald-800/60 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>{repoSuccessMsg}</span>
              </div>
            )}

            {/* Sub-tabs inside modal */}
            <div className="flex items-center gap-2 p-1 bg-neutral-950 rounded-2xl border border-neutral-800 text-xs">
              <button
                onClick={() => setActiveRepoTab('community')}
                className={`flex-1 py-2 rounded-xl font-bold transition flex items-center justify-center gap-1.5 ${
                  activeRepoTab === 'community'
                    ? 'bg-sky-500 text-neutral-950 shadow'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Globe className="w-3.5 h-3.5" />
                <span>Community Registry</span>
              </button>
              <button
                onClick={() => setActiveRepoTab('installed')}
                className={`flex-1 py-2 rounded-xl font-bold transition flex items-center justify-center gap-1.5 ${
                  activeRepoTab === 'installed'
                    ? 'bg-sky-500 text-neutral-950 shadow'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Installed ({extensions.length})</span>
              </button>
              <button
                onClick={() => setActiveRepoTab('custom')}
                className={`flex-1 py-2 rounded-xl font-bold transition flex items-center justify-center gap-1.5 ${
                  activeRepoTab === 'custom'
                    ? 'bg-sky-500 text-neutral-950 shadow'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>Add Custom URL</span>
              </button>
            </div>

            {/* TAB 1: Community Repositories Hub */}
            {activeRepoTab === 'community' && (
              <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400 block">
                  Popular Community Repositories ({POPULAR_COMMUNITY_REPOS.length})
                </span>
                <div className="space-y-2.5">
                  {POPULAR_COMMUNITY_REPOS.map((repo) => {
                    const isInstalled = extensions.some((e) => e.repoUrl === repo.url || e.id === repo.id);
                    return (
                      <div
                        key={repo.id}
                        className="p-3.5 rounded-2xl bg-neutral-950/80 border border-neutral-800/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 group hover:border-neutral-700 transition"
                      >
                        <div className="flex items-start gap-3 min-w-0">
                          <span className="text-2xl p-2 rounded-xl bg-neutral-900 border border-neutral-800">
                            {repo.icon}
                          </span>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <h4 className="text-xs font-bold text-neutral-100">{repo.name}</h4>
                              <span className="text-[10px] text-neutral-500">by {repo.author}</span>
                            </div>
                            <p className="text-[11px] text-neutral-400 line-clamp-1 mt-0.5">
                              {repo.description}
                            </p>
                            <div className="flex items-center gap-2 mt-1.5 text-[10px] text-neutral-500">
                              <span className="text-sky-400 font-semibold">{repo.sourceCount} sources</span>
                              <span>•</span>
                              <span>{repo.languages.join(', ')}</span>
                            </div>
                          </div>
                        </div>

                        <button
                          onClick={() => handleInstallCommunityRepo(repo)}
                          className={`w-full sm:w-auto px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition active:scale-95 flex-shrink-0 ${
                            isInstalled
                              ? 'bg-emerald-950/60 border border-emerald-500/40 text-emerald-300'
                              : 'bg-sky-500 hover:bg-sky-400 text-neutral-950 shadow-md shadow-sky-500/20'
                          }`}
                        >
                          {isInstalled ? (
                            <>
                              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                              <span>Subscribed</span>
                            </>
                          ) : (
                            <>
                              <Plus className="w-3.5 h-3.5" />
                              <span>Install Repo</span>
                            </>
                          )}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TAB 2: Installed Providers Toggle */}
            {activeRepoTab === 'installed' && (
              <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400 block mb-1">
                  Active & Installed Providers
                </span>
                {extensions.map((ext) => (
                  <div
                    key={ext.id}
                    className="p-3.5 rounded-2xl bg-neutral-950/80 border border-neutral-800 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="text-2xl p-1.5 rounded-xl bg-neutral-900 border border-neutral-800">
                        {ext.icon}
                      </span>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-bold text-neutral-200 truncate">{ext.name}</h4>
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-neutral-800 text-neutral-400 font-mono">
                            v{ext.version}
                          </span>
                        </div>
                        <p className="text-[10px] text-neutral-500 truncate mt-0.5">
                          {ext.language} • {ext.novels.length} novels cataloged
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => toggleExtension(ext.id)}
                      className={`px-3 py-1.5 rounded-xl text-[11px] font-bold border transition ${
                        ext.enabled
                          ? 'bg-sky-500/10 border-sky-500/40 text-sky-400'
                          : 'bg-neutral-800 border-neutral-700 text-neutral-500'
                      }`}
                    >
                      {ext.enabled ? 'Enabled' : 'Disabled'}
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* TAB 3: Add Custom Manifest Repo URL */}
            {activeRepoTab === 'custom' && (
              <div className="space-y-3.5">
                <span className="text-xs font-semibold uppercase tracking-wider text-neutral-400 block">
                  Link Custom JSON Manifest or Git Repository
                </span>
                <div className="space-y-2.5">
                  <div>
                    <label className="text-[11px] text-neutral-400 block mb-1 font-medium">
                      Repository Display Name:
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. My Private Webnovel Hub"
                      value={customRepoName}
                      onChange={(e) => setCustomRepoName(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-sky-500"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-neutral-400 block mb-1 font-medium">
                      Manifest URL (.json or Raw GitHub URL):
                    </label>
                    <input
                      type="url"
                      placeholder="https://raw.githubusercontent.com/.../repo.json"
                      value={customRepoUrl}
                      onChange={(e) => setCustomRepoUrl(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-sky-500"
                    />
                  </div>
                  <button
                    onClick={handleAddCustomRepo}
                    disabled={!customRepoUrl.trim()}
                    className="w-full py-2.5 bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-neutral-950 font-bold text-xs rounded-xl shadow-md transition"
                  >
                    Link & Import Custom Repository
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Share Toast Feedback */}
      {shareToast && (
        <div className="fixed bottom-20 sm:bottom-8 left-1/2 -translate-x-1/2 z-50 bg-neutral-900 border border-sky-500/50 text-neutral-100 text-xs px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-sky-400 flex-shrink-0" />
          <span>{shareToast}</span>
        </div>
      )}
    </div>
  );
};
