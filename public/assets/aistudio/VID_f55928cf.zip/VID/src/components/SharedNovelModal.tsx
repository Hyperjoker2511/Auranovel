import React, { useState } from 'react';
import { Share2, BookOpen, Plus, Check, X, Sparkles } from 'lucide-react';
import { Novel } from '../types/novel';

interface SharedNovelModalProps {
  sharedNovel: Novel | null;
  onClose: () => void;
  onAddToLibrary: (novel: Novel) => void;
  onReadImmediately: (novel: Novel) => void;
}

export const SharedNovelModal: React.FC<SharedNovelModalProps> = ({
  sharedNovel,
  onClose,
  onAddToLibrary,
  onReadImmediately,
}) => {
  const [added, setAdded] = useState(false);

  if (!sharedNovel) return null;

  const handleAdd = () => {
    onAddToLibrary(sharedNovel);
    setAdded(true);
    setTimeout(() => {
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 w-full max-w-lg bg-neutral-900 border border-neutral-800 rounded-3xl p-6 shadow-2xl flex flex-col gap-5 overflow-hidden">
        {/* Header Tag */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
              <Share2 className="w-4 h-4" />
            </span>
            <div>
              <h3 className="font-bold text-sm text-neutral-100 flex items-center gap-1.5">
                <span>Shared Novel Link</span>
                <Sparkles className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              </h3>
              <p className="text-[11px] text-neutral-400">
                A friend shared this book with you to read on AetherNovel
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-neutral-400 hover:text-neutral-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Novel Card */}
        <div className="flex gap-4">
          <div className="relative w-28 sm:w-32 aspect-[2/3] rounded-2xl overflow-hidden shadow-lg border border-neutral-800 bg-neutral-950 flex-shrink-0">
            {sharedNovel.coverUrl ? (
              <img
                src={sharedNovel.coverUrl}
                alt={sharedNovel.title}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-3xl">
                📖
              </div>
            )}
            <div className="absolute top-2 left-2 px-1.5 py-0.5 rounded bg-neutral-950/80 backdrop-blur-md text-[9px] font-mono text-neutral-300">
              {sharedNovel.sourceName?.split(' ')[0] || 'Shared'}
            </div>
          </div>

          <div className="flex-1 flex flex-col justify-between overflow-hidden">
            <div>
              <h4 className="text-base sm:text-lg font-black text-neutral-100 line-clamp-2">
                {sharedNovel.title}
              </h4>
              <p className="text-xs text-neutral-400 mt-0.5">By {sharedNovel.author}</p>

              <div className="flex flex-wrap gap-1 mt-2">
                {sharedNovel.genres?.slice(0, 3).map((g, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded-full bg-neutral-800 text-[10px] text-neutral-300"
                  >
                    {g}
                  </span>
                ))}
              </div>

              <p className="text-xs text-neutral-400 mt-2.5 line-clamp-3 leading-relaxed">
                {sharedNovel.description}
              </p>
            </div>

            <span className="text-[11px] text-amber-400/90 font-medium mt-2">
              {sharedNovel.chapters?.length || sharedNovel.totalChapters} chapters available
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-2.5 pt-2 border-t border-neutral-800">
          <button
            onClick={() => onReadImmediately(sharedNovel)}
            className="w-full sm:flex-1 py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs flex items-center justify-center gap-2 transition active:scale-95 shadow-lg shadow-amber-500/20"
          >
            <BookOpen className="w-4 h-4" />
            <span>Read Chapter 1 Now</span>
          </button>

          <button
            onClick={handleAdd}
            disabled={added}
            className={`w-full sm:w-auto py-2.5 px-4 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition active:scale-95 ${
              added
                ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400'
                : 'bg-neutral-800 hover:bg-neutral-700 border-neutral-700 text-neutral-200'
            }`}
          >
            {added ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Added to Library!</span>
              </>
            ) : (
              <>
                <Plus className="w-4 h-4 text-sky-400" />
                <span>Add to Library</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
