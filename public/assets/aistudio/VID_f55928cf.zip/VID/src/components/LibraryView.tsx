import React, { useState, useEffect } from 'react';
import {
  BookMarked,
  Search,
  BookOpen,
  MoreVertical,
  Trash2,
  CheckCircle,
  FileUp,
  Compass,
  Globe,
  Plus,
  Clock,
  Sparkles,
  ArrowRight,
  Heart,
  Download,
  BookX,
  Layers,
  Filter,
  SlidersHorizontal,
  X,
  ArrowUpDown,
  Share2,
} from 'lucide-react';
import { Novel, ReadingStats, ReaderSettings, ReadingStatus } from '../types/novel';
import { getDownloadedChapterIndices, saveNovel } from '../utils/storage';
import { estimateTimeRemaining } from '../utils/progression';
import { generateNovelShareLink } from '../utils/shareUtils';
import { NovelDetailsModal } from './NovelDetailsModal';

interface LibraryViewProps {
  novels: Novel[];
  stats?: ReadingStats;
  settings: ReaderSettings;
  onOpenReader: (novel: Novel, initialChapterIndex: number) => void;
  onDeleteNovel: (novelId: string) => void;
  onUpdateNovel: (novel: Novel) => void;
  onNavigateTab: (tab: 'library' | 'history' | 'discover' | 'browser' | 'me' | 'settings') => void;
  onTriggerEpubUpload: () => void;
}

export const LibraryView: React.FC<LibraryViewProps> = ({
  novels,
  stats,
  settings,
  onOpenReader,
  onDeleteNovel,
  onUpdateNovel,
  onNavigateTab,
  onTriggerEpubUpload,
}) => {
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'recent' | 'title' | 'progress'>('recent');
  const [activeMenuNovelId, setActiveMenuNovelId] = useState<string | null>(null);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [downloadedNovelIds, setDownloadedNovelIds] = useState<Set<string>>(new Set());
  const [shareToast, setShareToast] = useState<string | null>(null);
  const [selectedNovelForDetails, setSelectedNovelForDetails] = useState<Novel | null>(null);

  const handleShareNovel = async (novel: Novel) => {
    const link = generateNovelShareLink(novel);
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(link);
      } else {
        prompt('Copy this novel link to share:', link);
      }
      setShareToast(`Link copied! Friends opening it can read & save "${novel.title}".`);
      setTimeout(() => setShareToast(null), 4000);
    } catch {
      prompt('Copy this novel link to share:', link);
    }
  };

  // Check which novels have offline downloaded chapters
  useEffect(() => {
    async function checkDownloaded() {
      const downloadedSet = new Set<string>();
      for (const novel of novels) {
        if (novel.sourceType === 'epub') {
          downloadedSet.add(novel.id);
        } else {
          const chs = await getDownloadedChapterIndices(novel.id);
          if (chs.size > 0) {
            downloadedSet.add(novel.id);
          }
        }
      }
      setDownloadedNovelIds(downloadedSet);
    }
    checkDownloaded();
  }, [novels]);

  // Find most recently read active novel for Stats widget
  const currentActiveBook =
    novels.find((n) => n.status === 'reading') ||
    [...novels].sort((a, b) => (b.lastReadAt || 0) - (a.lastReadAt || 0))[0] ||
    null;

  const toggleFavorite = (e: React.MouseEvent, novel: Novel) => {
    e.stopPropagation();
    const updated: Novel = { ...novel, isFavorite: !novel.isFavorite };
    saveNovel(updated);
    onUpdateNovel(updated);
  };

  const setNovelStatus = (novel: Novel, newStatus: ReadingStatus) => {
    const updated: Novel = { ...novel, status: newStatus };
    saveNovel(updated);
    onUpdateNovel(updated);
    setActiveMenuNovelId(null);
  };

  const filteredNovels = novels
    .filter((n) => {
      const matchesSearch =
        n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        n.author.toLowerCase().includes(searchQuery.toLowerCase());

      if (!matchesSearch) return false;

      if (activeFilter === 'all') return true;
      if (activeFilter === 'favorites') return !!n.isFavorite;
      if (activeFilter === 'reading') return n.status === 'reading';
      if (activeFilter === 'downloaded') return downloadedNovelIds.has(n.id);
      if (activeFilter === 'non_reading') return n.status === 'plan_to_read' || n.status === 'on_hold';
      if (activeFilter === 'completed') return n.status === 'completed';
      if (activeFilter === 'epub') return n.sourceType === 'epub';
      if (activeFilter === 'web') return n.sourceType === 'web';
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'title') return a.title.localeCompare(b.title);
      if (sortBy === 'progress') {
        const progA = a.totalChapters > 0 ? (a.currentChapterIndex || 0) / a.totalChapters : 0;
        const progB = b.totalChapters > 0 ? (b.currentChapterIndex || 0) / b.totalChapters : 0;
        return progB - progA;
      }
      // default: 'recent'
      return (b.lastReadAt || 0) - (a.lastReadAt || 0);
    });

  const filterLabels: Record<string, string> = {
    all: 'All Books',
    favorites: 'Favorites ❤️',
    reading: 'Currently Reading',
    downloaded: 'Downloaded Offline 📥',
    non_reading: 'Plan to Read',
    completed: 'Completed',
    epub: 'EPUB E-Books',
    web: 'Web Articles',
  };

  return (
    <div className="flex-1 w-full max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 flex flex-col gap-6">
      {/* Top Search & Filter Bar with My Bookshelf tucked in upper right corner away from view */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Search Bar */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
          <input
            type="text"
            placeholder="Search novels, authors..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-neutral-900/90 border border-neutral-800 rounded-xl text-xs sm:text-sm text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500 transition"
          />
        </div>

        {/* Right Side: Filter & Sort + My Bookshelf tucked in the corner */}
        <div className="flex items-center gap-2.5 justify-between sm:justify-end">
          {activeFilter !== 'all' && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-medium">
              <span>{filterLabels[activeFilter] || activeFilter}</span>
              <button
                onClick={() => setActiveFilter('all')}
                className="hover:text-white p-0.5"
                title="Clear filter"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          <button
            onClick={() => setShowFilterModal(true)}
            className={`px-3.5 py-2.5 rounded-xl border text-xs font-semibold flex items-center gap-2 transition active:scale-95 ${
              activeFilter !== 'all'
                ? 'bg-amber-500/15 border-amber-500/50 text-amber-300 shadow-sm'
                : 'bg-neutral-900 hover:bg-neutral-800 border-neutral-800 text-neutral-200'
            }`}
          >
            <SlidersHorizontal className="w-4 h-4" />
            <span>Filter & Sort</span>
            {activeFilter !== 'all' && (
              <span className="w-2 h-2 rounded-full bg-amber-400" />
            )}
          </button>

          {/* My Bookshelf tucked away in upper right corner */}
          <div className="px-3 py-2 rounded-xl bg-neutral-900/70 border border-neutral-800/80 flex items-center gap-2 text-xs text-neutral-400 shadow-sm">
            <BookMarked className="w-3.5 h-3.5 text-amber-500/80" />
            <span className="text-neutral-400 font-medium hidden sm:inline">My Bookshelf</span>
            <span className="text-neutral-600 hidden sm:inline">•</span>
            <span className="text-amber-400 font-mono font-semibold">{novels.length} {novels.length === 1 ? 'novel' : 'novels'}</span>
          </div>
        </div>
      </div>

      {/* Novels Grid - Tablet 2-4 cols, Desktop 5-6 cols */}
      {filteredNovels.length === 0 ? (
        <div className="p-12 sm:p-16 border border-neutral-800/80 rounded-2xl bg-neutral-900/30 text-center flex flex-col items-center justify-center max-w-lg mx-auto my-6">
          <div className="w-16 h-16 rounded-2xl bg-neutral-800/60 border border-neutral-700/60 flex items-center justify-center mb-4 text-3xl">
            📖
          </div>
          <h3 className="text-base font-bold text-neutral-200">
            {activeFilter !== 'all' ? `No books matching "${filterLabels[activeFilter]}"` : 'No Books in Library Yet'}
          </h3>
          <p className="text-xs text-neutral-400 mt-1 max-w-sm text-center">
            {activeFilter !== 'all'
              ? 'Try selecting a different filter option or clearing the current selection.'
              : 'Discover novels from community providers or upload your own EPUBs.'}
          </p>

          <div className="flex flex-wrap items-center justify-center gap-2.5 mt-6">
            {activeFilter !== 'all' ? (
              <button
                onClick={() => setActiveFilter('all')}
                className="px-4 py-2 rounded-xl bg-amber-500 text-neutral-950 font-bold text-xs"
              >
                Reset Filter
              </button>
            ) : (
              <>
                <button
                  onClick={() => onNavigateTab('discover')}
                  className="px-4 py-2 rounded-xl bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-medium flex items-center gap-1.5 hover:bg-sky-500/20 transition"
                >
                  <Compass className="w-3.5 h-3.5" />
                  <span>Explore Novel Providers</span>
                </button>
                <button
                  onClick={onTriggerEpubUpload}
                  className="px-4 py-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-medium flex items-center gap-1.5 hover:bg-amber-500/20 transition"
                >
                  <FileUp className="w-3.5 h-3.5" />
                  <span>Import EPUB</span>
                </button>
              </>
            )}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 sm:gap-5">
          {filteredNovels.map((novel) => {
            const currentCh = novel.currentChapterIndex || 0;
            const progress =
              novel.totalChapters > 0
                ? Math.round(((currentCh + 1) / novel.totalChapters) * 100)
                : 0;
            const isDownloaded = downloadedNovelIds.has(novel.id);
            const remaining = estimateTimeRemaining(novel, settings.wpmReadingSpeed || 240);

            return (
              <div
                key={novel.id}
                className="group relative flex flex-col bg-neutral-900/80 border border-neutral-800 rounded-2xl overflow-hidden hover:border-neutral-700 transition shadow-lg hover:shadow-2xl"
              >
                {/* Cover & Badges */}
                <div
                  className="relative aspect-[2/3] w-full overflow-hidden bg-neutral-950 cursor-pointer"
                  onClick={() => setSelectedNovelForDetails(novel)}
                >
                  {novel.coverUrl ? (
                    <img
                      src={novel.coverUrl}
                      alt={novel.title}
                      className="w-full h-full object-cover transition duration-300 group-hover:scale-105"
                      loading="lazy"
                    />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center p-3 text-center bg-gradient-to-br from-neutral-800 to-neutral-950 text-neutral-400">
                      <span className="text-3xl mb-1">📖</span>
                      <span className="text-[11px] font-bold line-clamp-2">{novel.title}</span>
                    </div>
                  )}

                  {/* Quick Direct Reading Shortcut Button on hover */}
                  <div className="absolute inset-0 bg-black/45 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-2.5 pointer-events-none">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenReader(novel, novel.currentChapterIndex || 0);
                      }}
                      className="pointer-events-auto px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs font-bold flex items-center gap-1.5 shadow-xl active:scale-95 transition"
                      title="Continue reading directly"
                    >
                      <BookOpen className="w-3.5 h-3.5 stroke-[2.2]" />
                      <span>Resume Ch. {currentCh + 1}</span>
                    </button>
                  </div>

                  {/* Favorite Toggle Button */}
                  <button
                    onClick={(e) => toggleFavorite(e, novel)}
                    className="absolute top-2 left-2 p-1.5 rounded-full bg-neutral-950/80 backdrop-blur-md text-neutral-400 hover:text-rose-400 transition"
                    title={novel.isFavorite ? 'Remove from favorites' : 'Add to favorites'}
                  >
                    <Heart
                      className={`w-3.5 h-3.5 ${
                        novel.isFavorite ? 'text-rose-500 fill-rose-500' : 'text-neutral-400'
                      }`}
                    />
                  </button>

                  {/* Downloaded Offline Badge */}
                  {isDownloaded && (
                    <div className="absolute bottom-2 left-2 px-1.5 py-0.5 rounded-md bg-sky-500/90 text-neutral-950 text-[9px] font-bold flex items-center gap-0.5 shadow">
                      <Download className="w-2.5 h-2.5" />
                      <span>Cached</span>
                    </div>
                  )}

                  {/* Menu Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveMenuNovelId(activeMenuNovelId === novel.id ? null : novel.id);
                    }}
                    className="absolute top-2 right-2 p-1.5 rounded-lg bg-neutral-950/80 backdrop-blur-md text-neutral-400 hover:text-neutral-100 transition"
                  >
                    <MoreVertical className="w-3.5 h-3.5" />
                  </button>

                  {/* Dropdown Menu */}
                  {activeMenuNovelId === novel.id && (
                    <div
                      className="absolute top-10 right-2 z-20 w-48 bg-neutral-900 border border-neutral-800 rounded-xl shadow-2xl p-1.5 text-xs"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <button
                        onClick={() => {
                          setSelectedNovelForDetails(novel);
                          setActiveMenuNovelId(null);
                        }}
                        className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-neutral-800 flex items-center gap-2 text-sky-400 font-semibold"
                      >
                        <Layers className="w-3.5 h-3.5" /> Synopsis & Chapters
                      </button>

                      <button
                        onClick={() => {
                          onOpenReader(novel, novel.currentChapterIndex || 0);
                          setActiveMenuNovelId(null);
                        }}
                        className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-neutral-800 flex items-center gap-2 text-neutral-200"
                      >
                        <BookOpen className="w-3.5 h-3.5" /> Continue Reading
                      </button>

                      <button
                        onClick={() => {
                          handleShareNovel(novel);
                          setActiveMenuNovelId(null);
                        }}
                        className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-neutral-800 flex items-center gap-2 text-sky-400"
                      >
                        <Share2 className="w-3.5 h-3.5" /> Share Novel Link
                      </button>

                      <div className="px-2 py-1 text-[10px] text-neutral-500 uppercase tracking-wider font-semibold border-t border-neutral-800 mt-1">
                        Status
                      </div>
                      <button
                        onClick={() => setNovelStatus(novel, 'reading')}
                        className={`w-full text-left px-2.5 py-1 rounded-lg text-[11px] ${
                          novel.status === 'reading' ? 'text-amber-400 font-bold' : 'text-neutral-300'
                        }`}
                      >
                        • Currently Reading
                      </button>
                      <button
                        onClick={() => setNovelStatus(novel, 'plan_to_read')}
                        className={`w-full text-left px-2.5 py-1 rounded-lg text-[11px] ${
                          novel.status === 'plan_to_read' ? 'text-amber-400 font-bold' : 'text-neutral-300'
                        }`}
                      >
                        • Plan to Read
                      </button>
                      <button
                        onClick={() => setNovelStatus(novel, 'completed')}
                        className={`w-full text-left px-2.5 py-1 rounded-lg text-[11px] ${
                          novel.status === 'completed' ? 'text-amber-400 font-bold' : 'text-neutral-300'
                        }`}
                      >
                        • Completed
                      </button>

                      <div className="border-t border-neutral-800 mt-1 pt-1">
                        <button
                          onClick={() => {
                            onDeleteNovel(novel.id);
                            setActiveMenuNovelId(null);
                          }}
                          className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-rose-950 text-rose-400 flex items-center gap-2"
                        >
                          <Trash2 className="w-3.5 h-3.5" /> Remove from Library
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Progress bar overlay */}
                  <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/60">
                    <div
                      className="h-full bg-amber-500 transition-all duration-300"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>

                {/* Info Card */}
                <div
                  className="p-3 flex flex-col flex-1 justify-between cursor-pointer"
                  onClick={() => setSelectedNovelForDetails(novel)}
                >
                  <div>
                    <h3 className="text-xs font-bold text-neutral-200 line-clamp-1 group-hover:text-amber-400 transition">
                      {novel.title}
                    </h3>
                    <p className="text-[11px] text-neutral-500 line-clamp-1 mt-0.5">{novel.author}</p>
                  </div>

                  <div className="mt-2.5 pt-2 border-t border-neutral-800/60 flex flex-col gap-1 text-[11px] text-neutral-400">
                    <div className="flex items-center justify-between">
                      <span>
                        Ch {currentCh + 1} / {novel.totalChapters}
                      </span>
                      <span className="text-amber-400/90 font-mono font-medium">{progress}%</span>
                    </div>

                    <div className="text-[10px] text-neutral-500 flex items-center gap-1">
                      <Clock className="w-2.5 h-2.5" />
                      <span>{remaining.formatted} left</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Separate Filter & Status Options Drawer Modal */}
      {showFilterModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/75 backdrop-blur-sm"
            onClick={() => setShowFilterModal(false)}
          />
          <div className="relative z-10 w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-2xl flex flex-col gap-5">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2 font-bold text-sm text-neutral-100">
                <SlidersHorizontal className="w-4 h-4 text-amber-400" />
                <span>Library Filter & Status Options</span>
              </div>
              <button
                onClick={() => setShowFilterModal(false)}
                className="p-1 rounded-lg text-neutral-400 hover:text-neutral-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Reading Status Options */}
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-neutral-400 block mb-2">
                Reading Status
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {[
                  { id: 'all', label: 'All Novels' },
                  { id: 'reading', label: 'Currently Reading' },
                  { id: 'non_reading', label: 'Plan to Read / On Hold' },
                  { id: 'completed', label: 'Completed' },
                ].map((s) => (
                  <button
                    key={s.id}
                    onClick={() => {
                      setActiveFilter(s.id);
                    }}
                    className={`p-2.5 rounded-xl border text-left transition font-medium ${
                      activeFilter === s.id
                        ? 'bg-amber-500 text-neutral-950 font-bold border-amber-500'
                        : 'bg-neutral-950/60 border-neutral-800 text-neutral-300 hover:border-neutral-700'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Special Collections & Types */}
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-neutral-400 block mb-2">
                Special Collections
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                {[
                  { id: 'favorites', label: 'Favorites ❤️' },
                  { id: 'downloaded', label: 'Downloaded Offline 📥' },
                  { id: 'epub', label: 'EPUB E-Books 📖' },
                  { id: 'web', label: 'Web Reader 🌐' },
                ].map((c) => (
                  <button
                    key={c.id}
                    onClick={() => {
                      setActiveFilter(c.id);
                    }}
                    className={`p-2.5 rounded-xl border text-left transition font-medium ${
                      activeFilter === c.id
                        ? 'bg-amber-500 text-neutral-950 font-bold border-amber-500'
                        : 'bg-neutral-950/60 border-neutral-800 text-neutral-300 hover:border-neutral-700'
                    }`}
                  >
                    {c.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Sort Order */}
            <div>
              <label className="text-xs font-semibold uppercase tracking-wider text-neutral-400 block mb-2 flex items-center gap-1.5">
                <ArrowUpDown className="w-3.5 h-3.5" />
                <span>Sort Order</span>
              </label>
              <div className="grid grid-cols-3 gap-2 text-xs">
                {[
                  { id: 'recent', label: 'Recently Read' },
                  { id: 'title', label: 'Title (A-Z)' },
                  { id: 'progress', label: 'Reading Progress' },
                ].map((st) => (
                  <button
                    key={st.id}
                    onClick={() => setSortBy(st.id as any)}
                    className={`p-2 rounded-xl border text-center transition ${
                      sortBy === st.id
                        ? 'border-amber-400 text-amber-300 font-bold bg-amber-500/10'
                        : 'border-neutral-800 text-neutral-400 bg-neutral-950'
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Footer */}
            <div className="flex justify-between items-center pt-3 border-t border-neutral-800">
              <button
                onClick={() => {
                  setActiveFilter('all');
                  setSortBy('recent');
                }}
                className="text-xs text-neutral-400 hover:text-neutral-200"
              >
                Reset to Default
              </button>
              <button
                onClick={() => setShowFilterModal(false)}
                className="px-5 py-2 bg-amber-500 text-neutral-950 font-bold text-xs rounded-xl shadow-md shadow-amber-500/20"
              >
                Apply
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Share Toast Feedback */}
      {shareToast && (
        <div className="fixed bottom-20 sm:bottom-8 left-1/2 -translate-x-1/2 z-50 bg-neutral-900 border border-sky-500/50 text-neutral-100 text-xs px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2 animate-fade-in">
          <CheckCircle className="w-4 h-4 text-sky-400 flex-shrink-0" />
          <span>{shareToast}</span>
        </div>
      )}

      {/* Novel Details & Chapter Overview Modal */}
      {selectedNovelForDetails && (
        <NovelDetailsModal
          novel={selectedNovelForDetails}
          isOpen={!!selectedNovelForDetails}
          isInLibrary={true}
          onClose={() => setSelectedNovelForDetails(null)}
          onOpenReader={onOpenReader}
          onToggleLibrary={(nov, status) => {
            if (status) {
              setNovelStatus(nov, status);
            }
          }}
          onUpdateNovel={(updated) => {
            onUpdateNovel(updated);
            setSelectedNovelForDetails(updated);
          }}
        />
      )}
    </div>
  );
};
