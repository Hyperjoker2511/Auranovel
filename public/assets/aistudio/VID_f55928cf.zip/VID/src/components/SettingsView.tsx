import React, { useState, useEffect } from 'react';
import {
  Settings,
  HardDrive,
  Moon,
  Cloud,
  DownloadCloud,
  UploadCloud,
  Trash2,
  Check,
  Cpu,
  Clock,
  BookCheck,
  RefreshCw,
  Sparkles,
  Zap,
  Palette,
  Type,
  BookOpen,
  Volume2,
  Sliders,
  Eye,
  Smartphone,
  Layers,
  RotateCcw,
  Sun,
  Shield,
  Vibrate,
  SlidersHorizontal,
} from 'lucide-react';
import { ReaderSettings, ReadingStats, ReaderTheme, AccentColor, ReaderFont } from '../types/novel';
import {
  getStorageEstimate,
  clearAllCachedChapters,
  exportAllData,
  importAllData,
  getReadingStats,
  DEFAULT_SETTINGS,
} from '../utils/storage';
import { THEME_STYLES, ACCENT_HEX_MAP } from '../utils/themeConfig';
import { formatReadingTime } from '../utils/readerUtils';
import { playPageFlipSound, triggerHapticFeedback } from '../utils/audioEffects';

interface SettingsViewProps {
  settings: ReaderSettings;
  onUpdateSettings: (newSettings: ReaderSettings) => void;
  onRefreshLibrary: () => void;
  onOpenPwaModal?: () => void;
}

type SettingsTab = 'themes' | 'typography' | 'reading' | 'audio' | 'performance' | 'backup';

export const SettingsView: React.FC<SettingsViewProps> = ({
  settings,
  onUpdateSettings,
  onRefreshLibrary,
  onOpenPwaModal,
}) => {
  const [activeTab, setActiveTab] = useState<SettingsTab>('themes');
  const [storageInfo, setStorageInfo] = useState<{ totalBytes: number; chapterCount: number }>({
    totalBytes: 0,
    chapterCount: 0,
  });
  const [stats, setStats] = useState<ReadingStats>({
    totalSecondsRead: 0,
    chaptersCompleted: 0,
    booksFinished: 0,
    lastActiveDate: '',
    weeklyActivity: {},
    currentStreak: 1,
  });

  const [cacheClearSuccess, setCacheClearSuccess] = useState(false);
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [resetSuccess, setResetSuccess] = useState(false);
  const [syncCode] = useState('AETH-9824-SYNC');
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncSuccess, setSyncSuccess] = useState(false);

  // Available TTS voices
  const [systemVoices, setSystemVoices] = useState<SpeechSynthesisVoice[]>([]);

  useEffect(() => {
    refreshStorage();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      const updateVoices = () => {
        setSystemVoices(window.speechSynthesis.getVoices());
      };
      updateVoices();
      window.speechSynthesis.onvoiceschanged = updateVoices;
    }
  }, []);

  const refreshStorage = async () => {
    const info = await getStorageEstimate();
    setStorageInfo(info);
    setStats(getReadingStats());
  };

  const handleClearCache = async () => {
    if (confirm('Clear all downloaded and cached chapter contents? Your library list and reading progress will be kept intact.')) {
      await clearAllCachedChapters();
      await refreshStorage();
      setCacheClearSuccess(true);
      setTimeout(() => setCacheClearSuccess(false), 3000);
    }
  };

  const handleExportBackup = async () => {
    const jsonStr = await exportAllData();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `AetherNovel_Backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        const res = await importAllData(text);
        setImportStatus(`Successfully restored ${res.novelCount} items!`);
        onRefreshLibrary();
        await refreshStorage();
        setTimeout(() => setImportStatus(null), 4000);
      } catch (err: any) {
        alert(err.message || 'Failed to import backup');
      }
    };
    reader.readAsText(file);
  };

  const handleResetDefaults = () => {
    if (confirm('Reset all reading customization, visual themes, and layout to factory defaults?')) {
      onUpdateSettings(DEFAULT_SETTINGS);
      setResetSuccess(true);
      setTimeout(() => setResetSuccess(false), 3000);
    }
  };

  const handleCloudSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
      setSyncSuccess(true);
      setTimeout(() => setSyncSuccess(false), 3000);
    }, 1200);
  };

  const mbUsed = (storageInfo.totalBytes / (1024 * 1024)).toFixed(2);
  const activeThemeStyle = THEME_STYLES[settings.theme] || THEME_STYLES['liquid-glass'];
  const activeAccentHex = ACCENT_HEX_MAP[settings.accentColor || 'cyan'] || '#06b6d4';

  const themeList: { key: ReaderTheme; label: string; preview: string; textCol: string; isGlass?: boolean }[] = [
    { key: 'liquid-glass', label: 'Liquid Glass', preview: 'rgba(12, 16, 28, 0.85)', textCol: '#38bdf8', isGlass: true },
    { key: 'oled', label: 'OLED Black', preview: '#000000', textCol: '#ffffff' },
    { key: 'dark', label: 'Dark Charcoal', preview: '#14161b', textCol: '#e2e8f0' },
    { key: 'midnight', label: 'Midnight Blue', preview: '#0a0f1d', textCol: '#c9d3e6' },
    { key: 'nordic', label: 'Nordic Slate', preview: '#181e29', textCol: '#e2e8f0' },
    { key: 'cyberpunk', label: 'Cyberpunk Neon', preview: '#080811', textCol: '#38bdf8' },
    { key: 'crimson-void', label: 'Crimson Void', preview: '#0e0507', textCol: '#fecdd3' },
    { key: 'mocha', label: 'Mocha Coffee', preview: '#1c1715', textCol: '#ebdcd3' },
    { key: 'rose', label: 'Velvet Rose', preview: '#1c1216', textCol: '#ebd5dc' },
    { key: 'sepia', label: 'Warm Sepia', preview: '#f7eedc', textCol: '#3d2e1e' },
    { key: 'parchment', label: 'Old Parchment', preview: '#fdf6e2', textCol: '#2f281e' },
    { key: 'matcha', label: 'Matcha Cream', preview: '#f2f6ee', textCol: '#243322' },
    { key: 'light', label: 'Clean Paper', preview: '#fafafa', textCol: '#18181b' },
  ];

  const accentList: { key: AccentColor; label: string; color: string }[] = [
    { key: 'cyan', label: 'Cyan Glow', color: '#06b6d4' },
    { key: 'amber', label: 'Amber Gold', color: '#f59e0b' },
    { key: 'emerald', label: 'Emerald Jade', color: '#10b981' },
    { key: 'violet', label: 'Violet Astral', color: '#8b5cf6' },
    { key: 'rose', label: 'Rose Quartz', color: '#f43f5e' },
    { key: 'orange', label: 'Solar Orange', color: '#f97316' },
    { key: 'neon-pink', label: 'Neon Pink', color: '#ec4899' },
    { key: 'lime-gold', label: 'Lime Gold', color: '#84cc16' },
  ];

  const fontList: { key: ReaderFont; label: string; preview: string; desc: string }[] = [
    { key: 'Literata', label: 'Literata', preview: 'Serif · Designed for digital literature reading', desc: 'Serif' },
    { key: 'Lora', label: 'Lora', preview: 'Contemporary serif with calligraphic roots', desc: 'Editorial' },
    { key: 'Merriweather', label: 'Merriweather', preview: 'High-contrast pleasant reading on screens', desc: 'Classic' },
    { key: 'Inter', label: 'Inter', preview: 'Modern geometric sans-serif with high clarity', desc: 'Clean Sans' },
    { key: 'JetBrains Mono', label: 'JetBrains Mono', preview: 'Monospace with crisp character spacing', desc: 'Code/Mono' },
    { key: 'Cinzel', label: 'Cinzel', preview: 'Inspired by classical Roman inscriptions', desc: 'Fantasy/Epic' },
    { key: 'Atkinson', label: 'Atkinson', preview: 'Designed for optimal legibility & low strain', desc: 'Hyperlegible' },
    { key: 'system-ui', label: 'System UI', preview: 'Native platform typeface for fastest render', desc: 'Native' },
  ];

  return (
    <div className="flex-1 w-full max-w-5xl mx-auto p-4 sm:p-6 flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-100 flex items-center gap-2.5">
            <Settings className="w-7 h-7 text-cyan-400" />
            <span>Extensive Settings & Customization</span>
          </h1>
          <p className="text-xs sm:text-sm text-neutral-400 mt-1">
            Personalize Liquid Glass aesthetics, deep reading typography, acoustics, and high-performance modes.
          </p>
        </div>

        <button
          onClick={handleResetDefaults}
          className="px-3.5 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-400 hover:text-neutral-200 text-xs font-medium flex items-center gap-1.5 transition active:scale-95"
          title="Restore factory defaults"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Defaults</span>
        </button>
      </div>

      {resetSuccess && (
        <div className="p-3 rounded-xl bg-cyan-950/40 border border-cyan-800/50 text-xs text-cyan-300 flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>Settings successfully reset to factory defaults with Liquid Glass theme.</span>
        </div>
      )}

      {/* Tabs Navigation Bar */}
      <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-neutral-900/90 border border-neutral-800 overflow-x-auto no-scrollbar">
        {[
          { id: 'themes', label: 'Themes & Glass', icon: Palette },
          { id: 'typography', label: 'Typography', icon: Type },
          { id: 'reading', label: 'Reading Engine', icon: BookOpen },
          { id: 'audio', label: 'Audio & Haptics', icon: Volume2 },
          { id: 'performance', label: 'Performance', icon: Cpu },
          { id: 'backup', label: 'Data & Sync', icon: HardDrive },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as SettingsTab)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition flex-shrink-0 ${
                isActive
                  ? 'bg-neutral-800 text-cyan-400 shadow-sm border border-neutral-700/80'
                  : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ================= TAB 1: THEMES & LIQUID GLASS ================= */}
      {activeTab === 'themes' && (
        <div className="space-y-6">
          {/* Spotlight: Liquid Glass Showcase Card */}
          <div className="relative overflow-hidden p-6 rounded-3xl border border-cyan-500/30 bg-gradient-to-br from-cyan-950/40 via-neutral-900/80 to-purple-950/30 backdrop-blur-2xl shadow-2xl">
            {/* Ambient specular highlight orbs */}
            <div className="absolute -top-16 -right-16 w-48 h-48 bg-cyan-500/20 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -bottom-16 -left-16 w-48 h-48 bg-purple-500/20 rounded-full blur-3xl pointer-events-none" />

            <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-2xl bg-cyan-500/20 border border-cyan-400/40 text-cyan-300 shadow-lg shadow-cyan-500/10">
                  <Sparkles className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base sm:text-lg font-bold text-white tracking-wide">
                      Liquid Glass Experience
                    </h3>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-gradient-to-r from-cyan-500 to-blue-500 text-neutral-950">
                      Signature
                    </span>
                  </div>
                  <p className="text-xs text-neutral-300 mt-0.5">
                    Translucent frosted glassmorphism, glowing borders, and iridescent reflections.
                  </p>
                </div>
              </div>

              <button
                onClick={() =>
                  onUpdateSettings({
                    ...settings,
                    theme: 'liquid-glass',
                    appWideTheme: true,
                    ambientAura: true,
                  })
                }
                className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 active:scale-95 shadow-lg ${
                  settings.theme === 'liquid-glass'
                    ? 'bg-cyan-400 text-neutral-950 shadow-cyan-400/25'
                    : 'bg-white/10 hover:bg-white/20 text-white border border-white/20'
                }`}
              >
                {settings.theme === 'liquid-glass' ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Active Theme</span>
                  </>
                ) : (
                  <span>Apply Liquid Glass</span>
                )}
              </button>
            </div>

            {/* Liquid Glass Controls */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-neutral-200">App-Wide Shell Theme</span>
                  <input
                    type="checkbox"
                    checked={settings.appWideTheme ?? true}
                    onChange={(e) =>
                      onUpdateSettings({ ...settings, appWideTheme: e.target.checked })
                    }
                    className="w-4 h-4 accent-cyan-400 cursor-pointer rounded"
                  />
                </div>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  Applies the glassmorphic aesthetic across the navigation bars, cards, and modal dialogs.
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold text-neutral-200">Ambient Aura Orbs</span>
                  <input
                    type="checkbox"
                    checked={settings.ambientAura ?? true}
                    onChange={(e) =>
                      onUpdateSettings({ ...settings, ambientAura: e.target.checked })
                    }
                    className="w-4 h-4 accent-cyan-400 cursor-pointer rounded"
                  />
                </div>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  Generates smooth chromatic luminous radial light gradients behind reader panels.
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-semibold text-neutral-200">Glass Frosted Blur</span>
                  <span className="text-xs font-bold text-cyan-400 capitalize">
                    {settings.glassBlurIntensity || 'high'}
                  </span>
                </div>
                <div className="flex gap-1.5 mt-2">
                  {(['low', 'medium', 'high'] as const).map((lvl) => (
                    <button
                      key={lvl}
                      onClick={() =>
                        onUpdateSettings({ ...settings, glassBlurIntensity: lvl })
                      }
                      className={`flex-1 py-1 rounded-lg text-[10px] font-bold uppercase transition ${
                        (settings.glassBlurIntensity || 'high') === lvl
                          ? 'bg-cyan-400 text-neutral-950'
                          : 'bg-white/10 text-neutral-300 hover:bg-white/20'
                      }`}
                    >
                      {lvl}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Theme Palette Gallery */}
          <div className="p-5 sm:p-6 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Palette className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-sm text-neutral-100">Theme Palette Gallery</h3>
              </div>
              <span className="text-xs text-neutral-400">13 Handcrafted Themes</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {themeList.map((t) => {
                const isSelected = settings.theme === t.key;
                return (
                  <button
                    key={t.key}
                    onClick={() => {
                      onUpdateSettings({
                        ...settings,
                        theme: t.key,
                        oledPureBlack: t.key === 'oled',
                      });
                    }}
                    className={`p-3.5 rounded-2xl border text-left flex flex-col justify-between h-24 transition-all duration-200 relative overflow-hidden active:scale-95 ${
                      isSelected
                        ? 'ring-2 ring-cyan-400 shadow-lg'
                        : 'hover:border-neutral-700'
                    }`}
                    style={{
                      backgroundColor: t.preview,
                      borderColor: isSelected ? '#38bdf8' : '#262626',
                    }}
                  >
                    {t.isGlass && (
                      <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/10 to-transparent pointer-events-none" />
                    )}
                    <div className="flex items-center justify-between w-full">
                      <span
                        className="w-4 h-4 rounded-full border border-white/20 shadow-sm"
                        style={{ backgroundColor: t.preview }}
                      />
                      {isSelected && <Check className="w-4 h-4 text-cyan-400" />}
                    </div>

                    <div>
                      <div
                        className="text-xs font-bold truncate"
                        style={{ color: t.textCol }}
                      >
                        {t.label}
                      </div>
                      <div className="text-[10px] text-neutral-400 font-mono mt-0.5">
                        {t.isGlass ? 'Frosted Glass' : t.key}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Accent Color Selection */}
          <div className="p-5 sm:p-6 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Sun className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-sm text-neutral-100">Accent Glow & Highlights</h3>
              </div>
              <span className="text-xs font-mono font-bold" style={{ color: activeAccentHex }}>
                {settings.accentColor?.toUpperCase() || 'CYAN'}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {accentList.map((a) => {
                const isSelected = settings.accentColor === a.key;
                return (
                  <button
                    key={a.key}
                    onClick={() => onUpdateSettings({ ...settings, accentColor: a.key })}
                    className={`p-3 rounded-xl border flex items-center gap-3 transition active:scale-95 ${
                      isSelected
                        ? 'bg-neutral-800 border-neutral-700 shadow-md'
                        : 'bg-neutral-950/60 border-neutral-800 hover:border-neutral-700'
                    }`}
                  >
                    <span
                      className="w-5 h-5 rounded-full flex-shrink-0 flex items-center justify-center shadow-sm"
                      style={{ backgroundColor: a.color }}
                    >
                      {isSelected && <Check className="w-3 h-3 text-neutral-950 stroke-[3]" />}
                    </span>
                    <div className="text-left">
                      <div className="text-xs font-bold text-neutral-200">{a.label}</div>
                      <div className="text-[10px] font-mono text-neutral-500">{a.color}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 2: TYPOGRAPHY STUDIO ================= */}
      {activeTab === 'typography' && (
        <div className="space-y-6">
          {/* Live Interactive Reading Typography Preview */}
          <div
            className="p-6 rounded-3xl border transition-all duration-300 shadow-xl overflow-hidden relative"
            style={{
              backgroundColor: activeThemeStyle.bg,
              color: activeThemeStyle.text,
              borderColor: activeThemeStyle.border,
              fontFamily: settings.fontFamily,
            }}
          >
            {settings.theme === 'liquid-glass' && (
              <div className="absolute -top-12 -right-12 w-36 h-36 bg-cyan-500/15 rounded-full blur-2xl pointer-events-none" />
            )}

            <div className="flex items-center justify-between pb-3 border-b mb-4 opacity-70" style={{ borderColor: activeThemeStyle.border }}>
              <span className="text-xs uppercase tracking-wider font-semibold">
                Live Reader Preview · {settings.fontFamily} ({settings.fontSize}px)
              </span>
              <span className="text-xs font-mono font-bold" style={{ color: activeAccentHex }}>
                Line Height: {settings.lineHeight} · Spacing: {settings.paragraphSpacing}em
              </span>
            </div>

            <div
              style={{
                fontSize: `${settings.fontSize}px`,
                lineHeight: settings.lineHeight,
                letterSpacing: `${settings.letterSpacing}px`,
                textAlign: settings.textAlign,
                fontWeight: settings.fontWeight === 'bold' ? 700 : settings.fontWeight === 'medium' ? 500 : settings.fontWeight === 'light' ? 300 : 400,
              }}
              className="space-y-3"
            >
              <h3
                className="font-bold mb-2"
                style={{ fontSize: `${settings.fontSize * 1.3}px`, color: activeAccentHex }}
              >
                Chapter 1: The Crystal Horizon
              </h3>
              <p className={settings.indentParagraphs ? 'indent-6' : ''}>
                {settings.dropCaps && (
                  <span
                    className="float-left text-4xl leading-none font-bold mr-2 mt-1"
                    style={{ color: activeAccentHex }}
                  >
                    T
                  </span>
                )}
                {settings.dropCaps
                  ? 'he luminous spire rose through the twilight clouds, its crystalline facets reflecting the faint aurora overhead. Every breath tasted of crisp mountain snow and ancient resonance.'
                  : 'The luminous spire rose through the twilight clouds, its crystalline facets reflecting the faint aurora overhead. Every breath tasted of crisp mountain snow and ancient resonance.'}
              </p>
              <p className={settings.indentParagraphs ? 'indent-6' : ''}>
                He adjusted the straps of his worn traveling cloak, feeling the familiar hum of the artifact tucked securely against his chest. The path ahead was steep, but the stars promised guidance.
              </p>
            </div>
          </div>

          {/* Font Family Picker */}
          <div className="p-5 sm:p-6 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Type className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-sm text-neutral-100">Book Typeface Selection</h3>
              </div>
              <span className="text-xs text-neutral-400">8 Curated Typefaces</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
              {fontList.map((f) => {
                const isSelected = settings.fontFamily === f.key;
                return (
                  <button
                    key={f.key}
                    onClick={() => onUpdateSettings({ ...settings, fontFamily: f.key })}
                    className={`p-3 rounded-xl border text-left transition active:scale-95 ${
                      isSelected
                        ? 'bg-cyan-500/10 border-cyan-500 text-neutral-100 shadow-sm'
                        : 'bg-neutral-950/60 border-neutral-800 text-neutral-300 hover:border-neutral-700'
                    }`}
                  >
                    <div className="flex items-center justify-between font-bold text-xs mb-1">
                      <span style={{ fontFamily: f.key }}>{f.label}</span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                    </div>
                    <p className="text-[10px] text-neutral-500 truncate" style={{ fontFamily: f.key }}>
                      {f.preview}
                    </p>
                    <span className="inline-block mt-1 text-[9px] font-mono px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-400">
                      {f.desc}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Typography Sliders & Presets */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Font Size & Weight */}
            <div className="p-5 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-4">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-neutral-200">Font Size (px)</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() =>
                      onUpdateSettings({
                        ...settings,
                        fontSize: Math.max(13, settings.fontSize - 1),
                      })
                    }
                    className="w-6 h-6 rounded-lg bg-neutral-800 hover:bg-neutral-700 flex items-center justify-center font-bold text-neutral-200"
                  >
                    -
                  </button>
                  <span className="font-mono text-cyan-400 font-bold w-12 text-center">
                    {settings.fontSize}px
                  </span>
                  <button
                    onClick={() =>
                      onUpdateSettings({
                        ...settings,
                        fontSize: Math.min(38, settings.fontSize + 1),
                      })
                    }
                    className="w-6 h-6 rounded-lg bg-neutral-800 hover:bg-neutral-700 flex items-center justify-center font-bold text-neutral-200"
                  >
                    +
                  </button>
                </div>
              </div>

              <input
                type="range"
                min="13"
                max="38"
                step="1"
                value={settings.fontSize}
                onChange={(e) =>
                  onUpdateSettings({ ...settings, fontSize: parseInt(e.target.value, 10) })
                }
                className="w-full accent-cyan-400 cursor-pointer"
              />

              {/* Quick Size Presets */}
              <div className="flex gap-2 pt-1">
                {[
                  { label: 'Compact', size: 15 },
                  { label: 'Standard', size: 18 },
                  { label: 'Large', size: 22 },
                  { label: 'Huge', size: 28 },
                ].map((preset) => (
                  <button
                    key={preset.label}
                    onClick={() => onUpdateSettings({ ...settings, fontSize: preset.size })}
                    className={`flex-1 py-1.5 rounded-lg text-[11px] font-semibold border transition ${
                      settings.fontSize === preset.size
                        ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300'
                        : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    {preset.label} ({preset.size})
                  </button>
                ))}
              </div>

              {/* Font Weight */}
              <div className="pt-3 border-t border-neutral-800">
                <label className="text-xs font-semibold text-neutral-300 block mb-2">
                  Font Weight
                </label>
                <div className="grid grid-cols-4 gap-1.5">
                  {(['light', 'normal', 'medium', 'bold'] as const).map((w) => (
                    <button
                      key={w}
                      onClick={() => onUpdateSettings({ ...settings, fontWeight: w })}
                      className={`py-1.5 rounded-lg text-xs capitalize transition ${
                        settings.fontWeight === w
                          ? 'bg-cyan-400 text-neutral-950 font-bold'
                          : 'bg-neutral-800 text-neutral-400 hover:text-neutral-200'
                      }`}
                    >
                      {w}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Line Height & Letter Spacing */}
            <div className="p-5 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-4">
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-semibold text-neutral-200">Line Height (Leading)</span>
                  <span className="font-mono text-cyan-400 font-bold">{settings.lineHeight}x</span>
                </div>
                <input
                  type="range"
                  min="1.2"
                  max="2.6"
                  step="0.1"
                  value={settings.lineHeight}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, lineHeight: parseFloat(e.target.value) })
                  }
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-semibold text-neutral-200">Letter Spacing (Tracking)</span>
                  <span className="font-mono text-cyan-400 font-bold">{settings.letterSpacing}px</span>
                </div>
                <input
                  type="range"
                  min="-0.5"
                  max="3"
                  step="0.2"
                  value={settings.letterSpacing}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, letterSpacing: parseFloat(e.target.value) })
                  }
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-semibold text-neutral-200">Paragraph Spacing</span>
                  <span className="font-mono text-cyan-400 font-bold">{settings.paragraphSpacing}em</span>
                </div>
                <input
                  type="range"
                  min="0.6"
                  max="2.5"
                  step="0.1"
                  value={settings.paragraphSpacing}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, paragraphSpacing: parseFloat(e.target.value) })
                  }
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* Text Alignment */}
              <div className="pt-2 border-t border-neutral-800">
                <label className="text-xs font-semibold text-neutral-300 block mb-2">
                  Text Alignment
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['left', 'justify', 'center'] as const).map((align) => (
                    <button
                      key={align}
                      onClick={() => onUpdateSettings({ ...settings, textAlign: align })}
                      className={`py-1.5 rounded-lg text-xs capitalize transition ${
                        settings.textAlign === align
                          ? 'bg-cyan-400 text-neutral-950 font-bold'
                          : 'bg-neutral-800 text-neutral-400 hover:text-neutral-200'
                      }`}
                    >
                      {align}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Book Format Toggles (Indentation, Drop Caps, Max Width) */}
          <div className="p-5 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-4">
            <h4 className="font-bold text-xs text-neutral-200 uppercase tracking-wider">
              Editorial Formatting
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <label className="flex items-center justify-between p-3 rounded-xl bg-neutral-950 border border-neutral-800 cursor-pointer">
                <div>
                  <span className="text-xs font-semibold text-neutral-200 block">Paragraph Indents</span>
                  <span className="text-[10px] text-neutral-500">First-line book indent</span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.indentParagraphs}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, indentParagraphs: e.target.checked })
                  }
                  className="w-4 h-4 accent-cyan-400 cursor-pointer rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl bg-neutral-950 border border-neutral-800 cursor-pointer">
                <div>
                  <span className="text-xs font-semibold text-neutral-200 block">Classic Drop Caps</span>
                  <span className="text-[10px] text-neutral-500">Enlarged chapter start</span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.dropCaps}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, dropCaps: e.target.checked })
                  }
                  className="w-4 h-4 accent-cyan-400 cursor-pointer rounded"
                />
              </label>

              <div className="p-3 rounded-xl bg-neutral-950 border border-neutral-800">
                <div className="flex justify-between items-center text-xs mb-1">
                  <span className="font-semibold text-neutral-200">Max Column Width</span>
                  <span className="font-mono text-cyan-400 font-bold">
                    {settings.maxWidth === 0 ? 'Full' : `${settings.maxWidth}px`}
                  </span>
                </div>
                <input
                  type="range"
                  min="540"
                  max="1200"
                  step="20"
                  value={settings.maxWidth || 780}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, maxWidth: parseInt(e.target.value, 10) })
                  }
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 3: READING ENGINE & EYE COMFORT ================= */}
      {activeTab === 'reading' && (
        <div className="space-y-6">
          {/* Reading Mode & Page Transitions */}
          <div className="p-5 sm:p-6 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-sm text-neutral-100">Reading Engine & Spread Mode</h3>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {[
                {
                  id: 'scroll',
                  label: 'Continuous Scroll',
                  desc: 'Seamless vertical reading with infinite next-chapter loading',
                },
                {
                  id: 'paginated',
                  label: 'Paginated Flip',
                  desc: 'Classic e-reader page turns with tap zones and book curl',
                },
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() =>
                    onUpdateSettings({ ...settings, readingMode: m.id as any })
                  }
                  className={`p-3.5 rounded-xl border text-left transition ${
                    settings.readingMode === m.id
                      ? 'bg-cyan-500/10 border-cyan-400 text-neutral-100'
                      : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold text-xs mb-1">
                    <span>{m.label}</span>
                    {settings.readingMode === m.id && (
                      <Check className="w-4 h-4 text-cyan-400" />
                    )}
                  </div>
                  <p className="text-[11px] text-neutral-500 leading-relaxed">{m.desc}</p>
                </button>
              ))}

              {/* Tablet 2-Column Spread */}
              <button
                onClick={() =>
                  onUpdateSettings({ ...settings, twoColumnTablet: !settings.twoColumnTablet })
                }
                className={`p-3.5 rounded-xl border text-left transition ${
                  settings.twoColumnTablet
                    ? 'bg-cyan-500/10 border-cyan-400 text-neutral-100'
                    : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                }`}
              >
                <div className="flex items-center justify-between font-bold text-xs mb-1">
                  <span>Tablet 2-Page Spread</span>
                  {settings.twoColumnTablet && <Check className="w-4 h-4 text-cyan-400" />}
                </div>
                <p className="text-[11px] text-neutral-500 leading-relaxed">
                  Dual columns side-by-side on tablets, foldables, and landscape screens.
                </p>
              </button>
            </div>

            {/* Page Transitions */}
            <div className="pt-2 border-t border-neutral-800">
              <label className="text-xs font-semibold text-neutral-300 block mb-2">
                Page Flip Transition Effect
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {(
                  [
                    { id: 'slide', label: 'Smooth Slide' },
                    { id: 'curl', label: '3D Book Curl' },
                    { id: 'fade', label: 'Gentle Fade' },
                    { id: 'instant', label: 'Instant (Zero-Lag)' },
                  ] as const
                ).map((trans) => (
                  <button
                    key={trans.id}
                    onClick={() =>
                      onUpdateSettings({ ...settings, pageTransition: trans.id })
                    }
                    className={`py-2 rounded-xl text-xs font-semibold border transition ${
                      settings.pageTransition === trans.id
                        ? 'bg-cyan-400 text-neutral-950 border-cyan-400'
                        : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    {trans.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Eye Comfort, Candlelight Warm Tint & Reading Ruler */}
          <div className="p-5 sm:p-6 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Eye className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-sm text-neutral-100">
                  Eye Comfort, Warm Screen Tint & Focus Guide
                </h3>
              </div>
            </div>

            <div className="space-y-4">
              {/* Warm Screen Tint */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-semibold text-neutral-200">
                    Candlelight Warm Night Tint (Blue-Light Filter)
                  </span>
                  <span className="font-mono text-amber-400 font-bold">
                    {settings.warmScreenTint || 0}%
                  </span>
                </div>
                <p className="text-[11px] text-neutral-500 mb-2">
                  Adds a soothing amber warmth overlay over the entire reader to protect circadian rhythm in dark rooms.
                </p>
                <input
                  type="range"
                  min="0"
                  max="60"
                  step="5"
                  value={settings.warmScreenTint || 0}
                  onChange={(e) =>
                    onUpdateSettings({
                      ...settings,
                      warmScreenTint: parseInt(e.target.value, 10),
                    })
                  }
                  className="w-full accent-amber-500 cursor-pointer"
                />
              </div>

              {/* Reading Ruler Toggle */}
              <div className="flex items-center justify-between p-3.5 rounded-xl bg-neutral-950 border border-neutral-800">
                <div>
                  <span className="text-xs font-semibold text-neutral-200 block">
                    Reading Ruler / Focus Guide Line
                  </span>
                  <p className="text-[11px] text-neutral-500">
                    Displays a gentle translucent horizontal focus bar across the reader to assist line tracking.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.readingRuler ?? false}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, readingRuler: e.target.checked })
                  }
                  className="w-5 h-5 accent-cyan-400 cursor-pointer rounded"
                />
              </div>

              {/* Saccadic Bionic Reading */}
              <div className="p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-semibold text-neutral-200 block">
                      <b>Bio</b>nic Saccadic Speed Reading
                    </span>
                    <p className="text-[11px] text-neutral-500">
                      Bolds the initial characters of each word to guide the eye and increase reading speed.
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.bionicReading}
                    onChange={(e) =>
                      onUpdateSettings({ ...settings, bionicReading: e.target.checked })
                    }
                    className="w-5 h-5 accent-cyan-400 cursor-pointer rounded"
                  />
                </div>

                {settings.bionicReading && (
                  <div className="pt-2 border-t border-neutral-800">
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-neutral-400">Fixation Bold Intensity</span>
                      <span className="font-mono text-cyan-400 font-bold">
                        {settings.bionicStrength}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min="30"
                      max="70"
                      step="5"
                      value={settings.bionicStrength}
                      onChange={(e) =>
                        onUpdateSettings({
                          ...settings,
                          bionicStrength: parseInt(e.target.value, 10),
                        })
                      }
                      className="w-full accent-cyan-400 cursor-pointer"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Navigation Gestures & Tap Zones */}
          <div className="p-5 sm:p-6 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-4">
            <h4 className="font-bold text-xs text-neutral-200 uppercase tracking-wider">
              Navigation Gestures & Hardware Keys
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {[
                { id: 'standard', label: 'Standard Zones', desc: 'Left: Prev · Center: Menu · Right: Next' },
                { id: 'invert', label: 'Left-Handed Zones', desc: 'Right: Prev · Center: Menu · Left: Next' },
                { id: 'edges', label: 'Edge-Only Flip', desc: 'Outer 15% edges flip, center 70% shows menu' },
              ].map((zone) => (
                <button
                  key={zone.id}
                  onClick={() =>
                    onUpdateSettings({ ...settings, tapZoneMode: zone.id as any })
                  }
                  className={`p-3 rounded-xl border text-left transition ${
                    (settings.tapZoneMode || 'standard') === zone.id
                      ? 'bg-cyan-500/10 border-cyan-400 text-neutral-100'
                      : 'bg-neutral-950/60 border-neutral-800 text-neutral-400'
                  }`}
                >
                  <div className="text-xs font-bold mb-1">{zone.label}</div>
                  <div className="text-[10px] text-neutral-500">{zone.desc}</div>
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <label className="flex items-center justify-between p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 cursor-pointer">
                <div>
                  <span className="text-xs font-semibold text-neutral-200 block">
                    Volume Hardware Buttons Flip
                  </span>
                  <p className="text-[10px] text-neutral-500">
                    Use physical volume up/down keys to advance or rewind pages.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.volumeKeyNavigation ?? false}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, volumeKeyNavigation: e.target.checked })
                  }
                  className="w-4 h-4 accent-cyan-400 cursor-pointer rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3.5 rounded-xl bg-neutral-950 border border-neutral-800 cursor-pointer">
                <div>
                  <span className="text-xs font-semibold text-neutral-200 block">
                    Auto-Load Next Chapter
                  </span>
                  <p className="text-[10px] text-neutral-500">
                    Seamlessly jump to next chapter when reaching the bottom in scroll mode.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.autoLoadNextChapter ?? true}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, autoLoadNextChapter: e.target.checked })
                  }
                  className="w-4 h-4 accent-cyan-400 cursor-pointer rounded"
                />
              </label>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 4: AUDIO, SOUND EFFECTS & HAPTICS ================= */}
      {activeTab === 'audio' && (
        <div className="space-y-6">
          {/* Page Turn Acoustic Feedback & Haptics */}
          <div className="p-5 sm:p-6 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Volume2 className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-sm text-neutral-100">
                  Paper Rustle Flip Sound & Haptics
                </h3>
              </div>
            </div>

            <div className="space-y-3.5">
              <div className="flex items-center justify-between p-3.5 rounded-xl bg-neutral-950 border border-neutral-800">
                <div>
                  <span className="text-xs font-semibold text-neutral-200 block">
                    Page Turn Paper Rustle Sound Effect
                  </span>
                  <p className="text-[11px] text-neutral-500">
                    Procedural acoustic paper flip generated with Web Audio API (100% offline, zero network requests).
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => {
                      playPageFlipSound();
                    }}
                    className="px-3 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-cyan-300 transition active:scale-95"
                  >
                    Test Sound
                  </button>
                  <input
                    type="checkbox"
                    checked={settings.soundEffects ?? true}
                    onChange={(e) =>
                      onUpdateSettings({ ...settings, soundEffects: e.target.checked })
                    }
                    className="w-5 h-5 accent-cyan-400 cursor-pointer rounded"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between p-3.5 rounded-xl bg-neutral-950 border border-neutral-800">
                <div>
                  <span className="text-xs font-semibold text-neutral-200 block">
                    Haptic Vibration Feedback
                  </span>
                  <p className="text-[11px] text-neutral-500">
                    Provides a subtle tactile physical pulse on page turns on supported Android & mobile browsers.
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => {
                      triggerHapticFeedback([20]);
                    }}
                    className="px-3 py-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-cyan-300 transition active:scale-95"
                  >
                    Test Vibration
                  </button>
                  <input
                    type="checkbox"
                    checked={settings.hapticFeedback ?? true}
                    onChange={(e) =>
                      onUpdateSettings({ ...settings, hapticFeedback: e.target.checked })
                    }
                    className="w-5 h-5 accent-cyan-400 cursor-pointer rounded"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Text-to-Speech (TTS) Engine */}
          <div className="p-5 sm:p-6 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-400" />
                <h3 className="font-bold text-sm text-neutral-100">
                  Text-to-Speech (TTS) Voice Engine
                </h3>
              </div>
            </div>

            <div className="space-y-4">
              {/* System Voice Dropdown */}
              <div>
                <label className="text-xs font-semibold text-neutral-200 block mb-1">
                  Reader Voice Selection
                </label>
                <select
                  value={settings.ttsVoiceUri || ''}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, ttsVoiceUri: e.target.value })
                  }
                  className="w-full p-2.5 rounded-xl bg-neutral-950 border border-neutral-800 text-xs text-neutral-200 focus:outline-none focus:border-cyan-400"
                >
                  <option value="">Default System Voice</option>
                  {systemVoices.map((v) => (
                    <option key={v.voiceURI} value={v.voiceURI}>
                      {v.name} ({v.lang})
                    </option>
                  ))}
                </select>
              </div>

              {/* TTS Speed */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-semibold text-neutral-200">Narration Speed</span>
                  <span className="font-mono text-cyan-400 font-bold">{settings.ttsSpeed}x</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="2.5"
                  step="0.1"
                  value={settings.ttsSpeed}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, ttsSpeed: parseFloat(e.target.value) })
                  }
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>

              {/* TTS Pitch */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-semibold text-neutral-200">Narration Voice Pitch</span>
                  <span className="font-mono text-cyan-400 font-bold">{settings.ttsPitch}x</span>
                </div>
                <input
                  type="range"
                  min="0.8"
                  max="1.5"
                  step="0.1"
                  value={settings.ttsPitch}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, ttsPitch: parseFloat(e.target.value) })
                  }
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 5: PERFORMANCE & DEVICE ================= */}
      {activeTab === 'performance' && (
        <div className="space-y-6">
          {/* Older Devices & Battery Saver */}
          <div className="p-5 sm:p-6 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-4">
            <div className="flex items-center gap-2 pb-3 border-b border-neutral-800">
              <Cpu className="w-5 h-5 text-sky-400" />
              <div>
                <h3 className="font-bold text-sm text-neutral-100">
                  Older Devices & Low-Power Optimization (Android 7 - 9)
                </h3>
                <p className="text-xs text-neutral-400">
                  Reduces CPU overhead, disables heavy GPU backdrop filters, and conserves battery.
                </p>
              </div>
            </div>

            <div className="space-y-3.5 pt-1">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-neutral-200">
                    Low-Spec Device Mode
                  </span>
                  <p className="text-[11px] text-neutral-500">
                    Disables backdrop blur and expensive CSS animations for silky smooth 60fps performance on older chipsets.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.lowSpecMode}
                  onChange={(e) => onUpdateSettings({ ...settings, lowSpecMode: e.target.checked })}
                  className="w-5 h-5 rounded accent-sky-500 cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-semibold text-neutral-200">
                    OLED Pure Black Mode (#000000)
                  </span>
                  <p className="text-[11px] text-neutral-500">
                    Shuts off OLED pixels completely to extend battery life by up to 40% during night reading.
                  </p>
                </div>
                <input
                  type="checkbox"
                  checked={settings.oledPureBlack}
                  onChange={(e) =>
                    onUpdateSettings({
                      ...settings,
                      oledPureBlack: e.target.checked,
                      theme: e.target.checked ? 'oled' : settings.theme,
                    })
                  }
                  className="w-5 h-5 rounded accent-sky-500 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* AI Intelligence Provider */}
          <div className="p-5 sm:p-6 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="font-bold text-sm text-neutral-100">
                    AI Reading Intelligence Engine
                  </h3>
                  <p className="text-xs text-neutral-400">
                    Powers Chapter Recaps, Character Tracker, Lore Glossary, and Cliffhanger Predictions.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-4 pt-1">
              <div>
                <label className="text-xs font-semibold text-neutral-200 block mb-1">
                  Active AI Model
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {[
                    {
                      id: 'gemini-3.8-flash',
                      title: 'Gemini 3.8 Flash',
                      desc: 'Recommended: Deep narrative synthesis & high speed',
                    },
                    {
                      id: 'gemini-3.1-flash-lite',
                      title: 'Gemini Flash Lite',
                      desc: 'Ultra low latency & lightweight output',
                    },
                    {
                      id: 'local-offline',
                      title: 'Local Heuristic Engine',
                      desc: 'Offline rule-based excerpts with zero API calls',
                    },
                  ].map((model) => (
                    <button
                      key={model.id}
                      onClick={() =>
                        onUpdateSettings({
                          ...settings,
                          aiModelProvider: model.id as any,
                        })
                      }
                      className={`p-3 rounded-xl border text-left transition ${
                        settings.aiModelProvider === model.id
                          ? 'bg-amber-500/10 border-amber-500 text-neutral-100'
                          : 'bg-neutral-950/60 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                      }`}
                    >
                      <div className="flex items-center justify-between font-bold text-xs mb-1">
                        <span>{model.title}</span>
                        {settings.aiModelProvider === model.id && (
                          <Check className="w-3.5 h-3.5 text-amber-400" />
                        )}
                      </div>
                      <p className="text-[10px] leading-relaxed text-neutral-500">{model.desc}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Reading Pace Slider */}
              <div className="pt-2 border-t border-neutral-800/60">
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-semibold text-neutral-200">Personal Reading Pace</span>
                  <span className="font-mono text-cyan-400 font-bold">{settings.wpmReadingSpeed || 240} WPM</span>
                </div>
                <p className="text-[11px] text-neutral-500 mb-2">
                  Used by the Me/Library stats widget to calculate remaining reading time in books.
                </p>
                <input
                  type="range"
                  min="140"
                  max="450"
                  step="10"
                  value={settings.wpmReadingSpeed || 240}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, wpmReadingSpeed: parseInt(e.target.value, 10) })
                  }
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 6: DATA & CLOUD SYNC ================= */}
      {activeTab === 'backup' && (
        <div className="space-y-6">
          {/* Storage & Offline Cache Management */}
          <div className="p-5 sm:p-6 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <HardDrive className="w-5 h-5 text-cyan-400" />
                <div>
                  <h3 className="font-bold text-sm text-neutral-100">
                    Offline Chapter Cache
                  </h3>
                  <p className="text-xs text-neutral-400">
                    Stored locally in IndexedDB for 100% offline access with no network connection.
                  </p>
                </div>
              </div>
              <span className="text-xs font-mono px-2.5 py-1 rounded-lg bg-neutral-800 text-neutral-300">
                {mbUsed} MB in use
              </span>
            </div>

            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-1">
              <div>
                <p className="text-xs text-neutral-300">
                  Clear downloaded chapter texts to free up storage space.
                </p>
                <p className="text-[11px] text-neutral-500">
                  Your saved novel list, bookmarks, and reading progress will remain safe.
                </p>
              </div>
              <button
                onClick={handleClearCache}
                className="px-4 py-2 bg-rose-950/40 hover:bg-rose-900/40 border border-rose-800/60 text-rose-300 text-xs font-medium rounded-xl flex items-center gap-1.5 transition active:scale-95"
              >
                <Trash2 className="w-4 h-4" />
                <span>Clear Cached Chapters</span>
              </button>
            </div>

            {cacheClearSuccess && (
              <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-800/50 text-xs text-emerald-300 flex items-center gap-2">
                <Check className="w-4 h-4" />
                <span>Offline cache cleared successfully.</span>
              </div>
            )}
          </div>

          {/* Cloud Sync & Backups */}
          <div className="p-5 sm:p-6 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Cloud className="w-5 h-5 text-indigo-400" />
                <div>
                  <h3 className="font-bold text-sm text-neutral-100">
                    Cloud Sync & Portable Backups
                  </h3>
                  <p className="text-xs text-neutral-400">
                    Transfer your library, bookmarks, and settings across phone, tablet, and PC.
                  </p>
                </div>
              </div>
            </div>

            {/* Sync Key Panel */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-neutral-950 border border-neutral-800">
              <div>
                <span className="text-[11px] uppercase tracking-wider text-neutral-500 font-semibold block">
                  Cross-Device Sync Passkey
                </span>
                <span className="text-xs font-mono font-bold text-indigo-300">{syncCode}</span>
              </div>

              <button
                onClick={handleCloudSync}
                disabled={isSyncing}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl flex items-center justify-center gap-2 transition active:scale-95 shadow-md shadow-indigo-600/20"
              >
                {isSyncing ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : syncSuccess ? (
                  <Check className="w-3.5 h-3.5 text-emerald-300" />
                ) : (
                  <RefreshCw className="w-3.5 h-3.5" />
                )}
                <span>{isSyncing ? 'Syncing...' : syncSuccess ? 'Synced!' : 'Sync Now'}</span>
              </button>
            </div>

            {/* JSON Export and Import */}
            <div className="flex flex-col sm:flex-row gap-3 pt-1">
              <button
                onClick={handleExportBackup}
                className="flex-1 px-4 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-200 text-xs font-medium flex items-center justify-center gap-2 transition active:scale-95"
              >
                <DownloadCloud className="w-4 h-4 text-cyan-400" />
                <span>Export Full Backup (JSON)</span>
              </button>

              <label className="flex-1 px-4 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-200 text-xs font-medium flex items-center justify-center gap-2 transition active:scale-95 cursor-pointer">
                <UploadCloud className="w-4 h-4 text-amber-400" />
                <span>Restore Backup (JSON)</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImportBackup}
                  className="hidden"
                />
              </label>
            </div>

            {importStatus && (
              <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-800/50 text-xs text-emerald-300 flex items-center gap-2">
                <Check className="w-4 h-4" />
                <span>{importStatus}</span>
              </div>
            )}
          </div>

          {/* Android Native & App Store Publishing Studio Section */}
          <div className="p-5 sm:p-6 rounded-2xl bg-neutral-900/80 border border-neutral-800 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-amber-400" />
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-sm text-neutral-100">
                      Android Native & App Store Publishing Hub
                    </h3>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                      Target API 34
                    </span>
                  </div>
                  <p className="text-xs text-neutral-400">
                    Production native Android project, Google Play AAB bundle, F-Droid recipe, and WebAPK.
                  </p>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pt-1">
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs text-neutral-200 font-bold">
                    Native Project & Store Submission Studio
                  </span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-400 font-mono">
                    app.aethernovel
                  </span>
                </div>
                <p className="text-[11px] text-neutral-400 max-w-xl">
                  1-Click download complete Android Studio source (.zip), inspect Google Play Console signing commands, copy F-Droid YAML recipe, and test hardware vibration haptics.
                </p>
              </div>

              {onOpenPwaModal && (
                <button
                  onClick={onOpenPwaModal}
                  className="w-full sm:w-auto px-4 py-2.5 bg-gradient-to-r from-cyan-500 to-amber-500 hover:from-cyan-400 hover:to-amber-400 text-neutral-950 text-xs font-bold rounded-xl flex items-center justify-center gap-2 transition active:scale-95 shadow-md shadow-cyan-500/20 flex-shrink-0"
                >
                  <Smartphone className="w-4 h-4" />
                  <span>Open Publishing Studio</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
