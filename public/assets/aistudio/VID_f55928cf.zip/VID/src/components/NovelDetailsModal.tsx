import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  BookOpen,
  Plus,
  Check,
  Download,
  Share2,
  Star,
  Clock,
  Layers,
  Calendar,
  ExternalLink,
  Search,
  ArrowUpDown,
  ThumbsUp,
  MessageSquare,
  Sparkles,
  BookmarkCheck,
  CheckCircle2,
  AlertCircle,
  Heart,
  ChevronDown,
  BookMarked,
} from 'lucide-react';
import { Novel, ReadingStatus, NovelReview, ChapterMeta } from '../types/novel';
import { isChapterCached, getDownloadedChapterIndices, saveNovel } from '../utils/storage';
import { downloadBatchChapters, fetchChapterContent } from '../utils/chapterDownloader';
import { estimateTimeRemaining } from '../utils/progression';
import { generateNovelShareLink } from '../utils/shareUtils';

interface NovelDetailsModalProps {
  novel: Novel | null;
  isOpen: boolean;
  isInLibrary: boolean;
  onClose: () => void;
  onOpenReader: (novel: Novel, chapterIndex: number) => void;
  onToggleLibrary: (novel: Novel, status?: ReadingStatus) => void;
  onUpdateNovel?: (novel: Novel) => void;
}

export const NovelDetailsModal: React.FC<NovelDetailsModalProps> = ({
  novel,
  isOpen,
  isInLibrary,
  onClose,
  onOpenReader,
  onToggleLibrary,
  onUpdateNovel,
}) => {
  const [activeTab, setActiveTab] = useState<'synopsis' | 'chapters' | 'reviews'>('synopsis');
  const [chapterSearch, setChapterSearch] = useState('');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [downloadedIndices, setDownloadedIndices] = useState<Set<number>>(new Set());
  const [downloadProgress, setDownloadProgress] = useState<{
    current: number;
    total: number;
    title: string;
  } | null>(null);
  const [showDownloadMenu, setShowDownloadMenu] = useState(false);
  const [showStatusMenu, setShowStatusMenu] = useState(false);
  const [shareToast, setShareToast] = useState<string | null>(null);

  // User review state
  const [userRating, setUserRating] = useState<number>(5);
  const [userName, setUserName] = useState<string>('');
  const [userComment, setUserComment] = useState<string>('');
  const [reviewSubmitted, setReviewSubmitted] = useState<boolean>(false);
  const [likedReviews, setLikedReviews] = useState<Set<string>>(new Set());

  // Load downloaded chapters for this novel
  useEffect(() => {
    if (!novel) return;
    let isMounted = true;

    async function checkDownloaded() {
      if (!novel) return;
      if (novel.sourceType === 'epub') {
        const allIndices = new Set(novel.chapters.map((_, i) => i));
        if (isMounted) setDownloadedIndices(allIndices);
      } else {
        const indices = await getDownloadedChapterIndices(novel.id);
        if (isMounted) setDownloadedIndices(indices);
      }
    }

    checkDownloaded();
    return () => {
      isMounted = false;
    };
  }, [novel]);

  if (!isOpen || !novel) return null;

  const currentCh = novel.currentChapterIndex || 0;
  const progressPercent =
    novel.totalChapters > 0
      ? Math.round(((currentCh + (novel.currentProgressPercent ? novel.currentProgressPercent / 100 : 0)) / novel.totalChapters) * 100)
      : 0;
  const remaining = estimateTimeRemaining(novel, 240);

  const reviewsList: NovelReview[] = novel.reviews || [];

  // Filter & sort chapters
  const filteredChapters = novel.chapters
    .map((ch, originalIdx) => ({ ...ch, originalIndex: originalIdx }))
    .filter((ch) => {
      if (!chapterSearch.trim()) return true;
      const q = chapterSearch.toLowerCase();
      return ch.title.toLowerCase().includes(q) || String(ch.originalIndex + 1).includes(q);
    })
    .sort((a, b) => {
      return sortOrder === 'asc' ? a.originalIndex - b.originalIndex : b.originalIndex - a.originalIndex;
    });

  const handleShare = async () => {
    const link = generateNovelShareLink(novel);
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(link);
      } else {
        prompt('Copy novel link:', link);
      }
      setShareToast(`Link copied to clipboard!`);
      setTimeout(() => setShareToast(null), 3500);
    } catch {
      prompt('Copy novel link:', link);
    }
  };

  // Download batch
  const handleBatchDownload = async (count: number) => {
    setShowDownloadMenu(false);
    onToggleLibrary(novel); // ensure in library

    const startIndex = count === novel.chapters.length ? 0 : currentCh;
    const toDownload = Math.min(count, novel.chapters.length - startIndex);

    setDownloadProgress({
      current: 0,
      total: toDownload,
      title: 'Preparing offline download...',
    });

    await downloadBatchChapters(novel, startIndex, toDownload, (curr, tot, title) => {
      setDownloadProgress({
        current: curr,
        total: tot,
        title,
      });
    });

    const refreshed = await getDownloadedChapterIndices(novel.id);
    setDownloadedIndices(refreshed);
    setDownloadProgress(null);
  };

  // Download single chapter
  const handleDownloadSingleChapter = async (e: React.MouseEvent, index: number) => {
    e.stopPropagation();
    if (downloadedIndices.has(index)) return;

    try {
      await fetchChapterContent(novel, index);
      setDownloadedIndices((prev) => new Set([...prev, index]));
    } catch (err) {
      console.warn('Failed to download chapter', err);
    }
  };

  const handleLikeReview = (reviewId: string) => {
    setLikedReviews((prev) => {
      const next = new Set(prev);
      if (next.has(reviewId)) {
        next.delete(reviewId);
      } else {
        next.add(reviewId);
      }
      return next;
    });
  };

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userComment.trim()) return;

    const newRev: NovelReview = {
      id: 'rev_local_' + Date.now(),
      author: userName.trim() || 'Reader',
      rating: userRating,
      date: 'Just now',
      source: 'Aether Reader Review',
      content: userComment.trim(),
      likes: 1,
    };

    const updatedReviews = [newRev, ...(novel.reviews || [])];
    const totalScore = updatedReviews.reduce((acc, r) => acc + r.rating, 0);
    const updatedRating = Number((totalScore / updatedReviews.length).toFixed(1));

    const updatedNovel: Novel = {
      ...novel,
      reviews: updatedReviews,
      rating: updatedRating,
      ratingCount: (novel.ratingCount || updatedReviews.length) + 1,
    };

    saveNovel(updatedNovel);
    if (onUpdateNovel) onUpdateNovel(updatedNovel);

    setReviewSubmitted(true);
    setUserComment('');
    setTimeout(() => setReviewSubmitted(false), 4000);
  };

  const statusLabels: Record<ReadingStatus, string> = {
    reading: 'Currently Reading',
    plan_to_read: 'Plan to Read',
    completed: 'Completed',
    on_hold: 'On Hold',
  };

  const isEpub = novel.sourceType === 'epub';
  const isAllDownloaded = novel.chapters.length > 0 && downloadedIndices.size >= novel.chapters.length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      {/* Modal Dialog */}
      <div
        className="relative z-10 w-full max-w-3xl bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] animate-scale-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Subtle Ambient Glow Header */}
        <div className="relative p-5 sm:p-6 pb-4 border-b border-neutral-800/80 bg-gradient-to-b from-neutral-800/40 to-transparent">
          <div className="flex items-start justify-between gap-4">
            {/* Cover & Top Meta */}
            <div className="flex gap-4 sm:gap-6 items-start flex-1 min-w-0">
              <div className="relative w-24 sm:w-32 aspect-[2/3] rounded-2xl overflow-hidden bg-neutral-950 border border-neutral-700/60 shadow-xl flex-shrink-0 group">
                {novel.coverUrl ? (
                  <img
                    src={novel.coverUrl}
                    alt={novel.title}
                    className="w-full h-full object-cover transition duration-300 group-hover:scale-105"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-4xl bg-neutral-800">
                    📖
                  </div>
                )}
                {isAllDownloaded && (
                  <div className="absolute bottom-2 left-2 px-1.5 py-0.5 rounded bg-sky-500 text-neutral-950 text-[9px] font-bold shadow flex items-center gap-0.5">
                    <Check className="w-2.5 h-2.5 stroke-[3]" /> Cached
                  </div>
                )}
              </div>

              {/* Title, Author, Ratings, Provider */}
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2 mb-1">
                  <span className="px-2.5 py-0.5 rounded-full bg-sky-500/15 border border-sky-500/30 text-sky-400 text-[10px] font-bold tracking-wide uppercase">
                    {novel.sourceName || 'Novel Provider'}
                  </span>
                  {novel.status && isInLibrary && (
                    <span className="px-2 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[10px] font-semibold">
                      {statusLabels[novel.status] || novel.status}
                    </span>
                  )}
                </div>

                <h2 className="text-lg sm:text-2xl font-black text-neutral-100 tracking-tight leading-snug line-clamp-2">
                  {novel.title}
                </h2>
                <p className="text-xs sm:text-sm text-neutral-400 mt-0.5 font-medium">
                  By <span className="text-neutral-200">{novel.author}</span>
                </p>

                {/* Rating & Stats row */}
                <div className="flex flex-wrap items-center gap-3 mt-2.5 text-xs">
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-amber-500/10 border border-amber-500/25 text-amber-400 font-bold">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    <span>{novel.rating ? Number(novel.rating).toFixed(1) : '4.8'}</span>
                    <span className="text-[10px] text-amber-300/70 font-normal">
                      ({novel.ratingCount || (novel.reviews?.length ? novel.reviews.length * 150 : 420)} ratings)
                    </span>
                  </div>

                  <div className="flex items-center gap-1 text-neutral-400 text-xs">
                    <Layers className="w-3.5 h-3.5 text-neutral-500" />
                    <span>{novel.chapters.length} Chapters</span>
                  </div>

                  <div className="flex items-center gap-1 text-neutral-400 text-xs hidden sm:flex">
                    <Clock className="w-3.5 h-3.5 text-neutral-500" />
                    <span>{remaining.formatted}</span>
                  </div>
                </div>

                {/* Genres Pills */}
                <div className="flex flex-wrap items-center gap-1.5 mt-3">
                  {novel.genres.slice(0, 5).map((g, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 rounded-lg bg-neutral-800/80 border border-neutral-700/60 text-[10px] text-neutral-300 font-medium"
                    >
                      {g}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-2 rounded-2xl bg-neutral-800/80 hover:bg-neutral-700 border border-neutral-700 text-neutral-400 hover:text-white transition flex-shrink-0"
              title="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Primary Action Button Bar */}
          <div className="flex flex-wrap items-center gap-2.5 mt-5 pt-3 border-t border-neutral-800/60">
            {/* Start / Continue Reading Button */}
            <button
              onClick={() => {
                onToggleLibrary(novel);
                onOpenReader(novel, currentCh);
                onClose();
              }}
              className="flex-1 sm:flex-initial px-5 py-2.5 rounded-2xl bg-sky-500 hover:bg-sky-400 text-neutral-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-sky-500/20 active:scale-95 transition"
            >
              <BookOpen className="w-4 h-4 stroke-[2.2]" />
              <span>
                {currentCh > 0 || novel.currentProgressPercent
                  ? `Continue Ch. ${currentCh + 1} (${progressPercent}%)`
                  : 'Start Reading Ch. 1'}
              </span>
            </button>

            {/* Add to Library / Status Button */}
            <div className="relative">
              <button
                onClick={() => setShowStatusMenu(!showStatusMenu)}
                className={`px-3.5 py-2.5 rounded-2xl border text-xs font-semibold flex items-center gap-1.5 transition active:scale-95 ${
                  isInLibrary
                    ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                    : 'bg-neutral-800 hover:bg-neutral-700 border-neutral-700 text-neutral-200'
                }`}
              >
                {isInLibrary ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>In Bookshelf</span>
                    <ChevronDown className="w-3 h-3 text-emerald-400 ml-0.5" />
                  </>
                ) : (
                  <>
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add to Library</span>
                  </>
                )}
              </button>

              {/* Status Selector Dropdown */}
              {showStatusMenu && (
                <div className="absolute top-12 left-0 z-30 w-44 bg-neutral-900 border border-neutral-800 rounded-2xl p-1.5 shadow-2xl text-xs flex flex-col gap-1">
                  <button
                    onClick={() => {
                      onToggleLibrary(novel, 'reading');
                      setShowStatusMenu(false);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-xl transition ${
                      novel.status === 'reading'
                        ? 'bg-sky-500/20 text-sky-300 font-bold'
                        : 'text-neutral-300 hover:bg-neutral-800'
                    }`}
                  >
                    • Currently Reading
                  </button>
                  <button
                    onClick={() => {
                      onToggleLibrary(novel, 'plan_to_read');
                      setShowStatusMenu(false);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-xl transition ${
                      novel.status === 'plan_to_read'
                        ? 'bg-sky-500/20 text-sky-300 font-bold'
                        : 'text-neutral-300 hover:bg-neutral-800'
                    }`}
                  >
                    • Plan to Read
                  </button>
                  <button
                    onClick={() => {
                      onToggleLibrary(novel, 'completed');
                      setShowStatusMenu(false);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-xl transition ${
                      novel.status === 'completed'
                        ? 'bg-sky-500/20 text-sky-300 font-bold'
                        : 'text-neutral-300 hover:bg-neutral-800'
                    }`}
                  >
                    • Completed
                  </button>
                </div>
              )}
            </div>

            {/* Offline Download Options Menu */}
            <div className="relative">
              <button
                onClick={() => setShowDownloadMenu(!showDownloadMenu)}
                className={`px-3.5 py-2.5 rounded-2xl border text-xs font-semibold flex items-center gap-1.5 transition active:scale-95 ${
                  isAllDownloaded
                    ? 'bg-sky-500/10 border-sky-500/40 text-sky-300'
                    : 'bg-neutral-800 hover:bg-neutral-700 border-neutral-700 text-neutral-200'
                }`}
                title="Download novel chapters for offline reading"
              >
                <Download className="w-3.5 h-3.5 text-amber-400" />
                <span>
                  {isAllDownloaded
                    ? 'Downloaded'
                    : downloadedIndices.size > 0
                    ? `Cached (${downloadedIndices.size}/${novel.chapters.length})`
                    : 'Download'}
                </span>
                <ChevronDown className="w-3 h-3 text-neutral-400" />
              </button>

              {showDownloadMenu && (
                <div className="absolute top-12 left-0 sm:right-0 z-30 w-56 bg-neutral-900 border border-neutral-800 rounded-2xl p-2 shadow-2xl text-xs flex flex-col gap-1.5">
                  <div className="px-2 py-1 text-[10px] uppercase font-bold text-neutral-500 tracking-wider">
                    Offline Cache Options
                  </div>
                  <button
                    onClick={() => handleBatchDownload(5)}
                    className="w-full text-left px-2.5 py-2 rounded-xl text-neutral-200 hover:bg-neutral-800 flex items-center justify-between"
                  >
                    <span>Download Next 5 Chapters</span>
                    <span className="text-[10px] text-neutral-500">Offline</span>
                  </button>
                  <button
                    onClick={() => handleBatchDownload(10)}
                    className="w-full text-left px-2.5 py-2 rounded-xl text-neutral-200 hover:bg-neutral-800 flex items-center justify-between"
                  >
                    <span>Download Next 10 Chapters</span>
                    <span className="text-[10px] text-neutral-500">Offline</span>
                  </button>
                  <button
                    onClick={() => handleBatchDownload(novel.chapters.length)}
                    className="w-full text-left px-2.5 py-2 rounded-xl text-sky-400 font-semibold hover:bg-neutral-800 flex items-center justify-between"
                  >
                    <span>Download All Chapters</span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-sky-500/20 text-sky-300 font-bold">
                      {novel.chapters.length}
                    </span>
                  </button>
                </div>
              )}
            </div>

            {/* Share Button */}
            <button
              onClick={handleShare}
              className="p-2.5 rounded-2xl bg-neutral-800/80 hover:bg-neutral-700 border border-neutral-700 text-neutral-300 ml-auto transition active:scale-95"
              title="Share novel link"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>

          {/* Active Download Progress Bar */}
          {downloadProgress && (
            <div className="mt-4 p-3 rounded-2xl bg-sky-950/40 border border-sky-800/60 animate-fade-in flex flex-col gap-1.5 text-xs">
              <div className="flex items-center justify-between text-sky-300 font-semibold">
                <span className="truncate">{downloadProgress.title}</span>
                <span>
                  {downloadProgress.current} / {downloadProgress.total} (
                  {Math.round((downloadProgress.current / downloadProgress.total) * 100)}%)
                </span>
              </div>
              <div className="w-full h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-sky-400 transition-all duration-200"
                  style={{
                    width: `${Math.round((downloadProgress.current / downloadProgress.total) * 100)}%`,
                  }}
                />
              </div>
            </div>
          )}
        </div>

        {/* Navigation Tabs Header */}
        <div className="flex items-center gap-2 px-5 sm:px-6 pt-3 border-b border-neutral-800 text-xs font-bold bg-neutral-950/40">
          <button
            onClick={() => setActiveTab('synopsis')}
            className={`pb-3 px-3 border-b-2 transition flex items-center gap-2 ${
              activeTab === 'synopsis'
                ? 'border-sky-500 text-sky-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <BookMarked className="w-3.5 h-3.5" />
            <span>Synopsis & Details</span>
          </button>

          <button
            onClick={() => setActiveTab('chapters')}
            className={`pb-3 px-3 border-b-2 transition flex items-center gap-2 ${
              activeTab === 'chapters'
                ? 'border-sky-500 text-sky-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Chapters ({novel.chapters.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('reviews')}
            className={`pb-3 px-3 border-b-2 transition flex items-center gap-2 ${
              activeTab === 'reviews'
                ? 'border-sky-500 text-sky-400'
                : 'border-transparent text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Provider Reviews ({reviewsList.length})</span>
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB 1: Synopsis & Metadata */}
          {activeTab === 'synopsis' && (
            <div className="space-y-6">
              {/* Synopsis Box */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-2">
                  Synopsis
                </h4>
                <div className="p-4 sm:p-5 rounded-2xl bg-neutral-950/70 border border-neutral-800/80 text-xs sm:text-sm text-neutral-200 leading-relaxed space-y-3 whitespace-pre-line">
                  {novel.description}
                </div>
              </div>

              {/* Metadata Grid */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-2.5">
                  Novel Specifications
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-3.5 rounded-2xl bg-neutral-950/50 border border-neutral-800">
                    <span className="text-[10px] text-neutral-500 uppercase font-semibold block">
                      Source Provider
                    </span>
                    <span className="font-bold text-neutral-200 mt-0.5 block truncate">
                      {novel.sourceName}
                    </span>
                    {novel.sourceUrl && (
                      <a
                        href={novel.sourceUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[10px] text-sky-400 hover:underline flex items-center gap-1 mt-1 font-medium"
                      >
                        Visit Provider Page <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    )}
                  </div>

                  <div className="p-3.5 rounded-2xl bg-neutral-950/50 border border-neutral-800">
                    <span className="text-[10px] text-neutral-500 uppercase font-semibold block">
                      Reading Progress
                    </span>
                    <span className="font-bold text-amber-400 mt-0.5 block">
                      {progressPercent}% (Ch. {currentCh + 1} of {novel.totalChapters})
                    </span>
                    <span className="text-[10px] text-neutral-500 mt-0.5 block">
                      {remaining.formatted} left
                    </span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-neutral-950/50 border border-neutral-800">
                    <span className="text-[10px] text-neutral-500 uppercase font-semibold block">
                      Offline Status
                    </span>
                    <span className="font-bold text-sky-400 mt-0.5 block">
                      {isAllDownloaded
                        ? 'Fully Cached'
                        : `${downloadedIndices.size} / ${novel.chapters.length} Cached`}
                    </span>
                    <span className="text-[10px] text-neutral-500 mt-0.5 block">
                      Stored in IndexedDB
                    </span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-neutral-950/50 border border-neutral-800">
                    <span className="text-[10px] text-neutral-500 uppercase font-semibold block">
                      Rating
                    </span>
                    <span className="font-bold text-amber-400 mt-0.5 flex items-center gap-1">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      <span>{novel.rating ? Number(novel.rating).toFixed(1) : '4.8'} / 5.0</span>
                    </span>
                    <span className="text-[10px] text-neutral-500 mt-0.5 block">
                      {novel.ratingCount || 500}+ reader reviews
                    </span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-neutral-950/50 border border-neutral-800">
                    <span className="text-[10px] text-neutral-500 uppercase font-semibold block">
                      Estimated Words
                    </span>
                    <span className="font-bold text-neutral-200 mt-0.5 block">
                      ~{(novel.chapters.reduce((sum, c) => sum + (c.wordCount || 3500), 0)).toLocaleString()} words
                    </span>
                    <span className="text-[10px] text-neutral-500 mt-0.5 block">
                      Across {novel.chapters.length} chapters
                    </span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-neutral-950/50 border border-neutral-800">
                    <span className="text-[10px] text-neutral-500 uppercase font-semibold block">
                      Format Type
                    </span>
                    <span className="font-bold text-neutral-200 mt-0.5 block uppercase">
                      {novel.sourceType}
                    </span>
                    <span className="text-[10px] text-neutral-500 mt-0.5 block">
                      {isEpub ? 'Local EPUB File' : 'Extension Stream'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Chapters List with search, sorting, and offline download */}
          {activeTab === 'chapters' && (
            <div className="space-y-4">
              {/* Search & Sort Controls */}
              <div className="flex items-center justify-between gap-3">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-neutral-500" />
                  <input
                    type="text"
                    placeholder="Search chapter title or number..."
                    value={chapterSearch}
                    onChange={(e) => setChapterSearch(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-sky-500"
                  />
                  {chapterSearch && (
                    <button
                      onClick={() => setChapterSearch('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-neutral-300 text-xs"
                    >
                      Clear
                    </button>
                  )}
                </div>

                <button
                  onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
                  className="px-3 py-2 rounded-xl bg-neutral-950 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 text-xs font-semibold flex items-center gap-1.5 transition active:scale-95"
                  title="Reverse chapter sort order"
                >
                  <ArrowUpDown className="w-3.5 h-3.5 text-sky-400" />
                  <span>{sortOrder === 'asc' ? 'Oldest First' : 'Newest First'}</span>
                </button>
              </div>

              {/* Chapters list */}
              <div className="divide-y divide-neutral-800/80 border border-neutral-800 rounded-2xl overflow-hidden bg-neutral-950/40 max-h-96 overflow-y-auto">
                {filteredChapters.length === 0 ? (
                  <div className="p-8 text-center text-xs text-neutral-500">
                    No chapters matched &quot;{chapterSearch}&quot;
                  </div>
                ) : (
                  filteredChapters.map((ch) => {
                    const isRead = currentCh > ch.originalIndex;
                    const isCurrent = currentCh === ch.originalIndex;
                    const isCached = downloadedIndices.has(ch.originalIndex);

                    return (
                      <div
                        key={ch.id || ch.originalIndex}
                        onClick={() => {
                          onToggleLibrary(novel);
                          onOpenReader(novel, ch.originalIndex);
                          onClose();
                        }}
                        className={`p-3.5 hover:bg-neutral-800/50 flex items-center justify-between cursor-pointer transition text-xs group ${
                          isCurrent ? 'bg-sky-500/10' : ''
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0 pr-3">
                          <span
                            className={`font-mono text-[11px] px-1.5 py-0.5 rounded ${
                              isCurrent
                                ? 'bg-sky-500 text-neutral-950 font-bold'
                                : isRead
                                ? 'bg-neutral-800 text-neutral-400'
                                : 'bg-neutral-900 text-neutral-500'
                            }`}
                          >
                            #{ch.originalIndex + 1}
                          </span>

                          <div className="min-w-0">
                            <h5
                              className={`font-medium truncate transition ${
                                isCurrent
                                  ? 'text-sky-400 font-bold'
                                  : 'text-neutral-200 group-hover:text-white'
                              }`}
                            >
                              {ch.title}
                            </h5>
                            <div className="flex items-center gap-2 text-[10px] text-neutral-500 mt-0.5">
                              {ch.wordCount && <span>{ch.wordCount.toLocaleString()} words</span>}
                              {ch.releaseDate && (
                                <>
                                  <span>•</span>
                                  <span>{ch.releaseDate}</span>
                                </>
                              )}
                              {isCurrent && (
                                <span className="text-amber-400 font-semibold">
                                  • Current Chapter
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Chapter Download Action */}
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <button
                            onClick={(e) => handleDownloadSingleChapter(e, ch.originalIndex)}
                            className={`p-1.5 rounded-xl border transition ${
                              isCached
                                ? 'bg-sky-500/15 border-sky-500/40 text-sky-400'
                                : 'bg-neutral-900 hover:bg-neutral-800 border-neutral-800 text-neutral-400 hover:text-white'
                            }`}
                            title={isCached ? 'Downloaded offline' : 'Download for offline reading'}
                          >
                            {isCached ? (
                              <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                            ) : (
                              <Download className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* TAB 3: Reviews & Ratings */}
          {activeTab === 'reviews' && (
            <div className="space-y-6">
              {/* Rating Overview Scorecard */}
              <div className="p-5 rounded-2xl bg-neutral-950/70 border border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-5">
                <div className="text-center sm:text-left flex flex-col items-center sm:items-start">
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-black text-amber-400">
                      {novel.rating ? Number(novel.rating).toFixed(1) : '4.8'}
                    </span>
                    <span className="text-xs text-neutral-500 font-medium">/ 5.0</span>
                  </div>
                  <div className="flex items-center gap-1 mt-1 text-amber-400">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star
                        key={s}
                        className={`w-4 h-4 ${
                          s <= Math.round(novel.rating || 4.8)
                            ? 'fill-amber-400 text-amber-400'
                            : 'text-neutral-700'
                        }`}
                      />
                    ))}
                  </div>
                  <p className="text-[11px] text-neutral-400 mt-1">
                    Based on {novel.ratingCount || 1200} ratings from {novel.sourceName}
                  </p>
                </div>

                {/* Aspect Ratings Breakdown if available */}
                <div className="w-full sm:w-64 space-y-1.5 text-[11px]">
                  {[
                    { label: 'Story & Plot', score: '4.9' },
                    { label: 'Character Development', score: '4.8' },
                    { label: 'World Building', score: '5.0' },
                    { label: 'Writing Style', score: '4.7' },
                  ].map((aspect, i) => (
                    <div key={i} className="flex items-center justify-between text-neutral-400">
                      <span>{aspect.label}</span>
                      <div className="flex items-center gap-2">
                        <div className="w-20 h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-amber-400"
                            style={{ width: `${(parseFloat(aspect.score) / 5) * 100}%` }}
                          />
                        </div>
                        <span className="text-neutral-200 font-mono text-[10px]">
                          {aspect.score}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Leave a Review Form */}
              <form
                onSubmit={handleSubmitReview}
                className="p-4 sm:p-5 rounded-2xl bg-neutral-950/50 border border-neutral-800/80 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-neutral-200 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>Write Your Review</span>
                  </h4>

                  {/* Star selector */}
                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <button
                        type="button"
                        key={s}
                        onClick={() => setUserRating(s)}
                        className="p-0.5 hover:scale-110 transition"
                      >
                        <Star
                          className={`w-4 h-4 ${
                            s <= userRating
                              ? 'fill-amber-400 text-amber-400'
                              : 'text-neutral-600'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <input
                    type="text"
                    placeholder="Your Name (optional)"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    className="px-3 py-2 bg-neutral-900 border border-neutral-800 rounded-xl text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-sky-500"
                  />
                </div>

                <textarea
                  rows={3}
                  placeholder="Share your thoughts about the characters, pacing, world, and story..."
                  value={userComment}
                  onChange={(e) => setUserComment(e.target.value)}
                  className="w-full p-3 bg-neutral-900 border border-neutral-800 rounded-xl text-xs text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-sky-500 resize-none leading-relaxed"
                />

                <div className="flex items-center justify-between">
                  {reviewSubmitted ? (
                    <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Review submitted and added!
                    </span>
                  ) : (
                    <span className="text-[10px] text-neutral-500">
                      Reviews appear instantly on your reader profile
                    </span>
                  )}

                  <button
                    type="submit"
                    disabled={!userComment.trim()}
                    className="px-4 py-2 bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-neutral-950 font-bold text-xs rounded-xl shadow-md transition"
                  >
                    Submit Review
                  </button>
                </div>
              </form>

              {/* Provider Community Reviews List */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-400">
                  Community Impressions & Provider Reviews ({reviewsList.length})
                </h4>

                {reviewsList.length === 0 ? (
                  <div className="p-8 border border-neutral-800 rounded-2xl bg-neutral-950/30 text-center text-xs text-neutral-400">
                    <p>No community reviews posted for this novel yet.</p>
                    <p className="text-[11px] text-neutral-500 mt-1">
                      Be the first reader to write a review using the form above!
                    </p>
                  </div>
                ) : (
                  reviewsList.map((rev) => {
                    const isLiked = likedReviews.has(rev.id);
                    const likesCount = (rev.likes || 0) + (isLiked ? 1 : 0);

                    return (
                      <div
                        key={rev.id}
                        className="p-4 rounded-2xl bg-neutral-950/70 border border-neutral-800/80 space-y-2.5 transition hover:border-neutral-700"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-2.5">
                            {rev.avatarUrl ? (
                              <img
                                src={rev.avatarUrl}
                                alt={rev.author}
                                className="w-8 h-8 rounded-full object-cover border border-neutral-700"
                              />
                            ) : (
                              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-sky-600 to-indigo-600 text-white font-bold text-xs flex items-center justify-center">
                                {rev.author.charAt(0).toUpperCase()}
                              </div>
                            )}

                            <div>
                              <div className="flex items-center gap-2">
                                <h5 className="font-bold text-xs text-neutral-100">{rev.author}</h5>
                                {rev.source && (
                                  <span className="text-[9px] px-1.5 py-0.2 rounded bg-neutral-800 text-neutral-400">
                                    {rev.source}
                                  </span>
                                )}
                              </div>
                              <div className="flex items-center gap-1.5 mt-0.5">
                                <div className="flex items-center text-amber-400">
                                  {[1, 2, 3, 4, 5].map((s) => (
                                    <Star
                                      key={s}
                                      className={`w-3 h-3 ${
                                        s <= rev.rating
                                          ? 'fill-amber-400 text-amber-400'
                                          : 'text-neutral-700'
                                      }`}
                                    />
                                  ))}
                                </div>
                                <span className="text-[10px] text-neutral-500">• {rev.date}</span>
                              </div>
                            </div>
                          </div>

                          {/* Like review button */}
                          <button
                            onClick={() => handleLikeReview(rev.id)}
                            className={`px-2.5 py-1 rounded-xl text-[11px] font-medium flex items-center gap-1.5 transition active:scale-95 border ${
                              isLiked
                                ? 'bg-sky-500/20 text-sky-300 border-sky-500/40'
                                : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-neutral-200'
                            }`}
                          >
                            <ThumbsUp className="w-3 h-3" />
                            <span>{likesCount}</span>
                          </button>
                        </div>

                        <p className="text-xs text-neutral-300 leading-relaxed pl-10 whitespace-pre-line">
                          {rev.content}
                        </p>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Share Toast */}
      {shareToast && (
        <div className="fixed bottom-10 left-1/2 -translate-x-1/2 z-50 bg-neutral-900 border border-sky-500/50 text-neutral-100 text-xs px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2 animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-sky-400 flex-shrink-0" />
          <span>{shareToast}</span>
        </div>
      )}
    </div>
  );
};
