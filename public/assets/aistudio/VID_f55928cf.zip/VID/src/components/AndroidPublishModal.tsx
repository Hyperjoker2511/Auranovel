import React, { useState } from 'react';
import {
  Smartphone,
  Download,
  Package,
  CheckCircle,
  X,
  ExternalLink,
  Copy,
  Check,
  ShieldCheck,
  Terminal,
  FileCode,
  Layers,
  Sparkles,
  Zap,
  Globe,
  Vibrate,
  Eye,
  Share2,
  FileText,
  AlertCircle,
  HelpCircle,
  Flame,
  Award,
} from 'lucide-react';
import { usePWAInstall } from '../utils/usePWAInstall';
import {
  isAndroidNative,
  isStandaloneApp,
  triggerNativeHaptic,
  setNativeScreenAwake,
  setNativeStatusBarTheme,
  nativeShare,
  showNativeToast,
} from '../utils/androidBridge';
import { generateAndroidProjectZip } from '../utils/androidProjectZip';

interface AndroidPublishModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type TabKey = 'build' | 'playstore' | 'fdroid' | 'diagnostics' | 'privacy';

export const AndroidPublishModal: React.FC<AndroidPublishModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<TabKey>('build');
  const [isZipping, setIsZipping] = useState(false);
  const [zipSuccess, setZipSuccess] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [testWakeLockActive, setTestWakeLockActive] = useState(false);

  const { isInstallable, isInstalled, isAndroid, isIOS, install } = usePWAInstall();
  const isNative = isAndroidNative();
  const isStandalone = isStandaloneApp();

  if (!isOpen) return null;

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    triggerNativeHaptic('light');
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const handleDownloadProjectZip = async () => {
    try {
      setIsZipping(true);
      triggerNativeHaptic('medium');
      const blob = await generateAndroidProjectZip();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'AetherNovel-Android-Source.zip';
      a.click();
      URL.revokeObjectURL(url);
      setIsZipping(false);
      setZipSuccess(true);
      triggerNativeHaptic('success');
      setTimeout(() => setZipSuccess(false), 4000);
    } catch (err) {
      console.error('Failed to generate Android ZIP:', err);
      setIsZipping(false);
      alert('Could not bundle Android source zip. Please try again.');
    }
  };

  const handleTriggerInstall = async () => {
    triggerNativeHaptic('medium');
    const res = await install();
    if (res === 'accepted') {
      triggerNativeHaptic('success');
    }
  };

  const handleTestWakeLock = async () => {
    const nextState = !testWakeLockActive;
    setTestWakeLockActive(nextState);
    await setNativeScreenAwake(nextState);
    triggerNativeHaptic(nextState ? 'heavy' : 'light');
    showNativeToast(nextState ? 'Screen Wake Lock activated' : 'Screen Wake Lock disabled');
  };

  const handleTestStatusBar = (hex: string) => {
    setNativeStatusBarTheme(false, hex);
    triggerNativeHaptic('light');
    showNativeToast(`Status bar tinted to ${hex}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 animate-fade-in">
      <div className="fixed inset-0 bg-black/80 backdrop-blur-md" onClick={onClose} />

      <div className="relative z-10 w-full max-w-3xl max-h-[90vh] bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-neutral-100">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-neutral-800/80 bg-neutral-950/60 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-amber-500/20 border border-cyan-500/40 text-cyan-300 flex items-center justify-center shadow-inner">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold tracking-tight text-white">
                  Android & App Store Publishing Hub
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Target API 34
                </span>
              </div>
              <p className="text-[11px] text-neutral-400">
                Native Android Studio Project • Google Play Store (AAB) • F-Droid (FLOSS)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 px-6 pt-3 pb-2 border-b border-neutral-800 bg-neutral-950/30 overflow-x-auto no-scrollbar">
          {[
            { id: 'build', label: 'Build & Project Zip', icon: Package },
            { id: 'playstore', label: 'Google Play (AAB)', icon: Globe },
            { id: 'fdroid', label: 'F-Droid Submission', icon: ShieldCheck },
            { id: 'diagnostics', label: 'Hardware Bridge Test', icon: Vibrate },
            { id: 'privacy', label: 'Store Privacy Policy', icon: FileText },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as TabKey);
                  triggerNativeHaptic('light');
                }}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition flex-shrink-0 ${
                  isActive
                    ? 'bg-neutral-800 text-cyan-400 border border-neutral-700 shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-900/50'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-sm">
          {/* ================= TAB 1: BUILD & DOWNLOAD ================= */}
          {activeTab === 'build' && (
            <div className="space-y-6">
              {/* DIRECT APK DOWNLOAD HERO CARD */}
              <div className="relative overflow-hidden p-6 rounded-3xl border border-emerald-500/40 bg-gradient-to-br from-emerald-950/50 via-neutral-900 to-neutral-950 shadow-2xl space-y-4">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2.5 rounded-2xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                        <Smartphone className="w-6 h-6" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-extrabold text-base sm:text-lg text-white tracking-wide">
                            Installable Native Android APK
                          </h3>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500 text-neutral-950">
                            Signed & Ready
                          </span>
                        </div>
                        <p className="text-xs text-emerald-200/80 mt-0.5">
                          Compiled native Android package with offline reader, EPUB associations, and haptics.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto">
                    <a
                      href="/aethernovel.apk"
                      download="AetherNovel.apk"
                      onClick={() => triggerNativeHaptic('success')}
                      className="px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-400 to-emerald-500 hover:from-emerald-300 hover:to-emerald-400 text-neutral-950 font-black text-xs flex items-center justify-center gap-2 transition active:scale-95 shadow-xl shadow-emerald-500/25 flex-shrink-0"
                    >
                      <Download className="w-4 h-4 stroke-[2.5]" />
                      <span>Download APK File (402 KB)</span>
                    </a>

                    <button
                      onClick={() =>
                        handleCopy(
                          typeof window !== 'undefined'
                            ? `${window.location.origin}/aethernovel.apk`
                            : 'https://aethernovel.app/aethernovel.apk',
                          'apk_direct_link'
                        )
                      }
                      className="px-3 py-3 rounded-2xl bg-neutral-800/80 hover:bg-neutral-800 border border-neutral-700 text-neutral-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition active:scale-95"
                      title="Copy download URL to send to phone via messaging"
                    >
                      {copiedKey === 'apk_direct_link' ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Link Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5" />
                          <span>Copy Link</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* APK Verification Specs */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 border-t border-emerald-900/40 text-xs">
                  <div className="p-2.5 rounded-xl bg-neutral-950/60 border border-neutral-800/80">
                    <span className="text-[10px] text-neutral-400 block">Package ID</span>
                    <span className="font-mono text-xs font-bold text-emerald-300">app.aethernovel</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-neutral-950/60 border border-neutral-800/80">
                    <span className="text-[10px] text-neutral-400 block">Android Compatibility</span>
                    <span className="font-mono text-xs font-bold text-neutral-200">Android 5.0 to 15+</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-neutral-950/60 border border-neutral-800/80">
                    <span className="text-[10px] text-neutral-400 block">Signature Scheme</span>
                    <span className="font-mono text-xs font-bold text-emerald-300">v1 + v2 + v3 Verified</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-neutral-950/60 border border-neutral-800/80">
                    <span className="text-[10px] text-neutral-400 block">Architecture</span>
                    <span className="font-mono text-xs font-bold text-amber-300">Universal (All CPUs)</span>
                  </div>
                </div>

                {/* Phone Installation Step-by-Step Instructions */}
                <div className="p-4 rounded-2xl bg-neutral-950/80 border border-neutral-800/80 space-y-2">
                  <span className="text-xs font-bold text-neutral-200 flex items-center gap-1.5">
                    <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                    <span>How to Install on Your Android Phone:</span>
                  </span>
                  <ol className="text-xs text-neutral-300 space-y-1.5 list-decimal pl-5 leading-relaxed">
                    <li>Tap the green <strong className="text-emerald-400">"Download APK File"</strong> button above directly on your phone.</li>
                    <li>When the download finishes, tap the notification or open <code className="text-neutral-200 font-mono">AetherNovel.apk</code> from your <strong>Downloads</strong> folder.</li>
                    <li>If prompted by Android (<em className="text-neutral-400">"Install unknown apps"</em>), tap <strong>Settings</strong> and switch on <strong>"Allow from this source"</strong>.</li>
                    <li>Tap <strong className="text-emerald-400">"Install"</strong> — AetherNovel will be installed with its official book icon in your app drawer!</li>
                  </ol>
                </div>
              </div>

              {/* Platform Detection Banner */}
              <div className="p-4 rounded-2xl bg-neutral-950/80 border border-neutral-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-3 h-3 rounded-full animate-pulse ${
                      isNative
                        ? 'bg-emerald-400 shadow-[0_0_12px_#34d399]'
                        : isStandalone
                        ? 'bg-cyan-400 shadow-[0_0_12px_#22d3ee]'
                        : 'bg-amber-400 shadow-[0_0_12px_#fbbf24]'
                    }`}
                  />
                  <div>
                    <span className="font-bold text-xs text-neutral-200 block">
                      Runtime Environment:{' '}
                      {isNative
                        ? 'Native Android APK (AndroidBridge Attached)'
                        : isStandalone
                        ? 'Standalone WebAPK / Installed PWA'
                        : 'Web Browser Preview'}
                    </span>
                    <span className="text-[11px] text-neutral-400">
                      Package: <code className="text-cyan-400 font-mono">app.aethernovel</code> • Version 1.0.0
                    </span>
                  </div>
                </div>

                {isInstallable && (
                  <button
                    onClick={handleTriggerInstall}
                    className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 text-neutral-950 font-bold text-xs flex items-center gap-1.5 transition active:scale-95 shadow-md"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Install WebAPK on Device</span>
                  </button>
                )}
              </div>

              {/* 1-Click Native Project Zip Download Card */}
              <div className="relative overflow-hidden p-6 rounded-3xl border border-cyan-500/30 bg-gradient-to-br from-cyan-950/40 via-neutral-900 to-neutral-950 shadow-xl space-y-4">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-base text-white">
                        Full Native Android Studio Project Source
                      </h3>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                        Ready to Compile
                      </span>
                    </div>
                    <p className="text-xs text-neutral-300 max-w-xl">
                      Includes complete Gradle build scripts, Kotlin edge-to-edge Activity,
                      AndroidNativeBridge, FileProvider for EPUB association, background audio narration service,
                      and Fastlane store metadata.
                    </p>
                  </div>

                  <button
                    onClick={handleDownloadProjectZip}
                    disabled={isZipping}
                    className="px-5 py-3 rounded-2xl bg-cyan-400 hover:bg-cyan-300 text-neutral-950 font-bold text-xs flex items-center gap-2 transition active:scale-95 shadow-lg shadow-cyan-400/25 flex-shrink-0"
                  >
                    {isZipping ? (
                      <>
                        <div className="w-4 h-4 border-2 border-neutral-950 border-t-transparent rounded-full animate-spin" />
                        <span>Bundling Project...</span>
                      </>
                    ) : zipSuccess ? (
                      <>
                        <Check className="w-4 h-4 stroke-[3]" />
                        <span>Downloaded Source Zip!</span>
                      </>
                    ) : (
                      <>
                        <Download className="w-4 h-4" />
                        <span>Download Android Project (.zip)</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Android Architecture Spec Badges */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
                  <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-center">
                    <span className="text-[10px] text-neutral-400 block">Package ID</span>
                    <span className="font-mono text-xs font-bold text-cyan-300">app.aethernovel</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-center">
                    <span className="text-[10px] text-neutral-400 block">Target SDK</span>
                    <span className="font-mono text-xs font-bold text-amber-300">API 34 (Android 14+)</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-center">
                    <span className="text-[10px] text-neutral-400 block">Min SDK</span>
                    <span className="font-mono text-xs font-bold text-emerald-300">API 24 (Android 7.0+)</span>
                  </div>
                  <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-center">
                    <span className="text-[10px] text-neutral-400 block">License</span>
                    <span className="font-mono text-xs font-bold text-purple-300">Apache-2.0 (FLOSS)</span>
                  </div>
                </div>
              </div>

              {/* Quick CLI Build Instructions */}
              <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-bold text-neutral-200">
                    <Terminal className="w-4 h-4 text-cyan-400" />
                    <span>Quick Command Line Build</span>
                  </div>
                  <span className="text-[11px] text-neutral-500 font-mono">Linux / macOS / WSL</span>
                </div>

                <div className="space-y-2">
                  <div>
                    <div className="flex justify-between items-center text-[11px] text-neutral-400 mb-1">
                      <span>Compile Release APK (Standalone / F-Droid):</span>
                      <button
                        onClick={() => handleCopy('./gradlew assembleRelease', 'cmd1')}
                        className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-mono"
                      >
                        {copiedKey === 'cmd1' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedKey === 'cmd1' ? 'Copied' : 'Copy'}</span>
                      </button>
                    </div>
                    <pre className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-xs font-mono text-neutral-200 overflow-x-auto">
                      ./gradlew assembleRelease
                    </pre>
                  </div>

                  <div>
                    <div className="flex justify-between items-center text-[11px] text-neutral-400 mb-1">
                      <span>Compile Android App Bundle .aab (Google Play):</span>
                      <button
                        onClick={() => handleCopy('./gradlew bundleRelease', 'cmd2')}
                        className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-mono"
                      >
                        {copiedKey === 'cmd2' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedKey === 'cmd2' ? 'Copied' : 'Copy'}</span>
                      </button>
                    </div>
                    <pre className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-xs font-mono text-neutral-200 overflow-x-auto">
                      ./gradlew bundleRelease
                    </pre>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ================= TAB 2: GOOGLE PLAY STORE ================= */}
          {activeTab === 'playstore' && (
            <div className="space-y-6">
              {/* Play Store Step 1: Keystore */}
              <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-300 font-bold text-xs flex items-center justify-center">
                      1
                    </span>
                    <h4 className="font-bold text-sm text-neutral-200">
                      Generate Production Release Keystore
                    </h4>
                  </div>
                  <button
                    onClick={() =>
                      handleCopy(
                        'keytool -genkey -v -keystore aethernovel-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias aethernovel',
                        'keystore'
                      )
                    }
                    className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-mono"
                  >
                    {copiedKey === 'keystore' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedKey === 'keystore' ? 'Copied' : 'Copy Command'}</span>
                  </button>
                </div>
                <p className="text-xs text-neutral-400">
                  Run this command once in your terminal to create a standard cryptographic signing key:
                </p>
                <pre className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-xs font-mono text-amber-300/90 whitespace-pre-wrap break-all">
                  keytool -genkey -v -keystore aethernovel-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias aethernovel
                </pre>
              </div>

              {/* Play Store Step 2: Digital Asset Links */}
              <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-300 font-bold text-xs flex items-center justify-center">
                      2
                    </span>
                    <h4 className="font-bold text-sm text-neutral-200">
                      Digital Asset Links (TWA & App Verification)
                    </h4>
                  </div>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Live Active on Server
                  </span>
                </div>
                <p className="text-xs text-neutral-400">
                  Google Play requires an <code className="text-cyan-300">assetlinks.json</code> file served at{' '}
                  <code className="text-neutral-300">/.well-known/assetlinks.json</code> to prove ownership and remove the URL address bar.
                </p>
                <div className="flex items-center justify-between p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-xs font-mono">
                  <span className="text-neutral-300 truncate">/.well-known/assetlinks.json</span>
                  <a
                    href="/.well-known/assetlinks.json"
                    target="_blank"
                    rel="noreferrer"
                    className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 underline ml-2"
                  >
                    <span>Inspect Live</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              {/* Play Store Step 3: Store Listing Copy */}
              <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-4">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-300 font-bold text-xs flex items-center justify-center">
                    3
                  </span>
                  <h4 className="font-bold text-sm text-neutral-200">
                    Ready-to-Paste Store Listing Metadata
                  </h4>
                </div>

                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between items-center text-xs mb-1">
                      <span className="font-semibold text-neutral-300">App Title (≤ 30 chars):</span>
                      <button
                        onClick={() => handleCopy('AetherNovel - Novel & EPUB Reader', 'meta_title')}
                        className="text-cyan-400 hover:text-cyan-300 text-[11px] flex items-center gap-1"
                      >
                        {copiedKey === 'meta_title' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                        <span>Copy</span>
                      </button>
                    </div>
                    <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-xs font-mono text-neutral-200">
                      AetherNovel - Novel & EPUB Reader
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between items-center text-xs mb-1">
                      <span className="font-semibold text-neutral-300">Short Description (≤ 80 chars):</span>
                      <button
                        onClick={() =>
                          handleCopy(
                            'Distraction-free web novel & EPUB reader with OLED themes and offline audio.',
                            'meta_short'
                          )
                        }
                        className="text-cyan-400 hover:text-cyan-300 text-[11px] flex items-center gap-1"
                      >
                        {copiedKey === 'meta_short' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                        <span>Copy</span>
                      </button>
                    </div>
                    <div className="p-2.5 rounded-xl bg-neutral-900 border border-neutral-800 text-xs font-mono text-neutral-200">
                      Distraction-free web novel & EPUB reader with OLED themes and offline audio.
                    </div>
                  </div>
                </div>
              </div>

              {/* Play Store Step 4: Data Safety & Rating */}
              <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-2.5">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-cyan-500/20 text-cyan-300 font-bold text-xs flex items-center justify-center">
                    4
                  </span>
                  <h4 className="font-bold text-sm text-neutral-200">
                    Google Play Console Data Safety Answers
                  </h4>
                </div>
                <ul className="text-xs text-neutral-300 space-y-1.5 list-disc pl-5">
                  <li><strong>Data collection:</strong> Select <strong>"No"</strong> — The app does not collect or share user data.</li>
                  <li><strong>Encryption in transit:</strong> All chapter fetching uses standard TLS/HTTPS.</li>
                  <li><strong>Account creation:</strong> Optional / Local only. Zero mandatory personal sign-ups.</li>
                  <li><strong>Target Audience:</strong> General audience (13+).</li>
                </ul>
              </div>
            </div>
          )}

          {/* ================= TAB 3: F-DROID SUBMISSION ================= */}
          {activeTab === 'fdroid' && (
            <div className="space-y-6">
              {/* F-Droid Compliance Audit */}
              <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-emerald-400" />
                    <h4 className="font-bold text-sm text-neutral-200">
                      F-Droid Inclusion Criteria & Anti-Features Audit
                    </h4>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    100% Passed
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800/80 flex items-center gap-2 text-neutral-300">
                    <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span>0 Tracking or Analytics SDKs</span>
                  </div>
                  <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800/80 flex items-center gap-2 text-neutral-300">
                    <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span>0 Proprietary Ad Networks</span>
                  </div>
                  <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800/80 flex items-center gap-2 text-neutral-300">
                    <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span>Apache-2.0 Permissive Open Source</span>
                  </div>
                  <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800/80 flex items-center gap-2 text-neutral-300">
                    <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                    <span>Reproducible Gradle Build Recipe</span>
                  </div>
                </div>
              </div>

              {/* F-Droid Recipe YAML */}
              <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileCode className="w-4 h-4 text-amber-400" />
                    <h4 className="font-bold text-sm text-neutral-200">
                      Official F-Droid Recipe (<code className="text-amber-400">metadata/app.aethernovel.yml</code>)
                    </h4>
                  </div>
                  <button
                    onClick={() =>
                      handleCopy(
                        `Categories:
  - Reading
  - Education

License: Apache-2.0
AuthorName: AetherNovel Open Source Authors
SourceCode: https://github.com/aethernovel/aethernovel
WebSite: https://aethernovel.app

AutoName: AetherNovel
Summary: Distraction-free web novel and EPUB reader with OLED themes

Builds:
  - versionName: 1.0.0
    versionCode: 1
    commit: v1.0.0
    subdir: android
    gradle:
      - assembleRelease
    output: app/build/outputs/apk/release/app-release-unsigned.apk

CurrentVersion: 1.0.0
CurrentVersionCode: 1`,
                        'fdroid_yml'
                      )
                    }
                    className="text-xs text-amber-400 hover:text-amber-300 flex items-center gap-1 font-mono"
                  >
                    {copiedKey === 'fdroid_yml' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedKey === 'fdroid_yml' ? 'Copied' : 'Copy Recipe YAML'}</span>
                  </button>
                </div>

                <pre className="p-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-xs font-mono text-neutral-300 overflow-x-auto leading-relaxed">
{`Categories:
  - Reading
  - Education

License: Apache-2.0
AuthorName: AetherNovel Open Source Authors
SourceCode: https://github.com/aethernovel/aethernovel
WebSite: https://aethernovel.app

AutoName: AetherNovel
Summary: Distraction-free web novel and EPUB reader with OLED themes

Builds:
  - versionName: 1.0.0
    versionCode: 1
    commit: v1.0.0
    subdir: android
    gradle:
      - assembleRelease
    output: app/build/outputs/apk/release/app-release-unsigned.apk

CurrentVersion: 1.0.0
CurrentVersionCode: 1`}
                </pre>
              </div>

              {/* Submission Instructions */}
              <div className="p-4 rounded-2xl bg-neutral-900/60 border border-neutral-800 space-y-2">
                <h5 className="font-bold text-xs text-neutral-200">How to Submit to F-Droid:</h5>
                <ol className="text-xs text-neutral-400 space-y-1.5 list-decimal pl-5">
                  <li>Fork the official repository at <code className="text-cyan-300">gitlab.com/fdroid/fdroiddata</code>.</li>
                  <li>Create a new file in <code className="text-cyan-300">metadata/app.aethernovel.yml</code> with the recipe above.</li>
                  <li>Submit a Merge Request (MR). F-Droid's automated build server will compile and sign the APK!</li>
                </ol>
              </div>
            </div>
          )}

          {/* ================= TAB 4: HARDWARE DIAGNOSTICS ================= */}
          {activeTab === 'diagnostics' && (
            <div className="space-y-6">
              <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
                  <div className="flex items-center gap-2">
                    <Vibrate className="w-5 h-5 text-cyan-400" />
                    <h4 className="font-bold text-sm text-neutral-200">
                      Native Android Hardware & Bridge Tester
                    </h4>
                  </div>
                  <span className="text-xs text-neutral-500">Live Device Testing</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* Haptics Test */}
                  <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-neutral-200">Vibration Haptics</span>
                      <span className="text-[10px] text-neutral-500 font-mono">VibratorManager</span>
                    </div>
                    <div className="grid grid-cols-4 gap-1.5">
                      {(['light', 'medium', 'heavy', 'success'] as const).map((type) => (
                        <button
                          key={type}
                          onClick={() => {
                            triggerNativeHaptic(type);
                            showNativeToast(`Haptic: ${type}`);
                          }}
                          className="py-2 px-1 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-[11px] font-bold capitalize transition active:scale-95"
                        >
                          {type}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* WakeLock Test */}
                  <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-neutral-200">Keep Screen Awake</span>
                      <span className="text-[10px] text-neutral-500 font-mono">FLAG_KEEP_SCREEN_ON</span>
                    </div>
                    <button
                      onClick={handleTestWakeLock}
                      className={`w-full py-2 px-3 rounded-lg text-xs font-bold transition flex items-center justify-center gap-2 ${
                        testWakeLockActive
                          ? 'bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/20'
                          : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300'
                      }`}
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>{testWakeLockActive ? 'Screen Lock Active (Awake)' : 'Test Wake Lock'}</span>
                    </button>
                  </div>

                  {/* Status Bar Tint */}
                  <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-neutral-200">Status Bar Dynamic Tint</span>
                      <span className="text-[10px] text-neutral-500 font-mono">WindowCompat</span>
                    </div>
                    <div className="flex gap-2">
                      {[
                        { color: '#090D16', label: 'Dark' },
                        { color: '#000000', label: 'OLED' },
                        { color: '#0e1f38', label: 'Blue' },
                        { color: '#1c1715', label: 'Mocha' },
                      ].map((c) => (
                        <button
                          key={c.color}
                          onClick={() => handleTestStatusBar(c.color)}
                          className="flex-1 py-1.5 rounded-lg text-[10px] font-bold border border-neutral-700 text-neutral-300 hover:text-white transition"
                          style={{ backgroundColor: c.color }}
                        >
                          {c.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Native Share Intent */}
                  <div className="p-4 rounded-xl bg-neutral-900 border border-neutral-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-neutral-200">System Share Intent</span>
                      <span className="text-[10px] text-neutral-500 font-mono">ACTION_SEND</span>
                    </div>
                    <button
                      onClick={() =>
                        nativeShare(
                          'AetherNovel - Next-Gen Reader',
                          window.location.origin || 'https://aethernovel.app'
                        )
                      }
                      className="w-full py-2 px-3 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-cyan-300 text-xs font-bold flex items-center justify-center gap-2 transition"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                      <span>Trigger Native Share Sheet</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ================= TAB 5: STORE PRIVACY POLICY ================= */}
          {activeTab === 'privacy' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-neutral-950 border border-neutral-800 flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-xs text-neutral-200">Official Privacy Policy URL</h4>
                  <p className="text-[11px] text-neutral-400">
                    Mandatory for Google Play Console and F-Droid submission.
                  </p>
                </div>
                <a
                  href="/privacy"
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold text-xs flex items-center gap-1.5 hover:bg-cyan-500/30 transition"
                >
                  <span>Open /privacy</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              <div className="p-5 rounded-2xl bg-neutral-950/80 border border-neutral-800 text-xs text-neutral-300 space-y-3 leading-relaxed max-h-80 overflow-y-auto">
                <p>
                  <strong>AetherNovel</strong> operates under a strict Zero-Telemetry, Zero-Surveillance architecture.
                  Reading data, downloaded chapters, and bookmarks never leave the user's device.
                </p>
                <p>
                  <strong>Permissions:</strong> The application uses <code className="text-cyan-300">INTERNET</code> to fetch user-requested web chapters, <code className="text-cyan-300">WAKE_LOCK</code> for comfortable reading without display timeouts, <code className="text-cyan-300">VIBRATE</code> for page flip haptics, and <code className="text-cyan-300">FOREGROUND_SERVICE</code> for background audio narration.
                </p>
                <p>
                  No third-party trackers, advertisements, or tracking cookies are included in any build.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 border-t border-neutral-800 bg-neutral-950/80 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-neutral-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Google Play & F-Droid Ready</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadProjectZip}
              className="px-3.5 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-semibold transition"
            >
              Export Project Zip
            </button>
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-neutral-950 font-bold transition"
            >
              Done
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
