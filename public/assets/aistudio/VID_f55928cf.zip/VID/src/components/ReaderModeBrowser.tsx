import React, { useState } from 'react';
import {
  Globe,
  Sparkles,
  BookOpen,
  BookmarkPlus,
  ShieldCheck,
  Eye,
  Code,
  ExternalLink,
  ArrowRight,
  Clock,
  FileText,
  Check,
  AlertCircle,
  RefreshCw,
} from 'lucide-react';
import { Novel, ChapterMeta, ChapterContent } from '../types/novel';
import { saveNovel, saveChapterContent } from '../utils/storage';

interface ReaderModeBrowserProps {
  onOpenReader: (novel: Novel, initialChapterIndex: number) => void;
  onNovelAddedToLibrary: (novel: Novel) => void;
}

interface ScrapedData {
  title: string;
  author: string;
  siteName: string;
  url: string;
  cleanedHtml: string;
  text: string;
  wordCount: number;
  readingTimeMin: number;
}

export const ReaderModeBrowser: React.FC<ReaderModeBrowserProps> = ({
  onOpenReader,
  onNovelAddedToLibrary,
}) => {
  const [urlInput, setUrlInput] = useState('');
  const [isScraping, setIsScraping] = useState(false);
  const [scrapedData, setScrapedData] = useState<ScrapedData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isReaderMode, setIsReaderMode] = useState(true);
  const [isSaved, setIsSaved] = useState(false);

  // AI summary on extracted article
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  const handleScrape = async (targetUrl?: string) => {
    const urlToFetch = targetUrl || urlInput.trim();
    if (!urlToFetch) return;

    setIsScraping(true);
    setError(null);
    setAiSummary(null);
    setIsSaved(false);

    try {
      const res = await fetch('/api/novel/scrape', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: urlToFetch }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to extract content from URL');
      }

      setScrapedData(data);
      setUrlInput(urlToFetch);
    } catch (err: any) {
      console.error('Extraction error:', err);
      setError(err.message || 'Unable to load article. Please check the URL.');
    } finally {
      setIsScraping(false);
    }
  };

  const handleSaveToLibrary = async () => {
    if (!scrapedData) return;

    const novelId = 'web_' + Date.now();
    const chapterId = `${novelId}_ch_0`;

    const chapterMeta: ChapterMeta = {
      id: chapterId,
      novelId,
      index: 0,
      title: scrapedData.title,
      url: scrapedData.url,
      wordCount: scrapedData.wordCount,
      isDownloaded: true,
    };

    const newNovel: Novel = {
      id: novelId,
      title: scrapedData.title,
      author: scrapedData.author || scrapedData.siteName,
      coverUrl: 'https://images.unsplash.com/photo-1457369804613-52c61a468e7d?w=500&auto=format&fit=crop&q=80',
      description: `Saved from ${scrapedData.siteName} (${scrapedData.wordCount} words, ~${scrapedData.readingTimeMin} min read). ${scrapedData.text.slice(0, 160)}...`,
      genres: ['Web Article', 'Distraction-Free', scrapedData.siteName],
      sourceType: 'web',
      sourceName: scrapedData.siteName,
      sourceUrl: scrapedData.url,
      status: 'reading',
      currentChapterIndex: 0,
      currentProgressPercent: 0,
      totalChapters: 1,
      chapters: [chapterMeta],
      lastReadAt: Date.now(),
      createdAt: Date.now(),
      tags: ['Web Article'],
    };

    const chapterContent: ChapterContent = {
      id: chapterId,
      novelId,
      index: 0,
      title: scrapedData.title,
      contentHtml: scrapedData.cleanedHtml,
      text: scrapedData.text,
      wordCount: scrapedData.wordCount,
      cachedAt: Date.now(),
    };

    await saveNovel(newNovel);
    await saveChapterContent(chapterContent);
    onNovelAddedToLibrary(newNovel);
    setIsSaved(true);
  };

  const handleOpenInReader = async () => {
    if (!scrapedData) return;
    await handleSaveToLibrary();

    const novelId = 'web_' + Date.now();
    const newNovel: Novel = {
      id: novelId,
      title: scrapedData.title,
      author: scrapedData.author || scrapedData.siteName,
      coverUrl: 'https://images.unsplash.com/photo-1457369804613-52c61a468e7d?w=500&auto=format&fit=crop&q=80',
      description: scrapedData.text.slice(0, 150),
      genres: ['Web Article'],
      sourceType: 'web',
      sourceName: scrapedData.siteName,
      sourceUrl: scrapedData.url,
      status: 'reading',
      currentChapterIndex: 0,
      currentProgressPercent: 0,
      totalChapters: 1,
      chapters: [
        {
          id: `${novelId}_ch_0`,
          novelId,
          index: 0,
          title: scrapedData.title,
          wordCount: scrapedData.wordCount,
        },
      ],
      lastReadAt: Date.now(),
      createdAt: Date.now(),
    };

    const content: ChapterContent = {
      id: `${novelId}_ch_0`,
      novelId,
      index: 0,
      title: scrapedData.title,
      contentHtml: scrapedData.cleanedHtml,
      text: scrapedData.text,
      wordCount: scrapedData.wordCount,
      cachedAt: Date.now(),
    };

    await saveNovel(newNovel);
    await saveChapterContent(content);
    onOpenReader(newNovel, 0);
  };

  const handleAiSummarize = async () => {
    if (!scrapedData) return;
    setIsAiLoading(true);
    try {
      const res = await fetch('/api/novel/summarize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: scrapedData.title,
          text: scrapedData.text,
        }),
      });
      const data = await res.json();
      setAiSummary(data.recap || 'Article parsed successfully.');
    } catch (err) {
      console.error('Summary error:', err);
    } finally {
      setIsAiLoading(false);
    }
  };

  const sampleLinks = [
    {
      label: 'Royal Road Fiction',
      url: 'https://www.royalroad.com/fiction/21220/mother-of-learning/chapter/301778/1-good-morning-brother',
    },
    {
      label: 'Project Gutenberg',
      url: 'https://www.gutenberg.org/files/84/84-h/84-h.htm',
    },
    {
      label: 'Wikipedia Article',
      url: 'https://en.wikipedia.org/wiki/Web_fiction',
    },
  ];

  return (
    <div className="flex-1 w-full max-w-5xl mx-auto p-4 sm:p-6 flex flex-col gap-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-neutral-900 to-neutral-950 border border-neutral-800 rounded-2xl p-5 sm:p-7 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-medium mb-3">
              <ShieldCheck className="w-3.5 h-3.5" /> Ad & Clutter Stripper
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-neutral-100">
              Web to Book Reader Mode
            </h2>
            <p className="text-xs sm:text-sm text-neutral-400 mt-1 max-w-xl">
              Paste any web novel, article, or blog URL. Our engine strips away CSS clutter,
              advertisements, and tracking scripts for an ultra-clean, distraction-free reading
              experience.
            </p>
          </div>
        </div>

        {/* URL Input Form */}
        <div className="mt-5 flex flex-col sm:flex-row gap-2.5">
          <div className="relative flex-1">
            <Globe className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
            <input
              type="url"
              placeholder="Paste website or chapter URL (e.g. https://...)"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleScrape()}
              className="w-full pl-10 pr-4 py-3 bg-neutral-950/80 border border-neutral-800 rounded-xl text-xs sm:text-sm text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500 transition"
            />
          </div>
          <button
            onClick={() => handleScrape()}
            disabled={isScraping || !urlInput.trim()}
            className="px-6 py-3 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-neutral-950 font-semibold text-xs sm:text-sm rounded-xl transition flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 active:scale-95"
          >
            {isScraping ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Extracting...</span>
              </>
            ) : (
              <>
                <span>Extract Reader Mode</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>

        {/* Sample Links */}
        <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-neutral-400">
          <span className="text-[11px] uppercase tracking-wider text-neutral-500">Try Sample:</span>
          {sampleLinks.map((sample, idx) => (
            <button
              key={idx}
              onClick={() => {
                setUrlInput(sample.url);
                handleScrape(sample.url);
              }}
              className="px-2.5 py-1 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-amber-300 hover:border-amber-500/40 text-[11px] transition"
            >
              {sample.label}
            </button>
          ))}
        </div>
      </div>

      {/* Error Banner */}
      {error && (
        <div className="p-4 rounded-xl bg-rose-950/40 border border-rose-800/60 text-rose-300 text-xs flex items-center gap-3">
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Scraped Content Result Viewport */}
      {scrapedData && (
        <div className="bg-neutral-900/60 border border-neutral-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col">
          {/* Action Toolbar */}
          <div className="p-4 bg-neutral-950/90 border-b border-neutral-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              {/* Reader Mode Toggle */}
              <div className="flex p-1 rounded-xl bg-neutral-900 border border-neutral-800 text-xs">
                <button
                  onClick={() => setIsReaderMode(true)}
                  className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition font-medium ${
                    isReaderMode
                      ? 'bg-amber-500 text-neutral-950 shadow-sm'
                      : 'text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Reader Mode</span>
                </button>
                <button
                  onClick={() => setIsReaderMode(false)}
                  className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition font-medium ${
                    !isReaderMode
                      ? 'bg-neutral-800 text-neutral-200'
                      : 'text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  <Code className="w-3.5 h-3.5" />
                  <span>Source Web</span>
                </button>
              </div>

              {/* Stats badges */}
              <span className="hidden sm:inline-flex items-center gap-1 text-[11px] text-neutral-400 bg-neutral-900 px-2.5 py-1 rounded-lg border border-neutral-800">
                <Clock className="w-3 h-3" /> ~{scrapedData.readingTimeMin} min
              </span>
              <span className="hidden sm:inline-flex items-center gap-1 text-[11px] text-neutral-400 bg-neutral-900 px-2.5 py-1 rounded-lg border border-neutral-800">
                <FileText className="w-3 h-3" /> {scrapedData.wordCount.toLocaleString()} words
              </span>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-2">
              <button
                onClick={handleAiSummarize}
                disabled={isAiLoading}
                className="px-3 py-1.5 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-400 hover:bg-purple-500/20 text-xs font-medium flex items-center gap-1.5 transition active:scale-95"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isAiLoading ? 'Summarizing...' : 'AI Summary'}</span>
              </button>

              <button
                onClick={handleSaveToLibrary}
                className={`px-3.5 py-1.5 rounded-xl border text-xs font-medium flex items-center gap-1.5 transition active:scale-95 ${
                  isSaved
                    ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-400'
                    : 'bg-neutral-800 border-neutral-700 text-neutral-200 hover:border-neutral-600'
                }`}
              >
                {isSaved ? <Check className="w-3.5 h-3.5" /> : <BookmarkPlus className="w-3.5 h-3.5" />}
                <span>{isSaved ? 'Saved to Library' : 'Save to Library'}</span>
              </button>

              <button
                onClick={handleOpenInReader}
                className="px-3.5 py-1.5 rounded-xl bg-amber-500 text-neutral-950 hover:bg-amber-400 font-semibold text-xs flex items-center gap-1.5 transition active:scale-95 shadow-md shadow-amber-500/20"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Read Full Screen</span>
              </button>
            </div>
          </div>

          {/* AI Summary Callout */}
          {aiSummary && (
            <div className="mx-6 mt-6 p-4 rounded-xl bg-purple-950/20 border border-purple-800/40 text-xs text-purple-200 flex flex-col gap-1.5">
              <div className="flex items-center gap-2 font-semibold text-purple-300">
                <Sparkles className="w-4 h-4" />
                <span>Smart AI Executive Summary</span>
              </div>
              <p className="leading-relaxed opacity-90">{aiSummary}</p>
            </div>
          )}

          {/* Article / Web Container */}
          <div className="p-6 sm:p-10 max-h-[70vh] overflow-y-auto">
            {isReaderMode ? (
              <article className="max-w-2xl mx-auto font-serif">
                <header className="mb-8 pb-6 border-b border-neutral-800">
                  <span className="text-xs uppercase tracking-wider text-amber-400 font-sans font-semibold">
                    {scrapedData.siteName}
                  </span>
                  <h1 className="text-2xl sm:text-3xl font-bold text-neutral-100 tracking-tight mt-1 mb-3">
                    {scrapedData.title}
                  </h1>
                  <div className="flex items-center gap-3 text-xs text-neutral-400 font-sans">
                    <span>By {scrapedData.author}</span>
                    <span>•</span>
                    <a
                      href={scrapedData.url}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-1 text-neutral-400 hover:text-amber-400 transition"
                    >
                      Original Source <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </header>

                <div
                  className="prose prose-invert prose-neutral max-w-none text-base sm:text-lg leading-relaxed text-neutral-300 space-y-4 [&>p]:leading-relaxed [&>h3]:text-xl [&>h3]:font-bold [&>h3]:text-neutral-100 [&>h3]:mt-6 [&>h3]:mb-2 [&>blockquote]:border-l-2 [&>blockquote]:border-amber-500 [&>blockquote]:pl-4 [&>blockquote]:italic"
                  dangerouslySetInnerHTML={{ __html: scrapedData.cleanedHtml }}
                />
              </article>
            ) : (
              <div className="w-full flex flex-col gap-4">
                <div className="text-xs text-neutral-400 flex items-center justify-between pb-2 border-b border-neutral-800">
                  <span>Source URL: {scrapedData.url}</span>
                  <a
                    href={scrapedData.url}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 text-amber-400 hover:underline"
                  >
                    Open in new tab <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
                <div className="p-4 bg-neutral-950 rounded-xl border border-neutral-800 text-xs font-mono text-neutral-400 whitespace-pre-wrap max-h-96 overflow-y-auto">
                  {scrapedData.text}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
