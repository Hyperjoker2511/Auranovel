import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  List,
  Settings,
  Sparkles,
  Bookmark,
  Volume2,
  VolumeX,
  Play,
  Pause,
  Sun,
  Eye,
  Type,
  Maximize2,
  Minimize2,
  RotateCcw,
  FastForward,
  X,
  Check,
  Download,
  Share2,
  Columns2,
  BookOpen,
  HelpCircle,
  Users,
  Compass,
  Palette,
  Search,
  ArrowUpDown,
  AlignLeft,
  AlignJustify,
  AlignCenter,
  Sliders,
} from 'lucide-react';
import {
  Novel,
  ChapterContent,
  ReaderSettings,
  Bookmark as BookmarkType,
  AISummaryResult,
  AILoreResult,
  ReaderTheme,
  AccentColor,
  ReaderFont,
} from '../types/novel';
import { THEME_STYLES, ACCENT_HEX_MAP } from '../utils/themeConfig';
import { applyBionicReading } from '../utils/readerUtils';
import { saveBookmark, updateReadingTime, incrementChapterCompleted, DEFAULT_SETTINGS } from '../utils/storage';
import { fetchChapterContent } from '../utils/chapterDownloader';
import { generateNovelShareLink } from '../utils/shareUtils';
import { playPageFlipSound, triggerHapticFeedback } from '../utils/audioEffects';
import {
  setNativeScreenAwake,
  setNativeStatusBarTheme,
  nativeShare,
  startNativeAudioService,
  stopNativeAudioService,
} from '../utils/androidBridge';

interface ReaderViewProps {
  novel: Novel;
  initialChapterIndex: number;
  settings: ReaderSettings;
  onUpdateSettings: (newSettings: ReaderSettings) => void;
  onUpdateNovelProgress: (
    novelId: string,
    chapterIndex: number,
    progressPercent: number,
    paragraphIndex?: number
  ) => void;
  onClose: () => void;
  epubChapterGetter?: (index: number) => Promise<ChapterContent>;
}

export const ReaderView: React.FC<ReaderViewProps> = ({
  novel,
  initialChapterIndex,
  settings,
  onUpdateSettings,
  onUpdateNovelProgress,
  onClose,
  epubChapterGetter,
}) => {
  const [currentChapterIndex, setCurrentChapterIndex] = useState(initialChapterIndex);
  const [chapterContent, setChapterContent] = useState<ChapterContent | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // UI overlays
  const [showControls, setShowControls] = useState(false);
  const [showToc, setShowToc] = useState(false);
  const [showSettingsDrawer, setShowSettingsDrawer] = useState(false);
  const [showAiCompanion, setShowAiCompanion] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Table of Contents & Chapter list search / sort
  const [tocSearchQuery, setTocSearchQuery] = useState('');
  const [tocSortAsc, setTocSortAsc] = useState(true);
  const [settingsResetSuccess, setSettingsResetSuccess] = useState(false);

  // AI data states
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiSummary, setAiSummary] = useState<AISummaryResult | null>(null);
  const [aiLore, setAiLore] = useState<AILoreResult | null>(null);
  const [aiExplainText, setAiExplainText] = useState<string | null>(null);
  const [selectedWordToExplain, setSelectedWordToExplain] = useState<string>('');

  // Pagination & Reading progress
  const [currentPage, setCurrentPage] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const contentContainerRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Paragraph-level resume memory
  const [resumedParagraphIdx, setResumedParagraphIdx] = useState<number | null>(
    novel.currentChapterIndex === initialChapterIndex ? (novel.currentParagraphIndex ?? null) : null
  );
  const [showResumeBadge, setShowResumeBadge] = useState<boolean>(false);
  const [activeParagraphIndex, setActiveParagraphIndex] = useState<number>(
    novel.currentParagraphIndex || 0
  );

  // Text-To-Speech (TTS)
  const [isTtsPlaying, setIsTtsPlaying] = useState(false);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const ttsUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Auto-scroll
  const [isAutoScrolling, setIsAutoScrolling] = useState(false);
  const autoScrollTimerRef = useRef<number | null>(null);

  // Bookmarking feedback
  const [bookmarkAdded, setBookmarkAdded] = useState(false);
  const [shareToast, setShareToast] = useState<string | null>(null);
  const [rulerY, setRulerY] = useState<number>(35); // percentage from top

  const handleShareNovel = async () => {
    const link = generateNovelShareLink(novel);
    const shared = await nativeShare(novel.title, link);
    if (!shared) {
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          await navigator.clipboard.writeText(link);
        } else {
          prompt('Copy novel link to share:', link);
        }
        setShareToast(`Link copied! Friends clicking it can view & read "${novel.title}".`);
        setTimeout(() => setShareToast(null), 4000);
      } catch {
        prompt('Copy novel link to share:', link);
      }
    }
  };

  // Load available system TTS voices
  useEffect(() => {
    if ('speechSynthesis' in window) {
      const updateVoices = () => {
        const voices = window.speechSynthesis.getVoices();
        setAvailableVoices(voices);
      };
      updateVoices();
      window.speechSynthesis.onvoiceschanged = updateVoices;
    }
  }, []);

  // Time tracking for XP and weekly activity
  useEffect(() => {
    const timer = setInterval(() => {
      updateReadingTime(10);
    }, 10000);
    return () => clearInterval(timer);
  }, []);

  // Stable references to prevent infinite loading/reloading re-render loop
  const onUpdateNovelProgressRef = useRef(onUpdateNovelProgress);
  useEffect(() => {
    onUpdateNovelProgressRef.current = onUpdateNovelProgress;
  }, [onUpdateNovelProgress]);

  const novelRef = useRef(novel);
  useEffect(() => {
    novelRef.current = novel;
  }, [novel]);

  const epubChapterGetterRef = useRef(epubChapterGetter);
  useEffect(() => {
    epubChapterGetterRef.current = epubChapterGetter;
  }, [epubChapterGetter]);

  const lastLoadedChapterRef = useRef<number | null>(null);
  const isFetchingChapterRef = useRef<boolean>(false);
  const lastReportedProgressRef = useRef<{ percent: number; paragraph: number }>({
    percent: -1,
    paragraph: -1,
  });

  // Load Chapter Content - completely stable function reference
  const loadChapter = useCallback(
    async (index: number, forceReload = false) => {
      if (isFetchingChapterRef.current && lastLoadedChapterRef.current === index && !forceReload) {
        return;
      }
      isFetchingChapterRef.current = true;
      lastLoadedChapterRef.current = index;
      setIsLoading(true);
      setError(null);
      setCurrentPage(0);
      setAiSummary(null);
      setAiLore(null);

      try {
        let content: ChapterContent;
        const currentNovel = novelRef.current;
        if (currentNovel.sourceType === 'epub' && epubChapterGetterRef.current) {
          content = await epubChapterGetterRef.current(index);
        } else {
          content = await fetchChapterContent(currentNovel, index);
        }

        setChapterContent(content);
        setCurrentChapterIndex(index);

        // Notify initial chapter index without resetting if resuming
        if (onUpdateNovelProgressRef.current) {
          onUpdateNovelProgressRef.current(currentNovel.id, index, 0);
        }

        if (scrollContainerRef.current) {
          scrollContainerRef.current.scrollTop = 0;
        }
      } catch (err: any) {
        console.error('Error loading chapter:', err);
        setError(err?.message || 'Failed to load chapter content. Tap retry to reload.');
      } finally {
        setIsLoading(false);
        isFetchingChapterRef.current = false;
      }
    },
    [] // Completely stable! Never causes infinite re-renders!
  );

  // Load chapter on mount or when requested initialChapterIndex changes
  useEffect(() => {
    loadChapter(initialChapterIndex);
  }, [initialChapterIndex, loadChapter]);

  // Paginated mode calculation
  useEffect(() => {
    if (settings.readingMode === 'paginated' && contentContainerRef.current && chapterContent) {
      const container = contentContainerRef.current;
      const scrollW = container.scrollWidth;
      const clientW = container.clientWidth || 1;
      const calculatedPages = Math.max(1, Math.ceil(scrollW / clientW));
      setTotalPages(calculatedPages);
    }
  }, [
    settings.readingMode,
    settings.twoColumnTablet,
    chapterContent,
    settings.fontSize,
    settings.lineHeight,
    settings.fontFamily,
  ]);

  // Auto-scroll or jump to the exact paragraph where the user left off
  useEffect(() => {
    if (resumedParagraphIdx !== null && !isLoading && chapterContent) {
      const timer = setTimeout(() => {
        if (settings.readingMode === 'scroll' && scrollContainerRef.current) {
          const el = scrollContainerRef.current.querySelector(
            `[data-paragraph-idx="${resumedParagraphIdx}"]`
          ) as HTMLElement;
          if (el) {
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            setShowResumeBadge(true);
          }
        } else if (settings.readingMode === 'paginated' && contentContainerRef.current) {
          const el = contentContainerRef.current.querySelector(
            `[data-paragraph-idx="${resumedParagraphIdx}"]`
          ) as HTMLElement;
          if (el && contentContainerRef.current) {
            const containerW = contentContainerRef.current.clientWidth || 1;
            const pLeft = el.offsetLeft;
            const targetPage = Math.min(totalPages - 1, Math.max(0, Math.floor(pLeft / containerW)));
            setCurrentPage(targetPage);
            setShowResumeBadge(true);
          }
        }
      }, 350);

      const fadeTimer = setTimeout(() => setShowResumeBadge(false), 6000);
      return () => {
        clearTimeout(timer);
        clearTimeout(fadeTimer);
      };
    }
  }, [resumedParagraphIdx, isLoading, chapterContent, settings.readingMode, totalPages]);

  const handleScroll = () => {
    if (settings.readingMode !== 'scroll' || !scrollContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = scrollContainerRef.current;
    const maxScroll = scrollHeight - clientHeight;
    if (maxScroll > 0) {
      const percent = Math.min(100, Math.round((scrollTop / maxScroll) * 100));

      // Detect paragraph in view
      const pElements = scrollContainerRef.current.querySelectorAll('[data-paragraph-idx]');
      let detectedPIdx = activeParagraphIndex;
      const viewportTop = scrollContainerRef.current.getBoundingClientRect().top;

      for (let i = 0; i < pElements.length; i++) {
        const p = pElements[i] as HTMLElement;
        const rect = p.getBoundingClientRect();
        if (rect.top - viewportTop >= 0 && rect.top - viewportTop <= clientHeight * 0.45) {
          detectedPIdx = parseInt(p.getAttribute('data-paragraph-idx') || '0', 10);
          break;
        }
      }

      setActiveParagraphIndex(detectedPIdx);

      // Throttle updates to avoid excessive state updates and UI thrashing
      if (
        Math.abs(lastReportedProgressRef.current.percent - percent) >= 3 ||
        lastReportedProgressRef.current.paragraph !== detectedPIdx
      ) {
        lastReportedProgressRef.current = { percent, paragraph: detectedPIdx };
        if (onUpdateNovelProgressRef.current) {
          onUpdateNovelProgressRef.current(novelRef.current.id, currentChapterIndex, percent, detectedPIdx);
        }
      }
    }
  };

  const handleNextPage = () => {
    if (settings.soundEffects !== false) playPageFlipSound();
    if (settings.hapticFeedback !== false) triggerHapticFeedback(12);

    if (settings.readingMode === 'paginated') {
      if (currentPage < totalPages - 1) {
        const next = currentPage + 1;
        setCurrentPage(next);
        const percent = Math.round((next / (totalPages - 1)) * 100);
        onUpdateNovelProgress(novel.id, currentChapterIndex, percent);
      } else if (currentChapterIndex < novel.chapters.length - 1) {
        incrementChapterCompleted();
        loadChapter(currentChapterIndex + 1);
      }
    } else {
      if (currentChapterIndex < novel.chapters.length - 1) {
        incrementChapterCompleted();
        loadChapter(currentChapterIndex + 1);
      }
    }
  };

  const handlePrevPage = () => {
    if (settings.soundEffects !== false) playPageFlipSound();
    if (settings.hapticFeedback !== false) triggerHapticFeedback(12);

    if (settings.readingMode === 'paginated') {
      if (currentPage > 0) {
        const prev = currentPage - 1;
        setCurrentPage(prev);
        const percent = Math.round((prev / (totalPages - 1)) * 100);
        onUpdateNovelProgress(novel.id, currentChapterIndex, percent);
      } else if (currentChapterIndex > 0) {
        loadChapter(currentChapterIndex - 1);
      }
    } else {
      if (currentChapterIndex > 0) {
        loadChapter(currentChapterIndex - 1);
      }
    }
  };

  // Keyboard and Hardware volume navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isVolumeDown = e.key === 'AudioVolumeDown' || e.key === 'VolumeDown';
      const isVolumeUp = e.key === 'AudioVolumeUp' || e.key === 'VolumeUp';

      if (
        e.key === 'ArrowRight' ||
        e.key === 'PageDown' ||
        e.key === ' ' ||
        (settings.volumeKeyNavigation && isVolumeDown)
      ) {
        handleNextPage();
      } else if (
        e.key === 'ArrowLeft' ||
        e.key === 'PageUp' ||
        (settings.volumeKeyNavigation && isVolumeUp)
      ) {
        handlePrevPage();
      } else if (e.key === 'Escape') {
        setShowControls((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentPage, totalPages, currentChapterIndex, settings.readingMode, settings.volumeKeyNavigation, settings.soundEffects, settings.hapticFeedback]);

  // Auto-scroll loop
  useEffect(() => {
    if (isAutoScrolling && settings.readingMode === 'scroll') {
      autoScrollTimerRef.current = window.setInterval(() => {
        if (scrollContainerRef.current) {
          scrollContainerRef.current.scrollTop += settings.autoScrollSpeed * 1.5;
        }
      }, 50);
    } else {
      if (autoScrollTimerRef.current) {
        clearInterval(autoScrollTimerRef.current);
      }
    }
    return () => {
      if (autoScrollTimerRef.current) clearInterval(autoScrollTimerRef.current);
    };
  }, [isAutoScrolling, settings.readingMode, settings.autoScrollSpeed]);

  // Text-To-Speech (TTS)
  const toggleTts = () => {
    if (!('speechSynthesis' in window)) {
      alert('Text-to-speech is not supported by your browser.');
      return;
    }

    if (isTtsPlaying) {
      window.speechSynthesis.cancel();
      stopNativeAudioService();
      setIsTtsPlaying(false);
      return;
    }

    if (!chapterContent?.text) return;

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(chapterContent.text.slice(0, 20000));
    utterance.rate = settings.ttsSpeed || 1.0;
    utterance.pitch = settings.ttsPitch || 1.0;

    if (settings.ttsVoiceUri) {
      const selected = availableVoices.find((v) => v.voiceURI === settings.ttsVoiceUri);
      if (selected) utterance.voice = selected;
    }

    utterance.onend = () => {
      stopNativeAudioService();
      setIsTtsPlaying(false);
    };
    utterance.onerror = () => {
      stopNativeAudioService();
      setIsTtsPlaying(false);
    };

    ttsUtteranceRef.current = utterance;
    window.speechSynthesis.speak(utterance);
    startNativeAudioService(novel.title, chapterContent.title);
    setIsTtsPlaying(true);
  };

  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      stopNativeAudioService();
    };
  }, []);

  // Native Android Hardware Volume Rocker Navigation
  useEffect(() => {
    window.__handleAndroidVolumeKey = (direction: 'up' | 'down') => {
      if (!settings.volumeKeyNavigation) return false;
      if (direction === 'down') {
        handleNextPage();
        return true;
      } else if (direction === 'up') {
        handlePrevPage();
        return true;
      }
      return false;
    };
    return () => {
      window.__handleAndroidVolumeKey = undefined;
    };
  }, [settings.volumeKeyNavigation, handleNextPage, handlePrevPage]);

  // Save Bookmark
  const handleSaveBookmark = () => {
    if (!chapterContent) return;
    const snippet = chapterContent.text.slice(0, 120) + '...';
    const newBookmark: BookmarkType = {
      id: 'bm_' + Date.now(),
      novelId: novel.id,
      chapterIndex: currentChapterIndex,
      chapterTitle: chapterContent.title,
      percentage:
        settings.readingMode === 'paginated' && totalPages > 1
          ? Math.round((currentPage / (totalPages - 1)) * 100)
          : 0,
      snippet,
      createdAt: Date.now(),
    };
    saveBookmark(newBookmark);
    setBookmarkAdded(true);
    setTimeout(() => setBookmarkAdded(false), 2000);
  };

  // Fullscreen toggle
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  // AI Chapter Lore & Recap Fetch
  const handleFetchAiCompanion = async () => {
    if (!chapterContent) return;
    setShowAiCompanion(true);
    setIsAiLoading(true);

    try {
      const [sumRes, loreRes] = await Promise.all([
        fetch('/api/novel/summarize', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: novel.title,
            chapterTitle: chapterContent.title,
            text: chapterContent.text,
          }),
        }),
        fetch('/api/novel/ai-lore', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            title: novel.title,
            chapterTitle: chapterContent.title,
            text: chapterContent.text,
          }),
        }),
      ]);

      const sumData = await sumRes.json();
      const loreData = await loreRes.json();

      setAiSummary(sumData);
      setAiLore(loreData);
    } catch (err) {
      console.error('AI Companion error:', err);
    } finally {
      setIsAiLoading(false);
    }
  };

  // AI Term Explainer
  const handleExplainSelectedPhrase = async () => {
    if (!selectedWordToExplain.trim()) return;
    try {
      const res = await fetch('/api/novel/ai-explain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phrase: selectedWordToExplain,
          context: chapterContent?.title || novel.title,
        }),
      });
      const data = await res.json();
      setAiExplainText(data.explanation);
    } catch (err) {
      console.error('Explain error:', err);
    }
  };

  const themeStyle = THEME_STYLES[settings.theme] || THEME_STYLES.oled;
  const accentHex = ACCENT_HEX_MAP[settings.accentColor || 'amber'] || '#f59e0b';

  // Keep Android screen awake while reading and tint status bar to match theme
  useEffect(() => {
    setNativeScreenAwake(true);
    const rawBg = themeStyle.bg;
    const cleanHex = rawBg.startsWith('#')
      ? rawBg
      : rawBg.includes('0, 0, 0')
      ? '#000000'
      : '#090D16';
    setNativeStatusBarTheme(false, cleanHex);

    return () => {
      setNativeScreenAwake(false);
      setNativeStatusBarTheme(false, '#090D16');
    };
  }, [themeStyle.bg]);

  const renderedHtml = chapterContent
    ? (() => {
        let raw = settings.bionicReading
          ? applyBionicReading(chapterContent.contentHtml)
          : chapterContent.contentHtml;
        const parser = new DOMParser();
        const doc = parser.parseFromString(raw, 'text/html');
        const paragraphs = doc.querySelectorAll('p');
        paragraphs.forEach((p, idx) => {
          p.setAttribute('data-paragraph-idx', idx.toString());
          if (resumedParagraphIdx !== null && idx === resumedParagraphIdx) {
            p.classList.add('resumed-reading-paragraph');
          }
        });
        return doc.body.innerHTML;
      })()
    : '';

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col select-none overflow-hidden transition-colors duration-200 ${
        settings.theme === 'liquid-glass'
          ? settings.glassBlurIntensity === 'low'
            ? 'backdrop-blur-sm'
            : settings.glassBlurIntensity === 'medium'
            ? 'backdrop-blur-md'
            : 'backdrop-blur-xl'
          : ''
      }`}
      style={{
        backgroundColor: themeStyle.bg,
        backgroundImage:
          settings.theme === 'liquid-glass'
            ? 'radial-gradient(circle at 15% 15%, rgba(56, 189, 248, 0.08) 0%, transparent 45%), radial-gradient(circle at 85% 85%, rgba(139, 92, 246, 0.08) 0%, transparent 45%)'
            : undefined,
        color: themeStyle.text,
        fontFamily: settings.fontFamily,
      }}
    >
      {/* Ambient Aura Background Orbs for Liquid Glass & Dark Themes */}
      {settings.ambientAura && (settings.theme === 'liquid-glass' || themeStyle.isGlass) && (
        <>
          <div className="absolute top-10 right-10 w-80 h-80 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none animate-pulse" />
          <div className="absolute bottom-10 left-10 w-80 h-80 rounded-full bg-purple-500/10 blur-3xl pointer-events-none" />
        </>
      )}

      {/* Resumed Position Floating Notification */}
      {showResumeBadge && resumedParagraphIdx !== null && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-40 bg-amber-500 text-neutral-950 font-bold text-xs px-4 py-1.5 rounded-full shadow-2xl flex items-center gap-2 animate-bounce border border-amber-300">
          <span>📍 Resumed at Paragraph {resumedParagraphIdx + 1}</span>
          <button
            onClick={() => setShowResumeBadge(false)}
            className="text-neutral-900 hover:text-black font-black ml-1 text-sm leading-none"
          >
            ×
          </button>
        </div>
      )}

      {/* Brightness Dimmer Overlay */}
      {settings.brightness < 100 && (
        <div
          className="pointer-events-none fixed inset-0 z-40 bg-black transition-opacity"
          style={{ opacity: (100 - settings.brightness) / 100 }}
        />
      )}

      {/* Candlelight Warm Screen Tint Overlay */}
      {settings.warmScreenTint > 0 && (
        <div
          className="pointer-events-none fixed inset-0 z-40 bg-amber-500/80 transition-opacity"
          style={{ opacity: (settings.warmScreenTint * 0.4) / 100, mixBlendMode: 'multiply' }}
        />
      )}

      {/* Reading Ruler Focus Guide Line */}
      {settings.readingRuler && (
        <div
          className="pointer-events-none fixed left-0 right-0 z-35 h-11 border-y border-cyan-400/40 bg-cyan-400/5 transition-all duration-75 shadow-lg shadow-cyan-500/10"
          style={{ top: `${rulerY}%` }}
        />
      )}

      {/* Top Floating App Bar */}
      <header
        className={`fixed top-0 left-0 right-0 z-30 flex items-center justify-between px-4 py-3 border-b transition-all duration-300 ${
          showControls ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0 pointer-events-none'
        } ${settings.lowSpecMode ? '' : 'backdrop-blur-md'}`}
        style={{
          backgroundColor: `${themeStyle.headerBg}ee`,
          borderColor: themeStyle.border,
        }}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-2 rounded-xl transition hover:opacity-80 active:scale-95"
            style={{ backgroundColor: themeStyle.controlBg }}
            title="Back to Bookshelf"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div className="overflow-hidden">
            <h2 className="text-sm font-semibold truncate max-w-[180px] sm:max-w-md">{novel.title}</h2>
            <p className="text-xs truncate opacity-70">
              {novel.chapters[currentChapterIndex]?.title || `Chapter ${currentChapterIndex + 1}`}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* AI Lore & Companion Button */}
          <button
            onClick={handleFetchAiCompanion}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl transition active:scale-95 shadow-sm"
            style={{
              backgroundColor: `${accentHex}20`,
              color: accentHex,
              border: `1px solid ${accentHex}40`,
            }}
            title="AI Character Lore & Recap"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">AI Lore</span>
          </button>

          {/* Fullscreen Toggle */}
          <button
            onClick={toggleFullscreen}
            className="p-2 rounded-xl transition hover:opacity-80 active:scale-95 hidden sm:flex"
            style={{ backgroundColor: themeStyle.controlBg }}
            title="Toggle Fullscreen"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          {/* Bookmark Button */}
          <button
            onClick={handleSaveBookmark}
            className="p-2 rounded-xl transition hover:opacity-80 active:scale-95"
            style={{ backgroundColor: themeStyle.controlBg }}
            title="Bookmark Current Page"
          >
            {bookmarkAdded ? (
              <Check className="w-4 h-4 text-emerald-400" />
            ) : (
              <Bookmark className="w-4 h-4" />
            )}
          </button>

          {/* TTS Button */}
          <button
            onClick={toggleTts}
            className="p-2 rounded-xl transition active:scale-95"
            style={{
              backgroundColor: themeStyle.controlBg,
              color: isTtsPlaying ? accentHex : undefined,
            }}
            title={isTtsPlaying ? 'Stop Text-to-Speech' : 'Listen via Text-to-Speech'}
          >
            {isTtsPlaying ? <Volume2 className="w-4 h-4 animate-pulse" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Table of Contents Button */}
          <button
            onClick={() => setShowToc(true)}
            className="p-2 rounded-xl transition hover:opacity-80 active:scale-95"
            style={{ backgroundColor: themeStyle.controlBg }}
            title="Table of Contents"
          >
            <List className="w-4 h-4" />
          </button>

          {/* Share Novel Link Button */}
          <button
            onClick={handleShareNovel}
            className="p-2 rounded-xl transition hover:opacity-80 active:scale-95"
            style={{ backgroundColor: themeStyle.controlBg }}
            title="Share Novel Link"
          >
            <Share2 className="w-4 h-4" />
          </button>

          {/* Settings Button */}
          <button
            onClick={() => setShowSettingsDrawer(true)}
            className="p-2 rounded-xl transition hover:opacity-80 active:scale-95"
            style={{ backgroundColor: themeStyle.controlBg }}
            title="Typography & NeoQN Customization"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Reading Viewport */}
      <main
        className="relative flex-1 w-full h-full overflow-hidden"
        onMouseMove={(e) => {
          if (settings.readingRuler) {
            const rect = e.currentTarget.getBoundingClientRect();
            const pct = Math.max(5, Math.min(95, ((e.clientY - rect.top) / rect.height) * 100));
            setRulerY(pct);
          }
        }}
        onClick={(e) => {
          const width = window.innerWidth;
          const clickX = e.clientX;
          const mode = settings.tapZoneMode || 'standard';

          let isMenuClick = false;
          let isNextClick = false;
          let isPrevClick = false;

          if (mode === 'edges') {
            if (clickX <= width * 0.15) isPrevClick = true;
            else if (clickX >= width * 0.85) isNextClick = true;
            else isMenuClick = true;
          } else if (mode === 'invert') {
            if (clickX <= width * 0.25) isNextClick = true;
            else if (clickX >= width * 0.75) isPrevClick = true;
            else isMenuClick = true;
          } else {
            // standard
            if (clickX <= width * 0.25) isPrevClick = true;
            else if (clickX >= width * 0.75) isNextClick = true;
            else isMenuClick = true;
          }

          if (isMenuClick) {
            setShowControls(!showControls);
          } else if (settings.readingMode === 'paginated') {
            if (isPrevClick) handlePrevPage();
            else if (isNextClick) handleNextPage();
          }
        }}
      >
        {/* Dynamic Reader Typography & Layout Rules */}
        <style>{`
          .reader-body p {
            margin-bottom: ${settings.paragraphSpacing ?? 1.2}em !important;
            text-align: ${settings.textAlign ?? 'left'} !important;
            ${settings.indentParagraphs ? 'text-indent: 1.8em !important;' : ''}
            ${settings.textAlign === 'justify' ? 'text-justify: inter-word; hyphens: auto;' : ''}
          }
          ${
            settings.dropCaps
              ? `
          .reader-body p:first-of-type::first-letter {
            float: left;
            font-size: 3.2em;
            line-height: 0.82;
            font-weight: 700;
            padding-right: 0.18em;
            padding-top: 0.06em;
            color: ${accentHex};
          }
          `
              : ''
          }
        `}</style>
        {isLoading ? (
          <div className="flex flex-col items-center justify-center h-full gap-3">
            <div
              className="w-8 h-8 border-2 border-t-transparent rounded-full animate-spin"
              style={{ borderColor: accentHex }}
            />
            <p className="text-xs font-mono opacity-60">Preparing chapter text...</p>
          </div>
        ) : error ? (
          <div className="flex flex-col items-center justify-center h-full p-6 text-center max-w-md mx-auto">
            <p className="text-sm text-rose-400 mb-3">{error}</p>
            <button
              onClick={() => loadChapter(currentChapterIndex)}
              className="px-4 py-2 text-xs font-medium rounded-xl border transition active:scale-95"
              style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.controlBg }}
            >
              Retry Loading Chapter
            </button>
          </div>
        ) : (
          <>
            {/* Scroll Mode */}
            {settings.readingMode === 'scroll' ? (
              <div
                ref={scrollContainerRef}
                onScroll={handleScroll}
                className="w-full h-full overflow-y-auto px-5 sm:px-12 md:px-16 py-16 scroll-smooth"
                style={{ WebkitOverflowScrolling: 'touch' }}
              >
                <div
                  className={`mx-auto select-text pb-28 ${
                    settings.twoColumnTablet ? 'md:columns-2 md:gap-12' : ''
                  }`}
                  style={{
                    maxWidth: settings.maxWidth ? `${settings.maxWidth}px` : '100%',
                    fontSize: `${settings.fontSize}px`,
                    fontWeight:
                      settings.fontWeight === 'bold'
                        ? 700
                        : settings.fontWeight === 'medium'
                        ? 500
                        : settings.fontWeight === 'light'
                        ? 300
                        : 400,
                    lineHeight: settings.lineHeight,
                    letterSpacing: `${settings.letterSpacing}px`,
                    textAlign: settings.textAlign,
                  }}
                >
                  <div
                    className="mb-8 pb-4 border-b opacity-60 break-inside-avoid"
                    style={{ borderColor: themeStyle.border }}
                  >
                    <h1 className="text-xl sm:text-2xl font-bold tracking-tight mb-2">
                      {chapterContent?.title}
                    </h1>
                    <div className="text-xs flex gap-3 opacity-75">
                      <span>{novel.title}</span>
                      <span>•</span>
                      <span>{chapterContent?.wordCount} words</span>
                    </div>
                  </div>

                  <div
                    className={`reader-body [&>p]:mb-4 ${
                      settings.indentParagraphs ? '[&>p]:indent-6' : ''
                    } ${
                      settings.dropCaps
                        ? '[&>p:first-of-type]:first-letter:float-left [&>p:first-of-type]:first-letter:text-4xl [&>p:first-of-type]:first-letter:font-bold [&>p:first-of-type]:first-letter:pr-2 [&>p:first-of-type]:first-letter:leading-none'
                        : ''
                    }`}
                    dangerouslySetInnerHTML={{ __html: renderedHtml }}
                  />

                  {/* Chapter End Controls */}
                  <div
                    className="mt-16 pt-8 border-t flex flex-col sm:flex-row items-center justify-between gap-4 break-inside-avoid"
                    style={{ borderColor: themeStyle.border }}
                  >
                    <button
                      disabled={currentChapterIndex === 0}
                      onClick={handlePrevPage}
                      className="w-full sm:w-auto px-5 py-2.5 rounded-xl text-xs font-medium border flex items-center justify-center gap-2 disabled:opacity-30"
                      style={{ backgroundColor: themeStyle.controlBg, borderColor: themeStyle.border }}
                    >
                      <ChevronLeft className="w-4 h-4" /> Previous Chapter
                    </button>
                    <span className="text-xs opacity-60">
                      Chapter {currentChapterIndex + 1} of {novel.chapters.length}
                    </span>
                    <button
                      disabled={currentChapterIndex >= novel.chapters.length - 1}
                      onClick={handleNextPage}
                      className="w-full sm:w-auto px-5 py-2.5 rounded-xl text-xs font-medium border flex items-center justify-center gap-2 disabled:opacity-30"
                      style={{ backgroundColor: themeStyle.controlBg, borderColor: themeStyle.border }}
                    >
                      Next Chapter <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              /* Paginated Mode (Supports 2-column tablet book spread) */
              <div className="relative w-full h-full overflow-hidden px-6 sm:px-14 md:px-20 py-16">
                <div
                  ref={contentContainerRef}
                  className="w-full h-full mx-auto select-text"
                  style={{
                    maxWidth: settings.maxWidth ? `${settings.maxWidth}px` : '100%',
                    fontSize: `${settings.fontSize}px`,
                    fontWeight:
                      settings.fontWeight === 'bold'
                        ? 700
                        : settings.fontWeight === 'medium'
                        ? 500
                        : settings.fontWeight === 'light'
                        ? 300
                        : 400,
                    lineHeight: settings.lineHeight,
                    letterSpacing: `${settings.letterSpacing}px`,
                    textAlign: settings.textAlign,
                    columnFill: 'auto',
                    columnWidth: settings.twoColumnTablet && window.innerWidth >= 768 ? '45%' : '100%',
                    columnGap: '60px',
                    height: '100%',
                    transform: `translateX(-${currentPage * 100}%)`,
                    transition:
                      settings.pageTransition === 'slide' && !settings.lowSpecMode
                        ? 'transform 280ms cubic-bezier(0.16, 1, 0.3, 1)'
                        : settings.pageTransition === 'fade' && !settings.lowSpecMode
                        ? 'opacity 200ms ease'
                        : 'none',
                    willChange: 'transform',
                  }}
                >
                  <h1 className="text-xl sm:text-2xl font-bold tracking-tight mb-4 break-inside-avoid">
                    {chapterContent?.title}
                  </h1>
                  <div
                    className={`reader-body [&>p]:mb-4 ${
                      settings.indentParagraphs ? '[&>p]:indent-6' : ''
                    } ${
                      settings.dropCaps
                        ? '[&>p:first-of-type]:first-letter:float-left [&>p:first-of-type]:first-letter:text-4xl [&>p:first-of-type]:first-letter:font-bold [&>p:first-of-type]:first-letter:pr-2 [&>p:first-of-type]:first-letter:leading-none'
                        : ''
                    }`}
                    dangerouslySetInnerHTML={{ __html: renderedHtml }}
                  />
                </div>
              </div>
            )}
          </>
        )}
      </main>

      {/* Reader Footer Bar */}
      <footer
        className={`fixed bottom-0 left-0 right-0 z-30 px-4 py-2.5 border-t transition-all duration-300 flex flex-col gap-2 ${
          showControls ? 'translate-y-0 opacity-100' : 'translate-y-full opacity-0 pointer-events-none'
        } ${settings.lowSpecMode ? '' : 'backdrop-blur-md'}`}
        style={{
          backgroundColor: `${themeStyle.headerBg}ee`,
          borderColor: themeStyle.border,
        }}
      >
        {/* Progress Slider */}
        <div className="flex items-center gap-3 max-w-xl mx-auto w-full">
          <button
            onClick={handlePrevPage}
            disabled={currentChapterIndex === 0 && currentPage === 0}
            className="p-1.5 rounded-lg transition active:scale-95 disabled:opacity-30"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <div className="flex-1 flex flex-col gap-1">
            <div className="flex justify-between text-[11px] opacity-70">
              <span className="truncate max-w-[140px] sm:max-w-xs">
                {novel.chapters[currentChapterIndex]?.title}
              </span>
              <span>
                {settings.readingMode === 'paginated'
                  ? `Page ${currentPage + 1} / ${totalPages}`
                  : `Ch ${currentChapterIndex + 1} / ${novel.chapters.length}`}
              </span>
            </div>
            <div className="w-full bg-neutral-800/40 rounded-full h-1.5 overflow-hidden">
              <div
                className="h-full transition-all duration-200"
                style={{
                  width: `${
                    settings.readingMode === 'paginated' && totalPages > 1
                      ? ((currentPage + 1) / totalPages) * 100
                      : ((currentChapterIndex + 1) / novel.chapters.length) * 100
                  }%`,
                  backgroundColor: accentHex,
                }}
              />
            </div>
          </div>

          <button
            onClick={handleNextPage}
            disabled={
              currentChapterIndex >= novel.chapters.length - 1 &&
              currentPage >= totalPages - 1
            }
            className="p-1.5 rounded-lg transition active:scale-95 disabled:opacity-30"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Footer Toggles */}
        <div className="flex flex-wrap items-center justify-center gap-1.5 sm:gap-2.5 text-xs opacity-90">
          {/* Chapter List Shortcut */}
          <button
            onClick={() => setShowToc(true)}
            className="px-2.5 py-1 rounded-lg text-[11px] border flex items-center gap-1.5 transition active:scale-95"
            style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.controlBg }}
            title="Open Chapter List"
          >
            <List className="w-3.5 h-3.5" />
            <span>Ch {currentChapterIndex + 1}/{novel.chapters.length}</span>
          </button>

          {/* Quick Font Size Stepper */}
          <div
            className="flex items-center rounded-lg border overflow-hidden text-[11px]"
            style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.controlBg }}
          >
            <button
              onClick={() => onUpdateSettings({ ...settings, fontSize: Math.max(13, settings.fontSize - 1) })}
              className="px-2 py-1 hover:opacity-80 transition font-bold"
              title="Decrease Font Size"
            >
              A-
            </button>
            <span className="px-1.5 py-1 font-mono text-[10px] opacity-75 border-x" style={{ borderColor: themeStyle.border }}>
              {settings.fontSize}px
            </span>
            <button
              onClick={() => onUpdateSettings({ ...settings, fontSize: Math.min(38, settings.fontSize + 1) })}
              className="px-2 py-1 hover:opacity-80 transition font-bold"
              title="Increase Font Size"
            >
              A+
            </button>
          </div>

          {/* Quick Paragraph Spacing Stepper */}
          <div
            className="flex items-center rounded-lg border overflow-hidden text-[11px]"
            style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.controlBg }}
          >
            <button
              onClick={() => onUpdateSettings({ ...settings, paragraphSpacing: Math.max(0.5, Math.round(((settings.paragraphSpacing ?? 1.2) - 0.2) * 10) / 10) })}
              className="px-2 py-1 hover:opacity-80 transition font-bold"
              title="Decrease Paragraph Spacing"
            >
              ¶-
            </button>
            <span className="px-1.5 py-1 font-mono text-[10px] opacity-75 border-x" style={{ borderColor: themeStyle.border }}>
              {settings.paragraphSpacing ?? 1.2}em
            </span>
            <button
              onClick={() => onUpdateSettings({ ...settings, paragraphSpacing: Math.min(2.5, Math.round(((settings.paragraphSpacing ?? 1.2) + 0.2) * 10) / 10) })}
              className="px-2 py-1 hover:opacity-80 transition font-bold"
              title="Increase Paragraph Spacing"
            >
              ¶+
            </button>
          </div>

          {/* Scroll vs Paginated Toggle */}
          <button
            onClick={() =>
              onUpdateSettings({
                ...settings,
                readingMode: settings.readingMode === 'paginated' ? 'scroll' : 'paginated',
              })
            }
            className="px-2.5 py-1 rounded-lg text-[11px] border flex items-center gap-1.5 transition active:scale-95"
            style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.controlBg }}
          >
            {settings.readingMode === 'paginated' ? '📖 Flip' : '📜 Scroll'}
          </button>

          {/* Full Customization Drawer Shortcut */}
          <button
            onClick={() => setShowSettingsDrawer(true)}
            className="px-2.5 py-1 rounded-lg text-[11px] border flex items-center gap-1.5 transition active:scale-95 font-semibold"
            style={{
              borderColor: accentHex,
              backgroundColor: `${accentHex}18`,
              color: accentHex,
            }}
            title="Open all reader customization options"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Customize</span>
          </button>
        </div>
      </footer>

      {/* Table of Contents Drawer */}
      {showToc && (() => {
        const query = tocSearchQuery.trim().toLowerCase();
        const indexedChapters = novel.chapters.map((ch, idx) => ({ ch, originalIndex: idx }));
        const filtered = query
          ? indexedChapters.filter(
              (item) =>
                item.ch.title.toLowerCase().includes(query) ||
                `chapter ${item.originalIndex + 1}`.includes(query) ||
                `ch ${item.originalIndex + 1}`.includes(query) ||
                `${item.originalIndex + 1}` === query
            )
          : indexedChapters;
        const displayList = tocSortAsc ? filtered : [...filtered].reverse();

        return (
          <div className="fixed inset-0 z-50 flex">
            <div
              className="fixed inset-0 bg-black/60 transition-opacity backdrop-blur-xs"
              onClick={() => setShowToc(false)}
            />
            <div
              className="relative z-10 w-full max-w-sm sm:max-w-md h-full flex flex-col border-r shadow-2xl"
              style={{
                backgroundColor: themeStyle.bg,
                borderColor: themeStyle.border,
              }}
            >
              {/* Drawer Header */}
              <div className="p-4 border-b flex items-center justify-between gap-3" style={{ borderColor: themeStyle.border }}>
                <div>
                  <div className="flex items-center gap-2">
                    <List className="w-4 h-4" style={{ color: accentHex }} />
                    <h3 className="font-bold text-sm">Table of Contents</h3>
                  </div>
                  <p className="text-xs opacity-60 mt-0.5">
                    {novel.chapters.length} chapters · Current: Ch {currentChapterIndex + 1}
                  </p>
                </div>
                <button
                  onClick={() => setShowToc(false)}
                  className="p-1.5 rounded-xl hover:opacity-80 transition"
                  style={{ backgroundColor: themeStyle.controlBg }}
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Search & Fast Navigation Actions */}
              <div className="p-3 border-b flex flex-col gap-2.5" style={{ borderColor: themeStyle.border, backgroundColor: `${themeStyle.controlBg}50` }}>
                {/* Search Bar */}
                <div className="relative flex items-center">
                  <Search className="w-3.5 h-3.5 absolute left-3 opacity-50 pointer-events-none" />
                  <input
                    type="text"
                    value={tocSearchQuery}
                    onChange={(e) => setTocSearchQuery(e.target.value)}
                    placeholder="Search chapter title or #..."
                    className="w-full pl-9 pr-8 py-1.5 text-xs rounded-xl border focus:outline-hidden"
                    style={{
                      backgroundColor: themeStyle.controlBg,
                      borderColor: themeStyle.border,
                      color: themeStyle.text,
                    }}
                  />
                  {tocSearchQuery && (
                    <button
                      onClick={() => setTocSearchQuery('')}
                      className="absolute right-2.5 p-0.5 rounded text-xs opacity-60 hover:opacity-100"
                    >
                      ×
                    </button>
                  )}
                </div>

                {/* Quick Jumps & Sort Order */}
                <div className="flex items-center justify-between gap-2 text-[11px]">
                  <button
                    onClick={() => setTocSortAsc(!tocSortAsc)}
                    className="px-2 py-1 rounded-lg border flex items-center gap-1 opacity-80 hover:opacity-100 transition"
                    style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.controlBg }}
                    title="Toggle Sort Order"
                  >
                    <ArrowUpDown className="w-3 h-3" />
                    <span>{tocSortAsc ? '1 → N' : 'N → 1'}</span>
                  </button>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => {
                        loadChapter(0);
                        setShowToc(false);
                      }}
                      className="px-2 py-1 rounded-lg border opacity-80 hover:opacity-100 transition"
                      style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.controlBg }}
                      title="Jump to First Chapter"
                    >
                      First
                    </button>
                    <button
                      onClick={() => {
                        loadChapter(currentChapterIndex);
                        setShowToc(false);
                      }}
                      className="px-2 py-1 rounded-lg border font-semibold transition"
                      style={{
                        borderColor: accentHex,
                        backgroundColor: `${accentHex}20`,
                        color: accentHex,
                      }}
                      title="Jump to Currently Active Chapter"
                    >
                      Active (Ch {currentChapterIndex + 1})
                    </button>
                    <button
                      onClick={() => {
                        loadChapter(novel.chapters.length - 1);
                        setShowToc(false);
                      }}
                      className="px-2 py-1 rounded-lg border opacity-80 hover:opacity-100 transition"
                      style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.controlBg }}
                      title="Jump to Latest Chapter"
                    >
                      Latest
                    </button>
                  </div>
                </div>
              </div>

              {/* Chapter Items List */}
              <div className="flex-1 overflow-y-auto p-2 divide-y" style={{ borderColor: themeStyle.border }}>
                {displayList.length === 0 ? (
                  <div className="py-12 text-center text-xs opacity-60">
                    No chapters matching "{tocSearchQuery}"
                  </div>
                ) : (
                  displayList.map(({ ch, originalIndex }) => {
                    const isCurrent = originalIndex === currentChapterIndex;
                    const isRead = originalIndex < currentChapterIndex;
                    return (
                      <button
                        key={ch.id || originalIndex}
                        onClick={() => {
                          loadChapter(originalIndex);
                          setShowToc(false);
                        }}
                        className={`w-full text-left p-2.5 rounded-xl text-xs transition flex items-center justify-between gap-3 ${
                          isCurrent
                            ? 'font-bold ring-1'
                            : 'opacity-85 hover:opacity-100 hover:bg-white/5'
                        }`}
                        style={{
                          backgroundColor: isCurrent ? `${accentHex}18` : 'transparent',
                          borderColor: isCurrent ? accentHex : undefined,
                          color: isCurrent ? accentHex : undefined,
                        }}
                      >
                        <div className="flex items-center gap-2.5 overflow-hidden flex-1">
                          <span
                            className={`text-[10px] font-mono px-1.5 py-0.5 rounded flex-shrink-0 ${
                              isCurrent ? 'font-bold' : 'opacity-60'
                            }`}
                            style={{
                              backgroundColor: isCurrent ? `${accentHex}30` : themeStyle.controlBg,
                            }}
                          >
                            #{originalIndex + 1}
                          </span>
                          <div className="truncate">
                            <span className="block truncate font-medium">{ch.title}</span>
                            <span className="text-[10px] opacity-50 block truncate">
                              {ch.wordCount ? `${ch.wordCount.toLocaleString()} words` : 'Full chapter text'}
                              {ch.isDownloaded && ' · Offline ready'}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 flex-shrink-0 text-[10px]">
                          {isCurrent ? (
                            <span className="px-1.5 py-0.5 rounded font-bold uppercase tracking-wider text-[9px] bg-amber-500/20 text-amber-300">
                              Reading
                            </span>
                          ) : isRead ? (
                            <span className="opacity-50 flex items-center gap-0.5">
                              <Check className="w-3 h-3 text-emerald-400" />
                              <span>Read</span>
                            </span>
                          ) : null}
                          {ch.isDownloaded && (
                            <span title="Downloaded offline">
                              <Download className="w-3 h-3 opacity-60 text-emerald-400" />
                            </span>
                          )}
                        </div>
                      </button>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        );
      })()}

      {/* Reader Customization Drawer */}
      {showSettingsDrawer && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div
            className="fixed inset-0 bg-black/60 transition-opacity backdrop-blur-xs"
            onClick={() => setShowSettingsDrawer(false)}
          />
          <div
            className="relative z-10 w-full max-w-lg h-full flex flex-col border-l shadow-2xl overflow-y-auto p-5 sm:p-6"
            style={{
              backgroundColor: themeStyle.bg,
              borderColor: themeStyle.border,
            }}
          >
            {/* Drawer Header */}
            <div className="flex items-center justify-between pb-4 border-b mb-5" style={{ borderColor: themeStyle.border }}>
              <div className="flex items-center gap-2">
                <Palette className="w-5 h-5" style={{ color: accentHex }} />
                <div>
                  <h3 className="font-bold text-sm">Reader Customization</h3>
                  <p className="text-[11px] opacity-60">Typography, Spacing, Layout & Themes</p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    onUpdateSettings(DEFAULT_SETTINGS);
                    setSettingsResetSuccess(true);
                    setTimeout(() => setSettingsResetSuccess(false), 2500);
                  }}
                  className="px-2.5 py-1 rounded-lg text-[11px] border opacity-80 hover:opacity-100 flex items-center gap-1 transition"
                  style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.controlBg }}
                  title="Reset to default typography & layout"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset</span>
                </button>
                <button
                  onClick={() => setShowSettingsDrawer(false)}
                  className="p-1.5 rounded-lg hover:opacity-80 transition"
                  style={{ backgroundColor: themeStyle.controlBg }}
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {settingsResetSuccess && (
              <div className="mb-4 p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                <Check className="w-4 h-4" />
                <span>Reader typography and layout reset to defaults!</span>
              </div>
            )}

            {/* Quick Live Preview Snippet */}
            <div
              className="p-4 rounded-2xl border mb-6 transition"
              style={{
                backgroundColor: themeStyle.controlBg,
                borderColor: themeStyle.border,
                fontFamily: settings.fontFamily,
              }}
            >
              <div className="flex justify-between text-[10px] opacity-60 uppercase tracking-wider mb-2 font-mono">
                <span>Preview · {settings.fontFamily}</span>
                <span>{settings.fontSize}px · Spacing {settings.paragraphSpacing ?? 1.2}em</span>
              </div>
              <div
                style={{
                  fontSize: `${settings.fontSize}px`,
                  lineHeight: settings.lineHeight,
                  letterSpacing: `${settings.letterSpacing}px`,
                  textAlign: settings.textAlign,
                  fontWeight:
                    settings.fontWeight === 'bold'
                      ? 700
                      : settings.fontWeight === 'medium'
                      ? 500
                      : settings.fontWeight === 'light'
                      ? 300
                      : 400,
                }}
              >
                <p
                  style={{
                    marginBottom: `${settings.paragraphSpacing ?? 1.2}em`,
                    textIndent: settings.indentParagraphs ? '1.8em' : '0',
                  }}
                >
                  {settings.dropCaps && (
                    <span
                      className="float-left text-3xl font-bold mr-1.5 leading-none"
                      style={{ color: accentHex }}
                    >
                      T
                    </span>
                  )}
                  he silver stars aligned across the horizon, whispering ancient tales to those who listened closely in the quiet night.
                </p>
                <p
                  style={{
                    marginBottom: `${settings.paragraphSpacing ?? 1.2}em`,
                    textIndent: settings.indentParagraphs ? '1.8em' : '0',
                  }}
                >
                  Every written line resonates with clarity and intentional design.
                </p>
              </div>
            </div>

            {/* ================= SECTION 1: TYPOGRAPHY & SPACING ================= */}
            <div className="mb-6 space-y-5">
              <div className="flex items-center gap-2 pb-2 border-b" style={{ borderColor: themeStyle.border }}>
                <Type className="w-4 h-4" style={{ color: accentHex }} />
                <h4 className="text-xs font-bold uppercase tracking-wider opacity-80">
                  Typography & Paragraph Spacing
                </h4>
              </div>

              {/* 1. Paragraph Spacing (User requested explicitly) */}
              <div className="p-3.5 rounded-xl border" style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.controlBg }}>
                <div className="flex justify-between items-center text-xs mb-2">
                  <span className="font-semibold">Paragraph Spacing</span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() =>
                        onUpdateSettings({
                          ...settings,
                          paragraphSpacing: Math.max(0.5, Math.round(((settings.paragraphSpacing ?? 1.2) - 0.1) * 10) / 10),
                        })
                      }
                      className="w-6 h-6 rounded-md border flex items-center justify-center font-bold text-xs"
                      style={{ borderColor: themeStyle.border }}
                    >
                      -
                    </button>
                    <span className="font-mono font-bold w-14 text-center" style={{ color: accentHex }}>
                      {settings.paragraphSpacing ?? 1.2}em
                    </span>
                    <button
                      onClick={() =>
                        onUpdateSettings({
                          ...settings,
                          paragraphSpacing: Math.min(2.5, Math.round(((settings.paragraphSpacing ?? 1.2) + 0.1) * 10) / 10),
                        })
                      }
                      className="w-6 h-6 rounded-md border flex items-center justify-center font-bold text-xs"
                      style={{ borderColor: themeStyle.border }}
                    >
                      +
                    </button>
                  </div>
                </div>

                <input
                  type="range"
                  min="0.5"
                  max="2.5"
                  step="0.1"
                  value={settings.paragraphSpacing ?? 1.2}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, paragraphSpacing: parseFloat(e.target.value) })
                  }
                  className="w-full accent-amber-500 cursor-pointer"
                />

                {/* Spacing Presets */}
                <div className="grid grid-cols-4 gap-1.5 mt-2.5">
                  {[
                    { label: 'Tight', val: 0.8 },
                    { label: 'Normal', val: 1.2 },
                    { label: 'Relaxed', val: 1.6 },
                    { label: 'Spaced', val: 2.0 },
                  ].map((p) => (
                    <button
                      key={p.label}
                      onClick={() => onUpdateSettings({ ...settings, paragraphSpacing: p.val })}
                      className={`py-1 rounded-lg text-[10px] border transition font-medium ${
                        Math.abs((settings.paragraphSpacing ?? 1.2) - p.val) < 0.05
                          ? 'font-bold'
                          : 'opacity-70 hover:opacity-100'
                      }`}
                      style={{
                        borderColor:
                          Math.abs((settings.paragraphSpacing ?? 1.2) - p.val) < 0.05
                            ? accentHex
                            : themeStyle.border,
                        backgroundColor:
                          Math.abs((settings.paragraphSpacing ?? 1.2) - p.val) < 0.05
                            ? `${accentHex}20`
                            : 'transparent',
                        color:
                          Math.abs((settings.paragraphSpacing ?? 1.2) - p.val) < 0.05
                            ? accentHex
                            : undefined,
                      }}
                    >
                      {p.label} ({p.val}em)
                    </button>
                  ))}
                </div>
              </div>

              {/* 2. Font Size (User requested explicitly) */}
              <div className="p-3.5 rounded-xl border" style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.controlBg }}>
                <div className="flex justify-between items-center text-xs mb-2">
                  <span className="font-semibold">Font Size</span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() =>
                        onUpdateSettings({ ...settings, fontSize: Math.max(13, settings.fontSize - 1) })
                      }
                      className="w-6 h-6 rounded-md border flex items-center justify-center font-bold text-xs"
                      style={{ borderColor: themeStyle.border }}
                    >
                      -
                    </button>
                    <span className="font-mono font-bold w-14 text-center" style={{ color: accentHex }}>
                      {settings.fontSize}px
                    </span>
                    <button
                      onClick={() =>
                        onUpdateSettings({ ...settings, fontSize: Math.min(38, settings.fontSize + 1) })
                      }
                      className="w-6 h-6 rounded-md border flex items-center justify-center font-bold text-xs"
                      style={{ borderColor: themeStyle.border }}
                    >
                      +
                    </button>
                  </div>
                </div>

                <input
                  type="range"
                  min="13"
                  max="38"
                  step="1"
                  value={settings.fontSize}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, fontSize: parseInt(e.target.value, 10) })
                  }
                  className="w-full accent-amber-500 cursor-pointer"
                />

                {/* Font Size Presets */}
                <div className="grid grid-cols-4 gap-1.5 mt-2.5">
                  {[
                    { label: 'Compact', val: 15 },
                    { label: 'Default', val: 18 },
                    { label: 'Large', val: 22 },
                    { label: 'Spacious', val: 26 },
                  ].map((p) => (
                    <button
                      key={p.label}
                      onClick={() => onUpdateSettings({ ...settings, fontSize: p.val })}
                      className={`py-1 rounded-lg text-[10px] border transition font-medium ${
                        settings.fontSize === p.val ? 'font-bold' : 'opacity-70 hover:opacity-100'
                      }`}
                      style={{
                        borderColor: settings.fontSize === p.val ? accentHex : themeStyle.border,
                        backgroundColor: settings.fontSize === p.val ? `${accentHex}20` : 'transparent',
                        color: settings.fontSize === p.val ? accentHex : undefined,
                      }}
                    >
                      {p.label} ({p.val}px)
                    </button>
                  ))}
                </div>
              </div>

              {/* 3. Line Height & Letter Spacing */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 rounded-xl border" style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.controlBg }}>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="font-semibold">Line Height</span>
                    <span className="font-mono font-bold" style={{ color: accentHex }}>{settings.lineHeight}x</span>
                  </div>
                  <input
                    type="range"
                    min="1.2"
                    max="2.6"
                    step="0.1"
                    value={settings.lineHeight}
                    onChange={(e) =>
                      onUpdateSettings({ ...settings, lineHeight: parseFloat(e.target.value) })
                    }
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] opacity-60 mt-1">
                    <span>1.2x (Tight)</span>
                    <span>2.6x (Loose)</span>
                  </div>
                </div>

                <div className="p-3 rounded-xl border" style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.controlBg }}>
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="font-semibold">Letter Spacing</span>
                    <span className="font-mono font-bold" style={{ color: accentHex }}>{settings.letterSpacing}px</span>
                  </div>
                  <input
                    type="range"
                    min="-0.5"
                    max="3"
                    step="0.2"
                    value={settings.letterSpacing}
                    onChange={(e) =>
                      onUpdateSettings({ ...settings, letterSpacing: parseFloat(e.target.value) })
                    }
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] opacity-60 mt-1">
                    <span>-0.5px</span>
                    <span>+3.0px</span>
                  </div>
                </div>
              </div>

              {/* 4. Font Weight & Text Alignment */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold block mb-1.5 opacity-70">
                    Font Weight
                  </label>
                  <div className="grid grid-cols-4 gap-1">
                    {(['light', 'normal', 'medium', 'bold'] as const).map((w) => (
                      <button
                        key={w}
                        onClick={() => onUpdateSettings({ ...settings, fontWeight: w })}
                        className={`py-1.5 rounded-lg text-xs capitalize border transition ${
                          settings.fontWeight === w ? 'font-bold' : 'opacity-70 hover:opacity-100'
                        }`}
                        style={{
                          borderColor: settings.fontWeight === w ? accentHex : themeStyle.border,
                          backgroundColor: settings.fontWeight === w ? `${accentHex}20` : themeStyle.controlBg,
                          color: settings.fontWeight === w ? accentHex : undefined,
                        }}
                      >
                        {w}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-semibold block mb-1.5 opacity-70">
                    Text Alignment
                  </label>
                  <div className="grid grid-cols-3 gap-1">
                    {[
                      { id: 'left', label: 'Left', icon: AlignLeft },
                      { id: 'justify', label: 'Justify', icon: AlignJustify },
                      { id: 'center', label: 'Center', icon: AlignCenter },
                    ].map((align) => {
                      const Icon = align.icon;
                      const isSel = settings.textAlign === align.id;
                      return (
                        <button
                          key={align.id}
                          onClick={() => onUpdateSettings({ ...settings, textAlign: align.id as any })}
                          className={`py-1.5 rounded-lg text-xs border flex items-center justify-center gap-1 transition ${
                            isSel ? 'font-bold' : 'opacity-70 hover:opacity-100'
                          }`}
                          style={{
                            borderColor: isSel ? accentHex : themeStyle.border,
                            backgroundColor: isSel ? `${accentHex}20` : themeStyle.controlBg,
                            color: isSel ? accentHex : undefined,
                          }}
                        >
                          <Icon className="w-3 h-3" />
                          <span>{align.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* 5. Book Typeface Selection */}
              <div>
                <label className="text-[11px] font-semibold uppercase tracking-wider block mb-2 opacity-70">
                  Book Typeface ({settings.fontFamily})
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { key: 'Literata', label: 'Literata', type: 'Serif' },
                    { key: 'Lora', label: 'Lora', type: 'Editorial' },
                    { key: 'Merriweather', label: 'Merriweather', type: 'Classic' },
                    { key: 'Inter', label: 'Inter', type: 'Clean' },
                    { key: 'JetBrains Mono', label: 'JetBrains', type: 'Mono' },
                    { key: 'Cinzel', label: 'Cinzel', type: 'Epic' },
                    { key: 'Atkinson', label: 'Atkinson', type: 'Low-Strain' },
                    { key: 'system-ui', label: 'System UI', type: 'Fast' },
                  ].map((f) => (
                    <button
                      key={f.key}
                      onClick={() => onUpdateSettings({ ...settings, fontFamily: f.key as ReaderFont })}
                      className={`p-2 rounded-xl border text-left text-xs transition ${
                        settings.fontFamily === f.key ? 'font-bold ring-1' : 'opacity-75 hover:opacity-100'
                      }`}
                      style={{
                        fontFamily: f.key,
                        borderColor: settings.fontFamily === f.key ? accentHex : themeStyle.border,
                        backgroundColor: themeStyle.controlBg,
                        color: settings.fontFamily === f.key ? accentHex : undefined,
                      }}
                    >
                      <div className="flex items-center justify-between">
                        <span className="truncate">{f.label}</span>
                        {settings.fontFamily === f.key && <Check className="w-3 h-3 flex-shrink-0" />}
                      </div>
                      <span className="text-[9px] opacity-60 block mt-0.5">{f.type}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* 6. Column Max Width & Editorial Toggles */}
              <div className="p-3.5 rounded-xl border space-y-3" style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.controlBg }}>
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold">Reading Column Width</span>
                  <span className="font-mono font-bold" style={{ color: accentHex }}>
                    {settings.maxWidth === 0 ? 'Full Screen' : `${settings.maxWidth}px`}
                  </span>
                </div>
                <input
                  type="range"
                  min="540"
                  max="1300"
                  step="20"
                  value={settings.maxWidth || 780}
                  onChange={(e) =>
                    onUpdateSettings({ ...settings, maxWidth: parseInt(e.target.value, 10) })
                  }
                  className="w-full accent-amber-500 cursor-pointer"
                />

                <div className="grid grid-cols-4 gap-1.5">
                  {[
                    { label: 'Narrow', val: 640 },
                    { label: 'Standard', val: 780 },
                    { label: 'Wide', val: 960 },
                    { label: 'Full', val: 0 },
                  ].map((cw) => (
                    <button
                      key={cw.label}
                      onClick={() => onUpdateSettings({ ...settings, maxWidth: cw.val })}
                      className={`py-1 rounded-lg text-[10px] border transition ${
                        settings.maxWidth === cw.val ? 'font-bold' : 'opacity-70 hover:opacity-100'
                      }`}
                      style={{
                        borderColor: settings.maxWidth === cw.val ? accentHex : themeStyle.border,
                        backgroundColor: settings.maxWidth === cw.val ? `${accentHex}20` : 'transparent',
                        color: settings.maxWidth === cw.val ? accentHex : undefined,
                      }}
                    >
                      {cw.label}
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t" style={{ borderColor: themeStyle.border }}>
                  <label className="flex items-center justify-between p-2 rounded-lg border cursor-pointer" style={{ borderColor: themeStyle.border }}>
                    <div>
                      <span className="text-xs font-semibold block">Paragraph Indent</span>
                      <span className="text-[10px] opacity-60">Traditional novel indent</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.indentParagraphs}
                      onChange={(e) => onUpdateSettings({ ...settings, indentParagraphs: e.target.checked })}
                      className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
                    />
                  </label>

                  <label className="flex items-center justify-between p-2 rounded-lg border cursor-pointer" style={{ borderColor: themeStyle.border }}>
                    <div>
                      <span className="text-xs font-semibold block">Classic Drop Caps</span>
                      <span className="text-[10px] opacity-60">Enlarged initial letter</span>
                    </div>
                    <input
                      type="checkbox"
                      checked={settings.dropCaps}
                      onChange={(e) => onUpdateSettings({ ...settings, dropCaps: e.target.checked })}
                      className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
                    />
                  </label>
                </div>
              </div>
            </div>

            {/* ================= SECTION 2: READING ENGINE & FLOW ================= */}
            <div className="mb-6 space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b" style={{ borderColor: themeStyle.border }}>
                <BookOpen className="w-4 h-4" style={{ color: accentHex }} />
                <h4 className="text-xs font-bold uppercase tracking-wider opacity-80">
                  Reading Flow & Mode
                </h4>
              </div>

              <div className="grid grid-cols-2 gap-2">
                {[
                  { id: 'scroll', label: 'Continuous Scroll', icon: '📜' },
                  { id: 'paginated', label: 'Paginated Book', icon: '📖' },
                ].map((m) => (
                  <button
                    key={m.id}
                    onClick={() => onUpdateSettings({ ...settings, readingMode: m.id as any })}
                    className={`p-3 rounded-xl border text-left text-xs transition ${
                      settings.readingMode === m.id ? 'font-bold' : 'opacity-70 hover:opacity-100'
                    }`}
                    style={{
                      borderColor: settings.readingMode === m.id ? accentHex : themeStyle.border,
                      backgroundColor: settings.readingMode === m.id ? `${accentHex}18` : themeStyle.controlBg,
                      color: settings.readingMode === m.id ? accentHex : undefined,
                    }}
                  >
                    <span className="text-base block mb-1">{m.icon}</span>
                    <span>{m.label}</span>
                  </button>
                ))}
              </div>

              {settings.readingMode === 'paginated' && (
                <div>
                  <label className="text-[11px] font-semibold block mb-1.5 opacity-70">
                    Page Flip Transition
                  </label>
                  <div className="grid grid-cols-4 gap-1.5">
                    {[
                      { id: 'slide', label: 'Slide' },
                      { id: 'curl', label: '3D Curl' },
                      { id: 'fade', label: 'Fade' },
                      { id: 'instant', label: 'Instant' },
                    ].map((tr) => (
                      <button
                        key={tr.id}
                        onClick={() => onUpdateSettings({ ...settings, pageTransition: tr.id as any })}
                        className={`py-1.5 rounded-lg text-xs border transition ${
                          settings.pageTransition === tr.id ? 'font-bold' : 'opacity-70 hover:opacity-100'
                        }`}
                        style={{
                          borderColor: settings.pageTransition === tr.id ? accentHex : themeStyle.border,
                          backgroundColor: settings.pageTransition === tr.id ? `${accentHex}20` : themeStyle.controlBg,
                          color: settings.pageTransition === tr.id ? accentHex : undefined,
                        }}
                      >
                        {tr.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Tablet 2-Column Spread & Bionic Reading */}
              <div className="space-y-2">
                <label className="flex items-center justify-between p-3 rounded-xl border cursor-pointer" style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.controlBg }}>
                  <div>
                    <span className="text-xs font-semibold block">Tablet 2-Page Book Spread</span>
                    <span className="text-[10px] opacity-60">Dual-column book layout on wide screens</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.twoColumnTablet}
                    onChange={(e) => onUpdateSettings({ ...settings, twoColumnTablet: e.target.checked })}
                    className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
                  />
                </label>

                <label className="flex items-center justify-between p-3 rounded-xl border cursor-pointer" style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.controlBg }}>
                  <div>
                    <span className="text-xs font-semibold block"><b>Bio</b>nic Speed Reading</span>
                    <span className="text-[10px] opacity-60">Bold artificial fixation points for fast scanning</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.bionicReading}
                    onChange={(e) => onUpdateSettings({ ...settings, bionicReading: e.target.checked })}
                    className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
                  />
                </label>
              </div>
            </div>

            {/* ================= SECTION 3: THEMES & EYE COMFORT ================= */}
            <div className="mb-6 space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b" style={{ borderColor: themeStyle.border }}>
                <Eye className="w-4 h-4" style={{ color: accentHex }} />
                <h4 className="text-xs font-bold uppercase tracking-wider opacity-80">
                  Palette, Glow & Eye Comfort
                </h4>
              </div>

              {/* Accent Color Picker */}
              <div>
                <label className="text-[11px] font-semibold uppercase tracking-wider block mb-2 opacity-70">
                  Accent Glow Color
                </label>
                <div className="flex items-center gap-2 flex-wrap">
                  {(
                    [
                      { key: 'cyan', label: 'Cyan', color: '#06b6d4' },
                      { key: 'amber', label: 'Amber', color: '#f59e0b' },
                      { key: 'emerald', label: 'Emerald', color: '#10b981' },
                      { key: 'violet', label: 'Violet', color: '#8b5cf6' },
                      { key: 'rose', label: 'Rose', color: '#f43f5e' },
                      { key: 'orange', label: 'Orange', color: '#f97316' },
                      { key: 'neon-pink', label: 'Pink', color: '#ec4899' },
                      { key: 'lime-gold', label: 'Lime', color: '#84cc16' },
                    ] as const
                  ).map((a) => (
                    <button
                      key={a.key}
                      onClick={() => onUpdateSettings({ ...settings, accentColor: a.key })}
                      className={`w-7 h-7 rounded-full flex items-center justify-center transition ${
                        settings.accentColor === a.key ? 'ring-2 ring-white scale-110 shadow-sm' : 'opacity-70 hover:opacity-100'
                      }`}
                      style={{ backgroundColor: a.color }}
                      title={a.label}
                    >
                      {settings.accentColor === a.key && <Check className="w-3.5 h-3.5 text-neutral-950 stroke-[3]" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Reader Theme Presets */}
              <div>
                <label className="text-[11px] font-semibold uppercase tracking-wider block mb-2 opacity-70">
                  Color Theme Presets
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {(
                    [
                      { key: 'liquid-glass', label: 'Liquid Glass', preview: 'rgba(12, 16, 28, 0.85)', textCol: '#38bdf8' },
                      { key: 'oled', label: 'OLED Black', preview: '#000000', textCol: '#fff' },
                      { key: 'dark', label: 'Charcoal', preview: '#14161b', textCol: '#eee' },
                      { key: 'midnight', label: 'Midnight', preview: '#0a0f1d', textCol: '#ccd' },
                      { key: 'nordic', label: 'Nordic Slate', preview: '#181e29', textCol: '#e2e8f0' },
                      { key: 'cyberpunk', label: 'Cyberpunk', preview: '#080811', textCol: '#38bdf8' },
                      { key: 'crimson-void', label: 'Crimson Void', preview: '#0e0507', textCol: '#fecdd3' },
                      { key: 'mocha', label: 'Mocha Coffee', preview: '#1c1715', textCol: '#ebdcd3' },
                      { key: 'rose', label: 'Dark Velvet', preview: '#1c1216', textCol: '#ebd5dc' },
                      { key: 'sepia', label: 'Sepia Warm', preview: '#f7eedc', textCol: '#432' },
                      { key: 'parchment', label: 'Parchment', preview: '#fdf6e2', textCol: '#321' },
                      { key: 'matcha', label: 'Matcha Cream', preview: '#f2f6ee', textCol: '#243322' },
                      { key: 'light', label: 'Clean Paper', preview: '#fafafa', textCol: '#111' },
                    ] as const
                  ).map((t) => (
                    <button
                      key={t.key}
                      onClick={() =>
                        onUpdateSettings({
                          ...settings,
                          theme: t.key,
                          oledPureBlack: t.key === 'oled',
                        })
                      }
                      className={`p-2 rounded-xl border flex flex-col items-center gap-1 transition text-xs ${
                        settings.theme === t.key ? 'ring-2 font-bold' : 'opacity-85 hover:opacity-100'
                      }`}
                      style={{
                        backgroundColor: t.preview,
                        color: t.textCol,
                        borderColor: settings.theme === t.key ? accentHex : themeStyle.border,
                      }}
                    >
                      <span
                        className="w-3.5 h-3.5 rounded-full border border-black/20"
                        style={{ backgroundColor: t.preview }}
                      />
                      <span className="text-[10px] truncate">{t.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Eye Comfort Controls */}
              <div className="space-y-3 p-3.5 rounded-xl border" style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.controlBg }}>
                {/* Candlelight Warm Tint */}
                <div>
                  <div className="flex justify-between text-xs mb-1 opacity-80">
                    <span>Candlelight Warm Tint</span>
                    <span className="font-mono font-bold" style={{ color: accentHex }}>{settings.warmScreenTint || 0}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="60"
                    step="5"
                    value={settings.warmScreenTint || 0}
                    onChange={(e) =>
                      onUpdateSettings({ ...settings, warmScreenTint: parseInt(e.target.value, 10) })
                    }
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                {/* Screen Brightness */}
                <div>
                  <div className="flex justify-between text-xs mb-1 opacity-80">
                    <span>Reader Brightness Dimmer</span>
                    <span className="font-mono font-bold" style={{ color: accentHex }}>{settings.brightness}%</span>
                  </div>
                  <input
                    type="range"
                    min="20"
                    max="100"
                    value={settings.brightness}
                    onChange={(e) =>
                      onUpdateSettings({ ...settings, brightness: parseInt(e.target.value, 10) })
                    }
                    className="w-full accent-amber-500 cursor-pointer"
                  />
                </div>

                {/* Reading Ruler Focus Line */}
                <label className="flex items-center justify-between pt-2 border-t cursor-pointer" style={{ borderColor: themeStyle.border }}>
                  <div>
                    <h5 className="text-xs font-semibold">Reading Ruler Focus Line</h5>
                    <p className="text-[10px] opacity-60">Translucent line follows finger/cursor</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.readingRuler ?? false}
                    onChange={(e) => onUpdateSettings({ ...settings, readingRuler: e.target.checked })}
                    className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
                  />
                </label>
              </div>
            </div>

            {/* ================= SECTION 4: ACOUSTICS & TTS ================= */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b" style={{ borderColor: themeStyle.border }}>
                <Volume2 className="w-4 h-4" style={{ color: accentHex }} />
                <h4 className="text-xs font-bold uppercase tracking-wider opacity-80">
                  Acoustics & Voice (TTS)
                </h4>
              </div>

              {/* Page Turn Sound */}
              <label className="flex items-center justify-between p-3 rounded-xl border cursor-pointer" style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.controlBg }}>
                <div>
                  <span className="text-xs font-semibold block">Paper Page Flip Sound</span>
                  <span className="text-[10px] opacity-60">Procedural paper rustle acoustic effect</span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.soundEffects ?? true}
                  onChange={(e) => onUpdateSettings({ ...settings, soundEffects: e.target.checked })}
                  className="w-4 h-4 rounded accent-amber-500 cursor-pointer"
                />
              </label>

              {/* TTS Voice Settings */}
              {availableVoices.length > 0 && (
                <div className="p-3 rounded-xl border space-y-2" style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.controlBg }}>
                  <label className="text-[11px] font-semibold block opacity-70">
                    Text-To-Speech (TTS) Voice
                  </label>
                  <select
                    value={settings.ttsVoiceUri || ''}
                    onChange={(e) => onUpdateSettings({ ...settings, ttsVoiceUri: e.target.value })}
                    className="w-full p-2 rounded-lg text-xs border"
                    style={{ backgroundColor: themeStyle.bg, borderColor: themeStyle.border, color: themeStyle.text }}
                  >
                    <option value="">Default System Voice</option>
                    {availableVoices.slice(0, 20).map((v) => (
                      <option key={v.voiceURI} value={v.voiceURI}>
                        {v.name} ({v.lang})
                      </option>
                    ))}
                  </select>

                  <div className="flex items-center gap-3 pt-1">
                    <div className="flex-1">
                      <span className="text-[10px] opacity-75 block mb-1">
                        Speed ({settings.ttsSpeed || 1.0}x)
                      </span>
                      <input
                        type="range"
                        min="0.5"
                        max="2.5"
                        step="0.1"
                        value={settings.ttsSpeed || 1.0}
                        onChange={(e) =>
                          onUpdateSettings({ ...settings, ttsSpeed: parseFloat(e.target.value) })
                        }
                        className="w-full accent-amber-500 cursor-pointer"
                      />
                    </div>
                    <div className="flex-1">
                      <span className="text-[10px] opacity-75 block mb-1">
                        Pitch ({settings.ttsPitch || 1.0}x)
                      </span>
                      <input
                        type="range"
                        min="0.8"
                        max="1.5"
                        step="0.1"
                        value={settings.ttsPitch || 1.0}
                        onChange={(e) =>
                          onUpdateSettings({ ...settings, ttsPitch: parseFloat(e.target.value) })
                        }
                        className="w-full accent-amber-500 cursor-pointer"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* AI Companion & Character Lore Drawer */}
      {showAiCompanion && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/75 backdrop-blur-sm"
            onClick={() => setShowAiCompanion(false)}
          />
          <div
            className="relative z-10 w-full max-w-xl rounded-2xl border p-6 shadow-2xl flex flex-col gap-4 max-h-[88vh] overflow-y-auto"
            style={{
              backgroundColor: themeStyle.controlBg,
              borderColor: themeStyle.border,
            }}
          >
            <div className="flex items-center justify-between pb-3 border-b" style={{ borderColor: themeStyle.border }}>
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-sm">AI Reading Companion & Lore</h3>
              </div>
              <button onClick={() => setShowAiCompanion(false)} className="p-1 rounded-lg">
                <X className="w-4 h-4" />
              </button>
            </div>

            {isAiLoading ? (
              <div className="flex flex-col items-center justify-center py-12 gap-3">
                <div className="w-8 h-8 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
                <p className="text-xs opacity-75">Gemini 3.8 Flash analyzing chapter beats & lore...</p>
              </div>
            ) : (
              <div className="space-y-4 text-xs">
                {/* Chapter Recap */}
                {aiSummary?.recap && (
                  <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/20">
                    <h4 className="font-bold text-amber-400 uppercase tracking-wider text-[11px] mb-1">
                      Previously In This Chapter
                    </h4>
                    <p className="leading-relaxed opacity-95 text-neutral-200">{aiSummary.recap}</p>
                  </div>
                )}

                {/* Character & Lore Tracker */}
                {aiLore?.characters && aiLore.characters.length > 0 && (
                  <div>
                    <h4 className="font-bold text-sky-400 uppercase tracking-wider text-[11px] mb-2 flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5" />
                      <span>Active Character Tracker</span>
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {aiLore.characters.map((c, idx) => (
                        <div
                          key={idx}
                          className="p-2.5 rounded-xl border text-[11px] flex flex-col gap-0.5"
                          style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.bg }}
                        >
                          <div className="flex items-center justify-between font-bold text-neutral-100">
                            <span>{c.name}</span>
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-sky-500/10 text-sky-400">
                              {c.role}
                            </span>
                          </div>
                          <p className="text-neutral-400 text-[10px] mt-0.5">{c.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Fantasy / Jargon Vocabulary Terms */}
                {aiLore?.terms && aiLore.terms.length > 0 && (
                  <div>
                    <h4 className="font-bold text-emerald-400 uppercase tracking-wider text-[11px] mb-2 flex items-center gap-1.5">
                      <Compass className="w-3.5 h-3.5" />
                      <span>Glossary & Novel Terminology</span>
                    </h4>
                    <div className="space-y-1.5">
                      {aiLore.terms.map((t, idx) => (
                        <div
                          key={idx}
                          className="p-2.5 rounded-xl border text-[11px]"
                          style={{ borderColor: themeStyle.border, backgroundColor: themeStyle.bg }}
                        >
                          <div className="flex items-center justify-between mb-0.5">
                            <span className="font-bold text-emerald-300">{t.term}</span>
                            <span className="text-[10px] text-neutral-500">{t.category}</span>
                          </div>
                          <p className="text-neutral-400">{t.explanation}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Next Chapter Prediction */}
                {aiLore?.cliffhangerGuess && (
                  <div className="p-3 rounded-xl border border-indigo-500/30 bg-indigo-500/10 text-[11px]">
                    <span className="font-bold text-indigo-300 block mb-1">
                      Next Chapter Prediction
                    </span>
                    <p className="opacity-90">{aiLore.cliffhangerGuess}</p>
                  </div>
                )}

                {/* Quick Word Explainer Form */}
                <div className="pt-2 border-t" style={{ borderColor: themeStyle.border }}>
                  <label className="text-[11px] font-semibold text-neutral-300 block mb-1">
                    Ask AI about a word or phrase in this book:
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="e.g. Heavenly Tribulation, Core Formation, Leyline..."
                      value={selectedWordToExplain}
                      onChange={(e) => setSelectedWordToExplain(e.target.value)}
                      className="flex-1 px-3 py-1.5 rounded-lg border text-xs"
                      style={{ backgroundColor: themeStyle.bg, borderColor: themeStyle.border }}
                    />
                    <button
                      onClick={handleExplainSelectedPhrase}
                      className="px-3 py-1.5 rounded-lg bg-amber-500 text-neutral-950 font-bold text-xs"
                    >
                      Explain
                    </button>
                  </div>
                  {aiExplainText && (
                    <div className="mt-2 p-2.5 rounded-lg bg-neutral-900 border border-neutral-800 text-[11px] text-amber-200">
                      {aiExplainText}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Share Toast Feedback */}
      {shareToast && (
        <div className="fixed bottom-12 left-1/2 -translate-x-1/2 z-50 bg-neutral-900 border border-sky-500/50 text-neutral-100 text-xs px-4 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2 animate-fade-in">
          <Check className="w-4 h-4 text-sky-400 flex-shrink-0" />
          <span>{shareToast}</span>
        </div>
      )}
    </div>
  );
};
