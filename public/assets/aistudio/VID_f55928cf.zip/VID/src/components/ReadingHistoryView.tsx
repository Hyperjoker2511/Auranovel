import React, { useState, useEffect, useMemo } from 'react';
import {
  History,
  Clock,
  Play,
  Trash2,
  Search,
  BookOpen,
  Calendar,
  Filter,
  RotateCcw,
  BookMarked,
  Sparkles,
  ArrowRight,
  CheckCircle,
  ExternalLink,
  Layers,
  ChevronRight,
  Flame,
  Bookmark,
} from 'lucide-react';
import { Novel, ReadingHistoryEntry, ReaderSettings, ReadingStats } from '../types/novel';
import {
  getReadingHistory,
  removeReadingHistoryEntry,
  clearReadingHistory,
  recordReadingHistory,
} from '../utils/storage';
import { formatReadingTime } from '../utils/readerUtils';

interface ReadingHistoryViewProps {
  novels: Novel[];
  settings: ReaderSettings;
  stats?: ReadingStats;
  onOpenReader: (novel: Novel, initialChapterIndex: number) => void;
  onNavigateTab: (tab: 'library' | 'history' | 'discover' | 'browser' | 'me' | 'settings') => void;
}

export const ReadingHistoryView: React.FC<ReadingHistoryViewProps> = ({
  novels,
  settings,
  stats,
  onOpenReader,
  onNavigateTab,
}) => {
  const [historyList, setHistoryList] = useState<ReadingHistoryEntry[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterPeriod, setFilterPeriod] = useState<'all' | 'today' | 'week' | 'month'>('all');
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    setHistoryList(getReadingHistory());
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDeleteItem = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const updated = removeReadingHistoryEntry(id);
    setHistoryList(updated);
    setDeleteConfirmId(null);
    showToast('Removed chapter entry from reading history');
  };

  const handleClearAll = () => {
    clearReadingHistory();
    setHistoryList([]);
    setShowClearConfirm(false);
    showToast('Reading history cleared');
  };

  // Quick jump to exact chapter & location
  const handleJumpToLocation = (entry: ReadingHistoryEntry) => {
    const novel = novels.find((n) => n.id === entry.novelId);
    if (novel) {
      // If the novel has saved paragraph or entry has paragraph, open reader
      onOpenReader(
        {
          ...novel,
          currentParagraphIndex: entry.paragraphIndex ?? novel.currentParagraphIndex,
          currentChapterIndex: entry.chapterIndex,
        },
        entry.chapterIndex
      );
    } else {
      // If novel is not in currently loaded state, create a fallback novel structure
      const fallbackNovel: Novel = {
        id: entry.novelId,
        title: entry.novelTitle,
        author: entry.novelAuthor || 'Unknown Author',
        coverUrl: entry.novelCoverUrl,
        description: 'Novel from reading history',
        genres: ['Web Novel'],
        sourceType: 'web',
        sourceName: 'Reading History',
        status: 'reading',
        currentChapterIndex: entry.chapterIndex,
        currentProgressPercent: entry.progressPercent,
        currentParagraphIndex: entry.paragraphIndex,
        totalChapters: Math.max(entry.chapterIndex + 1, 10),
        chapters: [
          {
            id: `${entry.novelId}_ch_${entry.chapterIndex}`,
            novelId: entry.novelId,
            index: entry.chapterIndex,
            title: entry.chapterTitle,
          },
        ],
        lastReadAt: entry.timestamp,
        createdAt: entry.timestamp,
      };
      onOpenReader(fallbackNovel, entry.chapterIndex);
    }
  };

  // Relative and formatted timestamp helper
  const formatTimeAgo = (epochMs: number) => {
    const now = Date.now();
    const diffMs = Math.max(0, now - epochMs);
    const diffSec = Math.floor(diffMs / 1000);
    const diffMin = Math.floor(diffSec / 60);
    const diffHour = Math.floor(diffMin / 60);
    const diffDays = Math.floor(diffHour / 24);

    if (diffMin < 1) return 'Just now';
    if (diffMin < 60) return `${diffMin}m ago`;
    if (diffHour < 24) return `${diffHour}h ago`;
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays}d ago`;

    const date = new Date(epochMs);
    return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  };

  const formatFullDate = (epochMs: number) => {
    const date = new Date(epochMs);
    return date.toLocaleString(undefined, {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    });
  };

  // Group chronological items
  const filteredEntries = useMemo(() => {
    const now = Date.now();
    const oneDay = 24 * 60 * 60 * 1000;
    const oneWeek = 7 * oneDay;
    const oneMonth = 30 * oneDay;

    return historyList.filter((item) => {
      // Search
      const matchesSearch =
        item.novelTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.chapterTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (item.novelAuthor && item.novelAuthor.toLowerCase().includes(searchQuery.toLowerCase()));

      if (!matchesSearch) return false;

      // Period filter
      if (filterPeriod === 'today') {
        const itemDate = new Date(item.timestamp).toDateString();
        const todayDate = new Date().toDateString();
        return itemDate === todayDate;
      }
      if (filterPeriod === 'week') {
        return now - item.timestamp <= oneWeek;
      }
      if (filterPeriod === 'month') {
        return now - item.timestamp <= oneMonth;
      }

      return true;
    });
  }, [historyList, searchQuery, filterPeriod]);

  // Group by chronological labels
  const groupedHistory = useMemo(() => {
    const groups: { [key: string]: ReadingHistoryEntry[] } = {
      Today: [],
      Yesterday: [],
      'This Week': [],
      'Earlier This Month': [],
      Older: [],
    };

    const now = new Date();
    const todayStr = now.toDateString();

    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toDateString();

    const weekAgo = new Date(now);
    weekAgo.setDate(weekAgo.getDate() - 7);

    const monthAgo = new Date(now);
    monthAgo.setDate(monthAgo.getDate() - 30);

    filteredEntries.forEach((item) => {
      const itemDate = new Date(item.timestamp);
      const itemDateStr = itemDate.toDateString();

      if (itemDateStr === todayStr) {
        groups.Today.push(item);
      } else if (itemDateStr === yesterdayStr) {
        groups.Yesterday.push(item);
      } else if (itemDate > weekAgo) {
        groups['This Week'].push(item);
      } else if (itemDate > monthAgo) {
        groups['Earlier This Month'].push(item);
      } else {
        groups.Older.push(item);
      }
    });

    return Object.entries(groups).filter(([_, items]) => items.length > 0);
  }, [filteredEntries]);

  // Unique novels in history
  const uniqueNovelsCount = new Set(historyList.map((h) => h.novelId)).size;

  return (
    <div className="flex-1 w-full max-w-5xl mx-auto p-4 sm:p-6 lg:p-8 flex flex-col gap-6 animate-fade-in">
      {/* Toast Feedback */}
      {toastMessage && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-neutral-900 border border-amber-500/50 text-neutral-100 text-xs px-4 py-2 rounded-2xl shadow-2xl flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-amber-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header & Quick Action Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-2 border-b border-neutral-800/80">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-400 flex items-center justify-center shadow-inner">
              <History className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-neutral-100 flex items-center gap-2">
                <span>Reading History</span>
              </h1>
              <p className="text-xs text-neutral-400 mt-0.5">
                Chronological timeline of read chapters with quick-access jump to your exact reading location
              </p>
            </div>
          </div>
        </div>

        {/* Top Actions: Clear History & Library Link */}
        <div className="flex items-center gap-2 self-end sm:self-center">
          {historyList.length > 0 && (
            <button
              onClick={() => setShowClearConfirm(true)}
              className="px-3 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-400 hover:text-rose-400 text-xs font-semibold flex items-center gap-1.5 transition active:scale-95"
              title="Clear all reading history"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear History</span>
            </button>
          )}

          <button
            onClick={() => onNavigateTab('library')}
            className="px-3 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-200 text-xs font-semibold flex items-center gap-1.5 transition active:scale-95"
          >
            <BookMarked className="w-3.5 h-3.5 text-amber-400" />
            <span>My Bookshelf</span>
          </button>
        </div>
      </div>

      {/* Stats Summary Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-2xl bg-neutral-900/60 border border-neutral-800/80 flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-neutral-400 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>Chapters Logged</span>
          </span>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-xl sm:text-2xl font-black text-neutral-100 font-mono">
              {historyList.length}
            </span>
            <span className="text-[11px] text-neutral-500">entries</span>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-neutral-900/60 border border-neutral-800/80 flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-neutral-400 flex items-center gap-1.5">
            <BookOpen className="w-3.5 h-3.5 text-sky-400" />
            <span>Active Stories</span>
          </span>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-xl sm:text-2xl font-black text-neutral-100 font-mono">
              {uniqueNovelsCount}
            </span>
            <span className="text-[11px] text-neutral-500">books</span>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-neutral-900/60 border border-neutral-800/80 flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-neutral-400 flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5 text-orange-400" />
            <span>Reading Streak</span>
          </span>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-xl sm:text-2xl font-black text-neutral-100 font-mono">
              {stats?.currentStreak || 1}
            </span>
            <span className="text-[11px] text-neutral-500">days active</span>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-neutral-900/60 border border-neutral-800/80 flex flex-col justify-between">
          <span className="text-[11px] font-semibold text-neutral-400 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
            <span>Latest Session</span>
          </span>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-sm font-bold text-neutral-200 truncate">
              {historyList[0] ? formatTimeAgo(historyList[0].timestamp) : 'None yet'}
            </span>
          </div>
        </div>
      </div>

      {/* Search and Period Filter Controls */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
          <input
            type="text"
            placeholder="Search history by novel title or chapter..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-neutral-900/90 border border-neutral-800 rounded-xl text-xs sm:text-sm text-neutral-200 placeholder-neutral-500 focus:outline-none focus:border-amber-500 transition"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-neutral-300 text-xs"
            >
              Clear
            </button>
          )}
        </div>

        {/* Time Period Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          {[
            { id: 'all', label: 'All Time' },
            { id: 'today', label: 'Today' },
            { id: 'week', label: 'This Week' },
            { id: 'month', label: 'This Month' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterPeriod(tab.id as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition whitespace-nowrap active:scale-95 ${
                filterPeriod === tab.id
                  ? 'bg-amber-500 text-neutral-950 shadow-md shadow-amber-500/20'
                  : 'bg-neutral-900/80 hover:bg-neutral-800 border border-neutral-800 text-neutral-300'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Chronological List Content */}
      {filteredEntries.length === 0 ? (
        <div className="p-12 sm:p-16 border border-neutral-800/80 rounded-2xl bg-neutral-900/30 text-center flex flex-col items-center justify-center max-w-md mx-auto my-6">
          <div className="w-16 h-16 rounded-2xl bg-neutral-800/60 border border-neutral-700/60 flex items-center justify-center mb-4 text-3xl">
            ⏳
          </div>
          <h3 className="text-base font-bold text-neutral-200">
            {searchQuery || filterPeriod !== 'all' ? 'No Matching Chapters Found' : 'No Reading History Yet'}
          </h3>
          <p className="text-xs text-neutral-400 mt-1 text-center">
            {searchQuery || filterPeriod !== 'all'
              ? 'Try modifying your search query or reset the date period filter.'
              : 'As you read chapters, your reading progress, exact paragraphs, and timestamps will automatically be recorded here for instant jump-back.'}
          </p>

          <div className="flex items-center gap-2.5 mt-5">
            {searchQuery || filterPeriod !== 'all' ? (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setFilterPeriod('all');
                }}
                className="px-4 py-2 rounded-xl bg-amber-500 text-neutral-950 font-bold text-xs"
              >
                Reset Filters
              </button>
            ) : (
              <button
                onClick={() => onNavigateTab('library')}
                className="px-4 py-2 rounded-xl bg-amber-500 text-neutral-950 font-bold text-xs flex items-center gap-1.5"
              >
                <BookOpen className="w-4 h-4" />
                <span>Open Library to Read</span>
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="flex flex-col gap-8">
          {groupedHistory.map(([groupTitle, entries]) => (
            <div key={groupTitle} className="flex flex-col gap-3">
              {/* Group Header Badge */}
              <div className="flex items-center gap-2.5">
                <span className="px-3 py-1 rounded-full bg-neutral-800/80 border border-neutral-700/80 text-neutral-300 text-xs font-bold tracking-wide flex items-center gap-1.5 shadow-sm">
                  <Calendar className="w-3.5 h-3.5 text-amber-400" />
                  <span>{groupTitle}</span>
                </span>
                <span className="text-[11px] text-neutral-500">
                  {entries.length} {entries.length === 1 ? 'chapter' : 'chapters'}
                </span>
                <div className="flex-1 h-px bg-neutral-800/80 ml-2" />
              </div>

              {/* Entries Cards */}
              <div className="grid grid-cols-1 gap-3">
                {entries.map((entry) => {
                  const progress = Math.max(0, Math.min(100, Math.round(entry.progressPercent || 0)));
                  const isFinished = progress >= 95;

                  return (
                    <div
                      key={entry.id}
                      className="group relative bg-neutral-900/70 hover:bg-neutral-900 border border-neutral-800/80 hover:border-neutral-700 rounded-2xl p-3 sm:p-4 transition shadow-md hover:shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                    >
                      {/* Left: Thumbnail & Chapter Details */}
                      <div className="flex items-start sm:items-center gap-3.5 flex-1 min-w-0">
                        {/* Novel Cover Thumbnail */}
                        <div
                          onClick={() => handleJumpToLocation(entry)}
                          className="relative w-14 h-19 sm:w-16 sm:h-22 rounded-xl overflow-hidden bg-neutral-950 flex-shrink-0 cursor-pointer shadow border border-neutral-800 group-hover:scale-102 transition"
                        >
                          {entry.novelCoverUrl ? (
                            <img
                              src={entry.novelCoverUrl}
                              alt={entry.novelTitle}
                              className="w-full h-full object-cover"
                              loading="lazy"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-neutral-800 to-neutral-950 text-neutral-400 text-xl font-bold">
                              📖
                            </div>
                          )}
                          <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition" />
                        </div>

                        {/* Title, Author, Chapter Title & Progress */}
                        <div className="flex-1 min-w-0 flex flex-col gap-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-xs font-bold text-neutral-400 truncate max-w-[220px] sm:max-w-xs">
                              {entry.novelTitle}
                            </span>
                            {entry.novelAuthor && (
                              <span className="text-[11px] text-neutral-500 hidden sm:inline">
                                • {entry.novelAuthor}
                              </span>
                            )}
                          </div>

                          <h3
                            onClick={() => handleJumpToLocation(entry)}
                            className="text-sm sm:text-base font-bold text-neutral-100 group-hover:text-amber-400 transition cursor-pointer line-clamp-1"
                          >
                            {entry.chapterTitle}
                          </h3>

                          {/* Progress and Paragraph Detail */}
                          <div className="flex flex-wrap items-center gap-2.5 mt-1 text-[11px] text-neutral-400">
                            {/* Chapter Index Indicator */}
                            <span className="px-2 py-0.5 rounded-md bg-neutral-800 border border-neutral-700/80 text-neutral-300 font-mono text-[10px]">
                              Ch {entry.chapterIndex + 1}
                            </span>

                            {/* Progress bar */}
                            <div className="flex items-center gap-2">
                              <div className="w-20 sm:w-28 h-1.5 rounded-full bg-neutral-800 overflow-hidden">
                                <div
                                  className={`h-full transition-all duration-300 ${
                                    isFinished ? 'bg-emerald-400' : 'bg-amber-500'
                                  }`}
                                  style={{ width: `${progress}%` }}
                                />
                              </div>
                              <span
                                className={`font-mono text-[10px] font-semibold ${
                                  isFinished ? 'text-emerald-400' : 'text-amber-400'
                                }`}
                              >
                                {isFinished ? 'Finished' : `${progress}%`}
                              </span>
                            </div>

                            {/* Paragraph index if saved */}
                            {entry.paragraphIndex !== undefined && entry.paragraphIndex > 0 && (
                              <span className="hidden md:inline text-neutral-500 text-[10px]">
                                • Paragraph {entry.paragraphIndex + 1}
                              </span>
                            )}
                          </div>

                          {/* Timestamp Details */}
                          <div className="flex items-center gap-2 text-[10px] text-neutral-500 mt-0.5">
                            <Clock className="w-3 h-3 text-neutral-500" />
                            <span className="text-neutral-400 font-medium">{formatTimeAgo(entry.timestamp)}</span>
                            <span>•</span>
                            <span className="hidden sm:inline">{formatFullDate(entry.timestamp)}</span>
                          </div>
                        </div>
                      </div>

                      {/* Right: Quick Jump-To-Location Button & Delete */}
                      <div className="flex items-center gap-2.5 w-full sm:w-auto justify-between sm:justify-end border-t sm:border-t-0 pt-2.5 sm:pt-0 border-neutral-800/80">
                        {/* Quick Access Jump Button */}
                        <button
                          onClick={() => handleJumpToLocation(entry)}
                          className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs flex items-center justify-center gap-2 transition active:scale-95 shadow-md shadow-amber-500/20"
                          title="Jump directly to this chapter and location"
                        >
                          <Play className="w-3.5 h-3.5 fill-current" />
                          <span>Jump to Location</span>
                        </button>

                        {/* Delete Single Entry */}
                        <button
                          onClick={(e) => handleDeleteItem(entry.id, e)}
                          className="p-2.5 rounded-xl bg-neutral-800/80 hover:bg-neutral-800 hover:text-rose-400 text-neutral-400 transition active:scale-95 border border-neutral-700/80"
                          title="Remove from history"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Clear All Confirmation Modal */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-sm"
            onClick={() => setShowClearConfirm(false)}
          />
          <div className="relative z-10 w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-3xl p-6 shadow-2xl flex flex-col gap-4 text-center">
            <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>

            <div>
              <h3 className="text-base font-bold text-neutral-100">Clear Reading History?</h3>
              <p className="text-xs text-neutral-400 mt-1">
                This will remove all timestamped chapter logs. Your saved books in My Bookshelf and your reading stats will remain safe.
              </p>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="flex-1 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold text-xs transition"
              >
                Cancel
              </button>
              <button
                onClick={handleClearAll}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition shadow-lg shadow-rose-600/20"
              >
                Yes, Clear All
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
