import React, { useState, useEffect, useRef } from 'react';
import {
  User,
  Camera,
  Edit3,
  Check,
  X,
  Sparkles,
  Flame,
  Award,
  BookOpen,
  Heart,
  Download,
  Clock,
  BookMarked,
  SlidersHorizontal,
  ChevronRight,
  ShieldCheck,
  Zap,
  Calendar,
  Layers,
  Image as ImageIcon,
  RotateCcw,
} from 'lucide-react';
import { Novel, ReadingStats, ReaderSettings, UserProfile, ReadingHistoryEntry } from '../types/novel';
import {
  getUserProfile,
  saveUserProfile,
  DEFAULT_USER_PROFILE,
  PRESET_AVATARS,
  getDownloadedChapterIndices,
  getReadingHistory,
} from '../utils/storage';
import { ReadingStatsWidget } from './ReadingStatsWidget';
import { formatReadingTime } from '../utils/readerUtils';
import { calculateUserProgression, getTitleBadges } from '../utils/progression';

interface MeViewProps {
  stats: ReadingStats;
  novels: Novel[];
  settings: ReaderSettings;
  onOpenReader: (novel: Novel, initialChapterIndex: number) => void;
  onNavigateTab: (tab: 'library' | 'history' | 'discover' | 'browser' | 'me' | 'settings') => void;
}

export const MeView: React.FC<MeViewProps> = ({
  stats,
  novels,
  settings,
  onOpenReader,
  onNavigateTab,
}) => {
  const [profile, setProfile] = useState<UserProfile>(getUserProfile());
  const [isEditingName, setIsEditingName] = useState(false);
  const [tempName, setTempName] = useState(profile.name);
  const [tempBio, setTempBio] = useState(profile.bio);
  const [showAvatarPicker, setShowAvatarPicker] = useState(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);
  const [recentHistory, setRecentHistory] = useState<ReadingHistoryEntry[]>([]);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setProfile(getUserProfile());
    setRecentHistory(getReadingHistory().slice(0, 3));
  }, []);

  const progression = calculateUserProgression(stats);
  const titleBadges = getTitleBadges(stats);
  const unlockedBadges = titleBadges.filter((b) => b.isUnlocked);

  // Active or most recent novel
  const currentActiveBook =
    novels.find((n) => n.status === 'reading') ||
    [...novels].sort((a, b) => (b.lastReadAt || 0) - (a.lastReadAt || 0))[0] ||
    null;

  const favoriteNovels = novels.filter((n) => n.isFavorite);
  const completedNovels = novels.filter((n) => n.status === 'completed');
  const readingNovels = novels.filter((n) => n.status === 'reading');

  const handleSaveProfile = () => {
    if (!tempName.trim()) return;
    const updated: UserProfile = {
      ...profile,
      name: tempName.trim(),
      bio: tempBio.trim() || DEFAULT_USER_PROFILE.bio,
    };
    setProfile(updated);
    saveUserProfile(updated);
    setIsEditingName(false);
    triggerSuccessToast('Profile details updated!');
  };

  const handleSelectPresetAvatar = (url: string) => {
    const updated: UserProfile = {
      ...profile,
      avatarUrl: url,
    };
    setProfile(updated);
    saveUserProfile(updated);
    setShowAvatarPicker(false);
    triggerSuccessToast('Profile photo updated!');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Please select an image file (PNG, JPG, WebP, etc.).');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        const updated: UserProfile = {
          ...profile,
          avatarUrl: dataUrl,
        };
        setProfile(updated);
        saveUserProfile(updated);
        setShowAvatarPicker(false);
        triggerSuccessToast('Custom profile photo saved!');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleResetAvatar = () => {
    const updated: UserProfile = {
      ...profile,
      avatarUrl: DEFAULT_USER_PROFILE.avatarUrl,
    };
    setProfile(updated);
    saveUserProfile(updated);
    setShowAvatarPicker(false);
    triggerSuccessToast('Profile photo reset to default.');
  };

  const triggerSuccessToast = (msg: string) => {
    setSaveSuccessMsg(msg);
    setTimeout(() => setSaveSuccessMsg(null), 3000);
  };

  return (
    <div className="flex-1 w-full max-w-5xl mx-auto p-4 sm:p-6 lg:p-8 flex flex-col gap-6 animate-fade-in">
      {/* Toast Alert */}
      {saveSuccessMsg && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 bg-emerald-950 border border-emerald-500/50 text-emerald-200 text-xs px-4 py-2 rounded-2xl shadow-2xl flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{saveSuccessMsg}</span>
        </div>
      )}

      {/* User Profile Card */}
      <div className="relative overflow-hidden bg-gradient-to-br from-neutral-900 via-neutral-900/90 to-neutral-950 border border-neutral-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
        {/* Subtle Decorative Ambient Glow */}
        <div className="absolute top-0 right-0 w-72 h-72 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="relative flex flex-col sm:flex-row items-center sm:items-start gap-6">
          {/* Profile Photo Avatar with Change Action */}
          <div className="relative group">
            <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl overflow-hidden border-2 border-amber-500/40 shadow-xl bg-neutral-950 flex items-center justify-center">
              {profile.avatarUrl ? (
                <img
                  src={profile.avatarUrl}
                  alt={profile.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-neutral-900 flex items-center justify-center text-4xl">
                  👤
                </div>
              )}
            </div>

            {/* Photo Edit Trigger Button */}
            <button
              onClick={() => setShowAvatarPicker(true)}
              className="absolute -bottom-1 -right-1 p-2 rounded-2xl bg-amber-500 hover:bg-amber-400 text-neutral-950 shadow-lg transition active:scale-95 flex items-center justify-center"
              title="Change Profile Photo"
            >
              <Camera className="w-4 h-4 stroke-[2.5]" />
            </button>
          </div>

          {/* User Information & Edit Details */}
          <div className="flex-1 text-center sm:text-left flex flex-col justify-between">
            {isEditingName ? (
              <div className="flex flex-col gap-3 max-w-md">
                <div>
                  <label className="text-[11px] font-semibold text-neutral-400 block mb-1">
                    Display Name
                  </label>
                  <input
                    type="text"
                    value={tempName}
                    onChange={(e) => setTempName(e.target.value)}
                    className="w-full px-3.5 py-2 bg-neutral-950 border border-neutral-700 rounded-xl text-sm font-bold text-neutral-100 focus:outline-none focus:border-amber-500"
                    placeholder="Enter your name"
                    autoFocus
                  />
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-neutral-400 block mb-1">
                    Reading Bio / Motto
                  </label>
                  <input
                    type="text"
                    value={tempBio}
                    onChange={(e) => setTempBio(e.target.value)}
                    className="w-full px-3.5 py-2 bg-neutral-950 border border-neutral-700 rounded-xl text-xs text-neutral-200 focus:outline-none focus:border-amber-500"
                    placeholder="Wandering through infinite realms..."
                  />
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={handleSaveProfile}
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-neutral-950 font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5 transition"
                  >
                    <Check className="w-4 h-4" />
                    <span>Save Profile</span>
                  </button>
                  <button
                    onClick={() => {
                      setTempName(profile.name);
                      setTempBio(profile.bio);
                      setIsEditingName(false);
                    }}
                    className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 font-semibold text-xs rounded-xl transition"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div>
                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2.5">
                  <h1 className="text-xl sm:text-2xl font-black text-neutral-100 tracking-tight">
                    {profile.name}
                  </h1>

                  <button
                    onClick={() => {
                      setTempName(profile.name);
                      setTempBio(profile.bio);
                      setIsEditingName(true);
                    }}
                    className="p-1.5 rounded-lg text-neutral-400 hover:text-amber-400 hover:bg-neutral-800 transition"
                    title="Change Name & Bio"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mt-2">
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-amber-400 fill-amber-400" />
                    <span>{progression.rankTitle}</span>
                  </span>

                  <span className="px-2.5 py-0.5 rounded-full bg-neutral-800 border border-neutral-700 text-neutral-300 text-[11px] font-mono">
                    Level {progression.level} Reader
                  </span>

                  <span className="px-2.5 py-0.5 rounded-full bg-orange-500/10 border border-orange-500/30 text-orange-400 text-[11px] font-bold flex items-center gap-1">
                    <Flame className="w-3 h-3 fill-orange-400" />
                    <span>{stats.currentStreak || 1}d Streak</span>
                  </span>
                </div>

                <p className="text-xs text-neutral-400 mt-2.5 italic max-w-lg">
                  "{profile.bio}"
                </p>

                <div className="text-[11px] text-neutral-500 flex items-center justify-center sm:justify-start gap-3 mt-3">
                  <span>{profile.joinedDate || 'Member of AetherNovel'}</span>
                  <span>•</span>
                  <span>{unlockedBadges.length} milestone badges earned</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Profile Photo Picker Modal */}
      {showAvatarPicker && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-sm"
            onClick={() => setShowAvatarPicker(false)}
          />
          <div className="relative z-10 w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-3xl p-6 shadow-2xl flex flex-col gap-5">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2 font-bold text-sm text-neutral-100">
                <Camera className="w-4 h-4 text-amber-400" />
                <span>Change Profile Photo</span>
              </div>
              <button
                onClick={() => setShowAvatarPicker(false)}
                className="p-1 rounded-lg text-neutral-400 hover:text-neutral-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Custom Photo Upload Button */}
            <div>
              <span className="text-xs font-semibold text-neutral-300 block mb-2">
                Upload from Device:
              </span>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full py-3 px-4 rounded-2xl bg-neutral-800/80 hover:bg-neutral-800 border border-neutral-700/80 text-neutral-200 text-xs font-semibold flex items-center justify-center gap-2 transition active:scale-95"
              >
                <ImageIcon className="w-4 h-4 text-sky-400" />
                <span>Choose Image File (JPG, PNG, WebP)</span>
              </button>
            </div>

            {/* Novel Avatar Presets */}
            <div>
              <span className="text-xs font-semibold text-neutral-300 block mb-2.5">
                Or Select a Novel-Themed Avatar:
              </span>
              <div className="grid grid-cols-3 gap-3">
                {PRESET_AVATARS.map((av) => (
                  <button
                    key={av.id}
                    onClick={() => handleSelectPresetAvatar(av.url)}
                    className={`group relative rounded-2xl overflow-hidden border-2 p-0.5 transition active:scale-95 flex flex-col items-center gap-1 ${
                      profile.avatarUrl === av.url
                        ? 'border-amber-400 ring-2 ring-amber-400/30'
                        : 'border-neutral-800 hover:border-neutral-700'
                    }`}
                  >
                    <div className="w-full aspect-square rounded-xl overflow-hidden bg-neutral-950">
                      <img
                        src={av.url}
                        alt={av.label}
                        className="w-full h-full object-cover group-hover:scale-105 transition"
                      />
                    </div>
                    <span className="text-[10px] text-neutral-400 truncate w-full text-center pb-1">
                      {av.label}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Reset to Default */}
            <div className="pt-2 border-t border-neutral-800 flex justify-between items-center">
              <button
                onClick={handleResetAvatar}
                className="text-xs text-neutral-500 hover:text-neutral-300 flex items-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset to default</span>
              </button>
              <button
                onClick={() => setShowAvatarPicker(false)}
                className="px-4 py-2 bg-neutral-800 text-neutral-200 text-xs rounded-xl font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reading Status & Level Progression Widget (Dedicated Option) */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-500" />
            <h2 className="text-base sm:text-lg font-bold text-neutral-100">
              Reading Status & Leveling Progression
            </h2>
          </div>
          <span className="text-xs text-neutral-500 font-mono">
            {stats.chaptersCompleted} chs • {formatReadingTime(stats.totalSecondsRead)}
          </span>
        </div>

        {/* Full Reading Stats Widget Component */}
        <ReadingStatsWidget
          currentBook={currentActiveBook}
          stats={stats}
          settings={settings}
          onContinueReading={(novel) => onOpenReader(novel, novel.currentChapterIndex || 0)}
        />
      </div>

      {/* Recent Reading History Quick Access */}
      {recentHistory.length > 0 && (
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-amber-500" />
              <h2 className="text-base sm:text-lg font-bold text-neutral-100">
                Recent Reading History
              </h2>
            </div>
            <button
              onClick={() => onNavigateTab('history')}
              className="text-xs text-amber-400 hover:text-amber-300 font-semibold flex items-center gap-1 transition"
            >
              <span>View Full History</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {recentHistory.map((item) => {
              const matchedNovel = novels.find((n) => n.id === item.novelId);
              return (
                <div
                  key={item.id}
                  className="p-3.5 rounded-2xl bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 flex flex-col justify-between gap-3 group transition shadow-sm"
                >
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="w-10 h-14 rounded-lg overflow-hidden bg-neutral-950 flex-shrink-0 border border-neutral-800">
                      {item.novelCoverUrl ? (
                        <img
                          src={item.novelCoverUrl}
                          alt={item.novelTitle}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-sm bg-neutral-900 text-neutral-500">
                          📖
                        </div>
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <span className="text-[10px] text-neutral-500 font-mono block">
                        {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                      <h4 className="text-xs font-bold text-neutral-200 truncate mt-0.5">
                        {item.novelTitle}
                      </h4>
                      <p className="text-[11px] text-amber-400 truncate font-medium">
                        Ch. {item.chapterIndex + 1}: {item.chapterTitle}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      if (matchedNovel) {
                        onOpenReader(matchedNovel, item.chapterIndex);
                      } else {
                        onNavigateTab('history');
                      }
                    }}
                    className="w-full py-1.5 px-3 rounded-xl bg-amber-500/10 hover:bg-amber-500 border border-amber-500/30 hover:border-amber-500 text-amber-300 hover:text-neutral-950 font-bold text-xs flex items-center justify-center gap-1.5 transition"
                  >
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>Jump to Chapter</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Bookshelf Statistics & Quick Library Navigation */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
        <div
          onClick={() => onNavigateTab('library')}
          className="p-4 rounded-2xl bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 transition cursor-pointer flex flex-col justify-between group"
        >
          <div className="flex items-center justify-between text-neutral-400">
            <span className="text-xs font-semibold">Total Saved</span>
            <BookMarked className="w-4 h-4 group-hover:text-amber-400 transition" />
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-neutral-100">{novels.length}</span>
            <span className="text-[11px] text-neutral-500 block">Books in library</span>
          </div>
        </div>

        <div
          onClick={() => onNavigateTab('library')}
          className="p-4 rounded-2xl bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 transition cursor-pointer flex flex-col justify-between group"
        >
          <div className="flex items-center justify-between text-neutral-400">
            <span className="text-xs font-semibold">Favorites</span>
            <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-neutral-100">{favoriteNovels.length}</span>
            <span className="text-[11px] text-neutral-500 block">Favorite novels</span>
          </div>
        </div>

        <div
          onClick={() => onNavigateTab('library')}
          className="p-4 rounded-2xl bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 transition cursor-pointer flex flex-col justify-between group"
        >
          <div className="flex items-center justify-between text-neutral-400">
            <span className="text-xs font-semibold">In Progress</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-neutral-100">{readingNovels.length}</span>
            <span className="text-[11px] text-neutral-500 block">Currently reading</span>
          </div>
        </div>

        <div
          onClick={() => onNavigateTab('library')}
          className="p-4 rounded-2xl bg-neutral-900/60 border border-neutral-800 hover:border-neutral-700 transition cursor-pointer flex flex-col justify-between group"
        >
          <div className="flex items-center justify-between text-neutral-400">
            <span className="text-xs font-semibold">Finished</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-neutral-100">{completedNovels.length}</span>
            <span className="text-[11px] text-neutral-500 block">Books completed</span>
          </div>
        </div>
      </div>

      {/* Reader Preferences & Device Optimization Quick Card */}
      <div className="p-5 rounded-2xl bg-neutral-900/40 border border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center">
            <SlidersHorizontal className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-bold text-neutral-200">
              Reading Theme & Performance Settings
            </h4>
            <p className="text-[11px] text-neutral-400">
              Active: {settings.theme.toUpperCase()} theme • {settings.fontSize}px {settings.fontFamily} • Low-Spec Mode {settings.lowSpecMode ? 'Enabled' : 'Disabled'}
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigateTab('settings')}
          className="w-full sm:w-auto px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition active:scale-95"
        >
          <span>Open Settings</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
