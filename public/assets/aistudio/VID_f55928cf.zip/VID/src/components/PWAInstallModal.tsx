import React, { useState } from 'react';
import {
  Download,
  Smartphone,
  CheckCircle,
  X,
  Share2,
  ExternalLink,
  Layers,
  Sparkles,
  Zap,
  Info,
  ShieldCheck,
  Package,
} from 'lucide-react';
import { usePWAInstall } from '../utils/usePWAInstall';

interface PWAInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [installStatus, setInstallStatus] = useState<'idle' | 'installing' | 'success' | 'dismissed'>('idle');

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    setInstallStatus('installing');
    const result = await install();
    if (result === 'accepted') {
      setInstallStatus('success');
      setTimeout(() => {
        onClose();
        setInstallStatus('idle');
      }, 2500);
    } else if (result === 'dismissed') {
      setInstallStatus('dismissed');
      setTimeout(() => setInstallStatus('idle'), 3000);
    } else {
      setInstallStatus('idle');
    }
  };

  const handleDownloadManifest = () => {
    const manifest = {
      id: '/',
      name: 'AetherNovel - Next-Gen Novel & EPUB Reader',
      short_name: 'AetherNovel',
      description: 'High-performance web novel and EPUB reader with community extension repositories and offline chapter caching.',
      theme_color: '#090d16',
      background_color: '#090d16',
      display: 'standalone',
      orientation: 'portrait',
      start_url: '/',
      scope: '/',
      icons: [
        {
          src: '/pwa-192x192.png',
          sizes: '192x192',
          type: 'image/png',
          purpose: 'any',
        },
        {
          src: '/pwa-512x512.png',
          sizes: '512x512',
          type: 'image/png',
          purpose: 'any',
        },
        {
          src: '/pwa-maskable-512x512.png',
          sizes: '512x512',
          type: 'image/png',
          purpose: 'maskable',
        },
      ],
      categories: ['books', 'education', 'entertainment'],
    };

    const blob = new Blob([JSON.stringify(manifest, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'aethernovel-app-manifest.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-3xl p-6 sm:p-7 shadow-2xl flex flex-col gap-5 animate-fade-in text-neutral-100">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-400 flex items-center justify-center shadow-inner">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold tracking-tight">
                Install Android APK / Mobile App
              </h2>
              <p className="text-[11px] text-neutral-400">
                PWA WebAPK & Standalone App Launcher
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Already Installed Status */}
        {isInstalled ? (
          <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-200 flex items-center gap-3">
            <ShieldCheck className="w-6 h-6 text-emerald-400 flex-shrink-0" />
            <div className="text-xs">
              <span className="font-bold block text-sm">App Already Installed!</span>
              <span>AetherNovel is running in standalone mode with full offline caching and hardware acceleration.</span>
            </div>
          </div>
        ) : (
          <>
            {/* Install Prompt Button */}
            {isInstallable ? (
              <div className="flex flex-col gap-2">
                <button
                  onClick={handleInstallClick}
                  disabled={installStatus === 'installing'}
                  className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-neutral-950 font-bold text-sm flex items-center justify-center gap-2 transition active:scale-95 shadow-lg shadow-amber-500/20"
                >
                  {installStatus === 'installing' ? (
                    <div className="w-4 h-4 border-2 border-neutral-950 border-t-transparent rounded-full animate-spin" />
                  ) : installStatus === 'success' ? (
                    <>
                      <CheckCircle className="w-4 h-4" />
                      <span>Installation Started!</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4" />
                      <span>Install APK / WebApp on Device</span>
                    </>
                  )}
                </button>
                <p className="text-[11px] text-neutral-400 text-center">
                  Installs an official Android WebAPK with offline support, home screen icon, and full-screen reading.
                </p>
              </div>
            ) : null}

            {/* Android Chrome Instructions */}
            <div className="p-4 rounded-2xl bg-neutral-950/60 border border-neutral-800 flex flex-col gap-2.5">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
                <Smartphone className="w-4 h-4" />
                <span>Android Chrome / Samsung Internet Instructions:</span>
              </div>
              <ol className="text-xs text-neutral-300 flex flex-col gap-1.5 pl-4 list-decimal">
                <li>Tap the browser menu <strong className="text-neutral-100">⋮ (three dots)</strong> in the top right.</li>
                <li>Select <strong className="text-amber-400">"Install app"</strong> or <strong className="text-amber-400">"Add to Home screen"</strong>.</li>
                <li>Android will generate and install the official WebAPK package to your app drawer.</li>
              </ol>
            </div>

            {/* iOS Safari Instructions */}
            <div className="p-3.5 rounded-2xl bg-neutral-950/40 border border-neutral-800/80 flex flex-col gap-2">
              <div className="flex items-center gap-2 text-xs font-bold text-sky-400">
                <Share2 className="w-3.5 h-3.5" />
                <span>iPhone / iPad (iOS Safari):</span>
              </div>
              <p className="text-[11px] text-neutral-400">
                Tap the <strong className="text-neutral-200">Share button</strong> (square with arrow up) at the bottom of Safari, scroll down, and tap <strong className="text-neutral-200">"Add to Home Screen"</strong>.
              </p>
            </div>
          </>
        )}

        {/* APK / PWA Manifest Download for packaging */}
        <div className="pt-2 border-t border-neutral-800 flex items-center justify-between gap-3">
          <button
            onClick={handleDownloadManifest}
            className="text-xs text-neutral-400 hover:text-amber-400 flex items-center gap-1.5 transition"
            title="Download manifest JSON for Bubblewrap or PWABuilder"
          >
            <Package className="w-3.5 h-3.5" />
            <span>Download APK Manifest</span>
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-semibold text-xs transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
