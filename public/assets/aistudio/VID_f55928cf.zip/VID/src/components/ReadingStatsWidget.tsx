import React, { useState } from 'react';
import {
  Flame,
  Award,
  Clock,
  BookOpen,
  TrendingUp,
  Sparkles,
  ChevronRight,
  ChevronDown,
  BarChart2,
  Calendar,
  Zap,
  Lock,
  CheckCircle2,
  X,
  Trophy,
} from 'lucide-react';
import { Novel, ReadingStats, ReaderSettings } from '../types/novel';
import {
  calculateUserProgression,
  estimateTimeRemaining,
  getWeeklyActivityData,
  getTitleBadges,
  TitleBadge,
} from '../utils/progression';
import { formatReadingTime } from '../utils/readerUtils';

interface ReadingStatsWidgetProps {
  currentBook: Novel | null;
  stats: ReadingStats;
  settings: ReaderSettings;
  onContinueReading: (novel: Novel) => void;
}

export const ReadingStatsWidget: React.FC<ReadingStatsWidgetProps> = ({
  currentBook,
  stats,
  settings,
  onContinueReading,
}) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [showBadgesModal, setShowBadgesModal] = useState(false);

  const progression = calculateUserProgression(stats);
  const weeklyData = getWeeklyActivityData(stats);
  const timeRemaining = currentBook ? estimateTimeRemaining(currentBook, settings.wpmReadingSpeed || 240) : null;
  const allBadges = getTitleBadges(stats);
  const unlockedBadges = allBadges.filter((b) => b.isUnlocked);
  const nextBadgeToUnlock = allBadges.find((b) => !b.isUnlocked);

  const maxWeeklyMinutes = Math.max(1, ...weeklyData.map((d) => d.minutes), 30);
  const totalWeeklyMinutes = weeklyData.reduce((acc, curr) => acc + curr.minutes, 0);

  const xpPercent = Math.min(
    100,
    Math.round((progression.currentXp / Math.max(1, progression.nextLevelXp)) * 100)
  );

  return (
    <div className="w-full bg-gradient-to-br from-neutral-900/90 via-neutral-900/60 to-neutral-950 border border-neutral-800/90 rounded-2xl p-4 sm:p-5 shadow-xl transition-all">
      {/* Top Header: Level, Active Title, Streak & Expand Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          {/* Level Circle */}
          <div className="relative flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-300 text-neutral-950 font-black shadow-lg shadow-amber-500/20 text-lg flex-shrink-0">
            <span>{progression.level}</span>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-neutral-950 border border-amber-400 flex items-center justify-center">
              <Sparkles className="w-2.5 h-2.5 text-amber-400 fill-amber-400" />
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs uppercase tracking-wider text-amber-400 font-bold">
                Level {progression.level}
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold">
                {progression.rankTitle}
              </span>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-400 text-[10px] font-semibold">
                <Flame className="w-3 h-3 fill-orange-400" />
                <span>{stats.currentStreak || 1}d Streak</span>
              </span>
            </div>
            <p className="text-[11px] text-neutral-400 mt-0.5">
              Total Reading: <strong className="text-neutral-200">{formatReadingTime(stats.totalSecondsRead)}</strong> •{' '}
              <strong className="text-neutral-200">{stats.chaptersCompleted}</strong> chapters read
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          {/* View Badges Button */}
          <button
            onClick={() => setShowBadgesModal(true)}
            className="px-3 py-1.5 rounded-xl bg-neutral-800/90 hover:bg-neutral-700/90 border border-neutral-700 text-neutral-200 text-xs font-semibold flex items-center gap-1.5 transition active:scale-95 shadow-sm"
          >
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span>Badges ({unlockedBadges.length}/{allBadges.length})</span>
          </button>

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 rounded-xl bg-neutral-800/80 hover:bg-neutral-700/80 text-neutral-400 hover:text-neutral-200 transition"
            title={isExpanded ? 'Collapse Stats' : 'Expand Stats'}
          >
            {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Level XP Progress Bar */}
      <div className="mt-3 w-full bg-neutral-950/80 rounded-full h-2 overflow-hidden border border-neutral-800/80">
        <div
          className="h-full bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-300 rounded-full transition-all duration-500"
          style={{ width: `${xpPercent}%` }}
        />
      </div>

      {/* Earned Title Badges Showcase Strip */}
      <div className="mt-3 flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        <span className="text-[10px] uppercase tracking-wider text-neutral-500 font-bold whitespace-nowrap">
          Earned Titles:
        </span>
        {unlockedBadges.map((badge) => (
          <div
            key={badge.id}
            onClick={() => setShowBadgesModal(true)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-200 text-xs font-semibold whitespace-nowrap cursor-pointer hover:border-amber-500/50 transition shadow-sm"
          >
            <span className="text-sm">{badge.icon}</span>
            <span className="text-[11px] font-bold text-amber-300">{badge.title}</span>
          </div>
        ))}

        {nextBadgeToUnlock && (
          <div
            onClick={() => setShowBadgesModal(true)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-neutral-950/60 border border-dashed border-neutral-800 text-neutral-500 text-xs whitespace-nowrap cursor-pointer hover:text-neutral-400 transition"
          >
            <Lock className="w-3 h-3 text-neutral-600" />
            <span className="text-[10px]">Next: {nextBadgeToUnlock.title} ({nextBadgeToUnlock.progressPercent}%)</span>
          </div>
        )}
      </div>

      {/* Expanded Content: Estimated Time Remaining & Weekly Activity */}
      {isExpanded && (
        <div className="mt-4 pt-4 border-t border-neutral-800/70 grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5">
          {/* Left Column: Current Book & Estimated Time Remaining */}
          <div className="flex flex-col justify-between p-3.5 sm:p-4 rounded-xl bg-neutral-950/60 border border-neutral-800/60">
            <div>
              <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
                <span className="font-semibold flex items-center gap-1.5 text-neutral-300">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  Estimated Time Remaining
                </span>
                <span className="text-[11px] font-mono text-neutral-500">
                  {settings.wpmReadingSpeed || 240} wpm pace
                </span>
              </div>

              {currentBook ? (
                <div>
                  <div className="flex items-baseline gap-2 mb-1">
                    <span className="text-2xl font-black text-amber-300 tracking-tight">
                      {timeRemaining?.formatted}
                    </span>
                    <span className="text-xs text-neutral-400">left to finish book</span>
                  </div>
                  <p className="text-xs text-neutral-300 font-medium truncate">
                    {currentBook.title}
                  </p>
                  <p className="text-[11px] text-neutral-500 truncate">
                    Currently at Chapter {(currentBook.currentChapterIndex || 0) + 1} of {currentBook.totalChapters} ({currentBook.currentProgressPercent || 0}% read)
                  </p>
                </div>
              ) : (
                <div className="py-2 text-xs text-neutral-500">
                  Pick a novel from your library to view estimated reading completion time.
                </div>
              )}
            </div>

            {currentBook && (
              <button
                onClick={() => onContinueReading(currentBook)}
                className="mt-3 w-full py-2 px-3 rounded-lg bg-amber-500 hover:bg-amber-400 text-neutral-950 text-xs font-bold flex items-center justify-center gap-2 transition active:scale-95 shadow-md shadow-amber-500/20"
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Resume Current Book</span>
              </button>
            )}
          </div>

          {/* Right Column: Weekly Activity Progress Bar Chart */}
          <div className="flex flex-col justify-between p-3.5 sm:p-4 rounded-xl bg-neutral-950/60 border border-neutral-800/60">
            <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
              <span className="font-semibold flex items-center gap-1.5 text-neutral-300">
                <BarChart2 className="w-3.5 h-3.5 text-sky-400" />
                Weekly Reading Activity
              </span>
              <span className="text-[11px] font-medium text-sky-400">
                {totalWeeklyMinutes} mins this week
              </span>
            </div>

            {/* Daily Bars */}
            <div className="grid grid-cols-7 gap-1.5 items-end h-20 pt-2 pb-1">
              {weeklyData.map((d, idx) => {
                const heightPercent = Math.max(8, Math.round((d.minutes / maxWeeklyMinutes) * 100));

                return (
                  <div key={idx} className="flex flex-col items-center gap-1.5 h-full justify-end group">
                    <div className="relative w-full flex justify-center">
                      <div className="absolute -top-7 opacity-0 group-hover:opacity-100 transition-opacity bg-neutral-900 text-neutral-200 border border-neutral-700 text-[10px] px-1.5 py-0.5 rounded shadow pointer-events-none whitespace-nowrap z-20">
                        {d.minutes} min
                      </div>

                      <div
                        className={`w-full max-w-[20px] rounded-t-md transition-all duration-300 ${
                          d.isToday
                            ? 'bg-gradient-to-t from-sky-500 to-sky-300 shadow-sm shadow-sky-500/40'
                            : d.minutes > 0
                            ? 'bg-neutral-700 hover:bg-neutral-600'
                            : 'bg-neutral-800/40'
                        }`}
                        style={{ height: `${heightPercent}%` }}
                      />
                    </div>

                    <span
                      className={`text-[10px] font-mono ${
                        d.isToday ? 'text-sky-400 font-bold' : 'text-neutral-500'
                      }`}
                    >
                      {d.dayName}
                    </span>
                  </div>
                );
              })}
            </div>

            <div className="mt-2 text-[10px] text-neutral-500 text-center">
              Daily goal: 30 minutes • Read daily to keep your cultivation streak alive!
            </div>
          </div>
        </div>
      )}

      {/* Badges & Titles Milestone Modal */}
      {showBadgesModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/75 backdrop-blur-sm"
            onClick={() => setShowBadgesModal(false)}
          />
          <div className="relative z-10 w-full max-w-xl bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-2xl max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
              <div className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-sm text-neutral-100">
                  Reader Titles & Milestone Badges
                </h3>
              </div>
              <button
                onClick={() => setShowBadgesModal(false)}
                className="p-1 rounded-lg text-neutral-400 hover:text-neutral-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-neutral-400 mt-2 mb-4">
              Earn distinguished reader titles and badges by advancing your total reading hours and completing chapters!
            </p>

            <div className="flex-1 overflow-y-auto space-y-3 pr-1">
              {allBadges.map((badge) => (
                <div
                  key={badge.id}
                  className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 transition ${
                    badge.isUnlocked
                      ? 'bg-neutral-950/80 border-amber-500/40 shadow-sm'
                      : 'bg-neutral-950/40 border-neutral-800/60 opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0 ${
                        badge.isUnlocked
                          ? 'bg-gradient-to-tr ' + badge.tierColor + ' text-neutral-950 shadow-md'
                          : 'bg-neutral-800 text-neutral-500'
                      }`}
                    >
                      {badge.icon}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-xs text-neutral-100">{badge.title}</h4>
                        {badge.isUnlocked && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center gap-1 font-semibold">
                            <CheckCircle2 className="w-3 h-3" /> Unlocked
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-neutral-400 mt-0.5">{badge.requirementText}</p>
                    </div>
                  </div>

                  <div className="text-right flex-shrink-0">
                    <span className="text-xs font-mono font-bold text-neutral-300">
                      {badge.currentValue} / {badge.targetValue}
                    </span>
                    <div className="w-20 bg-neutral-800 rounded-full h-1.5 overflow-hidden mt-1">
                      <div
                        className={`h-full ${
                          badge.isUnlocked ? 'bg-amber-400' : 'bg-neutral-600'
                        }`}
                        style={{ width: `${badge.progressPercent}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
