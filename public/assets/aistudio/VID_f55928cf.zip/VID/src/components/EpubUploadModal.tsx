import React, { useState } from 'react';
import { FileUp, BookOpen, X, CheckCircle, AlertCircle, RefreshCw } from 'lucide-react';
import { Novel, ChapterContent } from '../types/novel';
import { parseEpubFile, ParsedEpub } from '../utils/epubParser';
import { saveNovel, saveEpubBlob, saveChapterContent } from '../utils/storage';

interface EpubUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNovelImported: (novel: Novel, chapterGetter: (idx: number) => Promise<ChapterContent>) => void;
}

export const EpubUploadModal: React.FC<EpubUploadModalProps> = ({
  isOpen,
  onClose,
  onNovelImported,
}) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);

  if (!isOpen) return null;

  const handleProcessFile = async (file: File) => {
    if (!file.name.toLowerCase().endsWith('.epub') && file.type !== 'application/epub+zip') {
      setError('Please select a valid .epub file format.');
      return;
    }

    setIsProcessing(true);
    setError(null);

    try {
      const parsed: ParsedEpub = await parseEpubFile(file, file.name);

      // Persist novel metadata and raw EPUB blob in IndexedDB
      await saveNovel(parsed.novel);
      await saveEpubBlob(parsed.novel.id, file);

      // Pre-cache chapter 1 so it opens instantaneously
      if (parsed.novel.chapters.length > 0) {
        const firstChapter = await parsed.getChapterContent(0);
        await saveChapterContent(firstChapter);
      }

      onNovelImported(parsed.novel, parsed.getChapterContent);
      onClose();
    } catch (err: any) {
      console.error('EPUB import failure:', err);
      setError(err.message || 'Failed to parse EPUB. The file may be corrupt or encrypted with DRM.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleProcessFile(e.dataTransfer.files[0]);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/75 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-2xl flex flex-col gap-4">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <FileUp className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-sm text-neutral-100">Import EPUB E-Book</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-neutral-400 hover:text-neutral-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drop Area */}
        <div
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          className={`border-2 border-dashed rounded-2xl p-8 text-center flex flex-col items-center justify-center gap-3 transition cursor-pointer ${
            dragActive
              ? 'border-amber-400 bg-amber-500/10'
              : 'border-neutral-700 bg-neutral-950/60 hover:border-neutral-600'
          }`}
          onClick={() => document.getElementById('epub-file-input')?.click()}
        >
          <div className="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center">
            {isProcessing ? (
              <RefreshCw className="w-6 h-6 animate-spin" />
            ) : (
              <BookOpen className="w-6 h-6" />
            )}
          </div>

          <div>
            <p className="text-xs font-semibold text-neutral-200">
              {isProcessing
                ? 'Unpacking and indexing EPUB...'
                : 'Click to select or drag and drop an EPUB file'}
            </p>
            <p className="text-[11px] text-neutral-500 mt-1">
              Supports standard EPUB 2 & EPUB 3 with embedded fonts and images
            </p>
          </div>

          <input
            id="epub-file-input"
            type="file"
            accept=".epub,application/epub+zip"
            onChange={(e) => e.target.files?.[0] && handleProcessFile(e.target.files[0])}
            className="hidden"
          />
        </div>

        {/* Error Callout */}
        {error && (
          <div className="p-3 bg-rose-950/40 border border-rose-800/60 rounded-xl text-xs text-rose-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </div>
    </div>
  );
};
