# Proguard rules for AetherNovel
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

-keep class app.aethernovel.AndroidNativeBridge { *; }

-dontwarn androidx.webkit.**
-keepattributes *Annotation*
-keepattributes JavascriptInterface
