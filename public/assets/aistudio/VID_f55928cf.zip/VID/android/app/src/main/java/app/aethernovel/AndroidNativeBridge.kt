package app.aethernovel

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.widget.Toast
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat

class AndroidNativeBridge(private val activity: Activity) {

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = activity.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        activity.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    var pendingEpubUri: String? = null
    var pendingEpubBase64: String? = null
    var pendingEpubFileName: String? = null

    @JavascriptInterface
    fun isNativeApp(): Boolean = true

    @JavascriptInterface
    fun getAppVersion(): String = "1.0.0"

    @JavascriptInterface
    fun triggerHaptic(type: String) {
        activity.runOnUiThread {
            if (vibrator?.hasVibrator() != true) return@runOnUiThread

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val effect = when (type.lowercase()) {
                    "light" -> VibrationEffect.createOneShot(12, 60)
                    "medium" -> VibrationEffect.createOneShot(24, 140)
                    "heavy" -> VibrationEffect.createOneShot(45, 255)
                    "success" -> VibrationEffect.createWaveform(longArrayOf(0, 15, 60, 25), intArrayOf(0, 100, 0, 180), -1)
                    else -> VibrationEffect.createOneShot(15, VibrationEffect.DEFAULT_AMPLITUDE)
                }
                vibrator.vibrate(effect)
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(18)
            }
        }
    }

    @JavascriptInterface
    fun setKeepScreenOn(keepOn: Boolean) {
        activity.runOnUiThread {
            if (keepOn) {
                activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            } else {
                activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }

    @JavascriptInterface
    fun setStatusBarTheme(darkIcons: Boolean, hexColor: String) {
        activity.runOnUiThread {
            try {
                val color = Color.parseColor(hexColor)
                activity.window.statusBarColor = color
                activity.window.navigationBarColor = color

                val insetsController = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
                insetsController.isAppearanceLightStatusBars = darkIcons
                insetsController.isAppearanceLightNavigationBars = darkIcons
            } catch (_: Exception) {
                // Ignore parse errors
            }
        }
    }

    @JavascriptInterface
    fun shareNovel(title: String, url: String) {
        activity.runOnUiThread {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, "Read \"$title\" on AetherNovel:\n$url")
            }
            activity.startActivity(Intent.createChooser(shareIntent, "Share Novel"))
        }
    }

    @JavascriptInterface
    fun showToast(message: String) {
        activity.runOnUiThread {
            Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
        }
    }

    @JavascriptInterface
    fun startAudioPlayback(title: String, chapter: String) {
        activity.runOnUiThread {
            try {
                val intent = Intent(activity, AudioService::class.java).apply {
                    action = AudioService.ACTION_PLAY
                    putExtra(AudioService.EXTRA_TITLE, title)
                    putExtra(AudioService.EXTRA_CHAPTER, chapter)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    activity.startForegroundService(intent)
                } else {
                    activity.startService(intent)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun stopAudioPlayback() {
        activity.runOnUiThread {
            try {
                val intent = Intent(activity, AudioService::class.java).apply {
                    action = AudioService.ACTION_STOP
                }
                activity.startService(intent)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun hasNativeAudioService(): Boolean = true

    @JavascriptInterface
    fun hasCloudflareResolver(): Boolean = true

    @JavascriptInterface
    fun openCloudflareResolver(url: String) {
        activity.runOnUiThread {
            try {
                val dialog = android.app.Dialog(activity, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
                val layout = android.widget.LinearLayout(activity).apply {
                    orientation = android.widget.LinearLayout.VERTICAL
                    setBackgroundColor(android.graphics.Color.parseColor("#090D16"))
                }

                val toolbar = android.widget.LinearLayout(activity).apply {
                    orientation = android.widget.LinearLayout.HORIZONTAL
                    setPadding(32, 48, 32, 24)
                    setBackgroundColor(android.graphics.Color.parseColor("#14161B"))
                }
                val titleView = android.widget.TextView(activity).apply {
                    text = "Cloudflare Captcha Solver"
                    setTextColor(android.graphics.Color.WHITE)
                    textSize = 16f
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                    layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f)
                }
                val closeButton = android.widget.Button(activity).apply {
                    text = "Done / Close"
                    setTextColor(android.graphics.Color.parseColor("#38BDF8"))
                    setBackgroundColor(android.graphics.Color.TRANSPARENT)
                    setOnClickListener {
                        val cookieManager = android.webkit.CookieManager.getInstance()
                        val cookies = cookieManager.getCookie(url) ?: ""
                        dialog.dismiss()
                        if (activity is MainActivity) {
                            activity.dispatchCloudflareSolved(url, cookies)
                        }
                    }
                }
                toolbar.addView(titleView)
                toolbar.addView(closeButton)
                layout.addView(toolbar)

                val subtitle = android.widget.TextView(activity).apply {
                    text = "Tap the Cloudflare checkbox below. Once passed, cookies will sync automatically."
                    setTextColor(android.graphics.Color.parseColor("#94A3B8"))
                    textSize = 12f
                    setPadding(32, 16, 32, 16)
                    setBackgroundColor(android.graphics.Color.parseColor("#1A1F2C"))
                }
                layout.addView(subtitle)

                val cfWebView = android.webkit.WebView(activity).apply {
                    layoutParams = android.widget.LinearLayout.LayoutParams(
                        android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                        android.widget.LinearLayout.LayoutParams.MATCH_PARENT
                    )
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.databaseEnabled = true
                    settings.userAgentString = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
                    webViewClient = object : android.webkit.WebViewClient() {
                        override fun onPageFinished(view: android.webkit.WebView?, pageUrl: String?) {
                            super.onPageFinished(view, pageUrl)
                            val cookieManager = android.webkit.CookieManager.getInstance()
                            val cookies = cookieManager.getCookie(pageUrl) ?: ""
                            if (cookies.contains("cf_clearance")) {
                                android.widget.Toast.makeText(activity, "Cloudflare Captcha Solved!", android.widget.Toast.LENGTH_SHORT).show()
                                dialog.dismiss()
                                if (activity is MainActivity) {
                                    activity.dispatchCloudflareSolved(url, cookies)
                                }
                            }
                        }
                    }
                }
                layout.addView(cfWebView)
                dialog.setContentView(layout)
                dialog.show()

                cfWebView.loadUrl(url)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    @JavascriptInterface
    fun getPendingEpub(): String {
        val json = """
            {
                "uri": "${pendingEpubUri ?: ""}",
                "fileName": "${pendingEpubFileName ?: ""}",
                "base64": "${pendingEpubBase64 ?: ""}"
            }
        """.trimIndent()
        return json
    }

    @JavascriptInterface
    fun clearPendingEpub() {
        pendingEpubUri = null
        pendingEpubBase64 = null
        pendingEpubFileName = null
    }
}
