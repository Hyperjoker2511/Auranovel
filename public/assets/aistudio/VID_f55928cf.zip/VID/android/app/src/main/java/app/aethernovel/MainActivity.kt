package app.aethernovel

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Base64
import android.view.View
import android.webkit.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.io.InputStream

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var nativeBridge: AndroidNativeBridge
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    // Activity Result Launcher for File Chooser (e.g. EPUB import)
    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            val results: Array<Uri>? = when {
                data?.data != null -> arrayOf(data.data!!)
                data?.clipData != null -> {
                    val count = data.clipData!!.itemCount
                    Array(count) { i -> data.clipData!!.getItemAt(i).uri }
                }
                else -> null
            }
            filePathCallback?.onReceiveValue(results)
        } else {
            filePathCallback?.onReceiveValue(null)
        }
        filePathCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Setup Edge-to-Edge display
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT

        // Root layout setup
        webView = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#090D16"))
        }
        setContentView(webView)

        // Setup native bridge
        nativeBridge = AndroidNativeBridge(this)

        setupWebView()
        handleIncomingIntent(intent)

        // Android System Back Button Intercept
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Check if web app wants to consume back button (e.g. close reader)
                webView.evaluateJavascript(
                    "window.__androidHandleBack ? window.__androidHandleBack() : false"
                ) { result ->
                    if (result == "true") {
                        // Handled by reader inside web app
                        return@evaluateJavascript
                    }
                    if (webView.canGoBack()) {
                        webView.goBack()
                    } else {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        // Apply system window insets padding
        ViewCompat.setOnApplyWindowInsetsListener(webView) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            // Pass system insets as CSS custom variables to WebView
            val script = """
                document.documentElement.style.setProperty('--android-top-inset', '${systemBars.top}px');
                document.documentElement.style.setProperty('--android-bottom-inset', '${systemBars.bottom}px');
            """.trimIndent()
            webView.evaluateJavascript(script, null)
            insets
        }

        // Determine starting URL (local assets or hosted URL with offline service worker)
        val defaultUrl = getString(R.string.default_web_url)
        webView.loadUrl(defaultUrl)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent != null) {
            handleIncomingIntent(intent)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.cacheMode = WebSettings.LOAD_DEFAULT

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.safeBrowsingEnabled = true
        }

        // Add Javascript Bridge
        webView.addJavascriptInterface(nativeBridge, "AndroidBridge")

        // Setup WebViewClient
        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // Notify web app that native bridge is attached and check for pending EPUB
                val script = """
                    window.__isAndroidNative = true;
                    if (window.__onAndroidBridgeReady) {
                        window.__onAndroidBridgeReady();
                    }
                """.trimIndent()
                webView.evaluateJavascript(script, null)

                dispatchPendingEpubIfAny()
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                // Fallback to offline local bundled assets if hosted site is unreachable
                if (request?.isForMainFrame == true) {
                    try {
                        view?.loadUrl("file:///android_asset/index.html")
                    } catch (_: Exception) {}
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                // Keep local app URLs in WebView, open external non-reader links in system browser
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    return false
                }
                return try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    startActivity(intent)
                    true
                } catch (_: Exception) {
                    false
                }
            }
        }

        // Setup WebChromeClient for File Uploads & Progress
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                filePath: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = filePath

                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/epub+zip", "application/octet-stream", "*/*"))
                }

                try {
                    filePickerLauncher.launch(intent)
                } catch (e: Exception) {
                    filePathCallback = null
                    return false
                }
                return true
            }
        }
    }

    private fun handleIncomingIntent(intent: Intent) {
        val action = intent.action
        val data = intent.data

        if (Intent.ACTION_VIEW == action && data != null) {
            readEpubFromUri(data)
        }
    }

    private fun readEpubFromUri(uri: Uri) {
        Thread {
            try {
                var fileName = "imported.epub"
                val cursor = contentResolver.query(uri, null, null, null, null)
                cursor?.use {
                    if (it.moveToFirst()) {
                        val nameIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIndex != -1) {
                            fileName = it.getString(nameIndex) ?: fileName
                        }
                    }
                }

                val inputStream: InputStream? = contentResolver.openInputStream(uri)
                val bytes = inputStream?.readBytes()
                inputStream?.close()

                if (bytes != null && bytes.isNotEmpty()) {
                    val base64Data = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    nativeBridge.pendingEpubUri = uri.toString()
                    nativeBridge.pendingEpubFileName = fileName
                    nativeBridge.pendingEpubBase64 = base64Data

                    runOnUiThread {
                        dispatchPendingEpubIfAny()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }

    private fun dispatchPendingEpubIfAny() {
        if (nativeBridge.pendingEpubBase64 != null) {
            val fileName = nativeBridge.pendingEpubFileName ?: "imported.epub"
            val script = """
                if (window.__handleAndroidEpubImport) {
                    window.__handleAndroidEpubImport('$fileName');
                }
            """.trimIndent()
            webView.evaluateJavascript(script, null)
        }
    }

    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (event.action == android.view.KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                android.view.KeyEvent.KEYCODE_VOLUME_DOWN -> {
                    webView.evaluateJavascript(
                        "window.__handleAndroidVolumeKey ? window.__handleAndroidVolumeKey('down') : false"
                    ) { handled ->
                        if (handled != "true") {
                            super.dispatchKeyEvent(event)
                        }
                    }
                    return true
                }
                android.view.KeyEvent.KEYCODE_VOLUME_UP -> {
                    webView.evaluateJavascript(
                        "window.__handleAndroidVolumeKey ? window.__handleAndroidVolumeKey('up') : false"
                    ) { handled ->
                        if (handled != "true") {
                            super.dispatchKeyEvent(event)
                        }
                    }
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    fun dispatchCloudflareSolved(url: String, cookies: String) {
        val safeCookies = cookies.replace("'", "\\'")
        val script = "if(window.__onCloudflareSolved){ window.__onCloudflareSolved('$url', '$safeCookies'); }"
        webView.evaluateJavascript(script, null)
    }

    override fun onDestroy() {
        super.onDestroy()
        webView.destroy()
    }
}
