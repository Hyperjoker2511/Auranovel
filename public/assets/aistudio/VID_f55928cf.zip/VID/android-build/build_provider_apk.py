#!/usr/bin/env python3
"""
AetherNovel Provider Extension APK Builder
Generates a standalone, installable Android Provider APK for any novel website.
"""

import sys
import os
import re
import json
import shutil
import subprocess

def sanitize_slug(name):
    slug = re.sub(r'[^a-zA-Z0-9]', '_', name.lower()).strip('_')
    return slug or "custom_provider"

def main():
    if len(sys.argv) < 3:
        print("Usage: build_provider_apk.py <SiteName> <SiteUrl> [Selector] [IconEmoji]")
        sys.exit(1)

    site_name = sys.argv[1].strip()
    site_url = sys.argv[2].strip()
    selector = sys.argv[3].strip() if len(sys.argv) > 3 and sys.argv[3].strip() else ".chapter-content"
    icon = sys.argv[4].strip() if len(sys.argv) > 4 and sys.argv[4].strip() else "📖"

    slug = sanitize_slug(site_name)
    package_name = f"app.aethernovel.provider.{slug}"

    script_dir = os.path.dirname(os.path.abspath(__file__))
    workspace_dir = os.path.abspath(os.path.join(script_dir, ".."))
    
    # Locate Android SDK
    sdk_path = os.environ.get("ANDROID_HOME") or os.environ.get("ANDROID_SDK_ROOT")
    if not sdk_path:
        local_appdata = os.environ.get("LOCALAPPDATA", "")
        candidate = os.path.join(local_appdata, "Android", "Sdk")
        if os.path.exists(candidate):
            sdk_path = candidate

    if not sdk_path or not os.path.exists(sdk_path):
        print(json.dumps({"error": f"Android SDK not found at {sdk_path}"}))
        sys.exit(1)

    # Locate build tools (highest version)
    build_tools_root = os.path.join(sdk_path, "build-tools")
    build_tools_dirs = sorted([d for d in os.listdir(build_tools_root) if os.path.isdir(os.path.join(build_tools_root, d))], reverse=True)
    if not build_tools_dirs:
        print(json.dumps({"error": "No build-tools found"}))
        sys.exit(1)
    build_tools = os.path.join(build_tools_root, build_tools_dirs[0])

    # Locate platform android.jar
    platforms_root = os.path.join(sdk_path, "platforms")
    platform_dirs = sorted([d for d in os.listdir(platforms_root) if os.path.isdir(os.path.join(platforms_root, d))], reverse=True)
    if not platform_dirs:
        print(json.dumps({"error": "No platforms found"}))
        sys.exit(1)
    android_jar = os.path.join(platforms_root, platform_dirs[0], "android.jar")

    aapt = os.path.join(build_tools, "aapt.exe" if os.name == "nt" else "aapt")
    d8 = os.path.join(build_tools, "d8.bat" if os.name == "nt" else "d8")
    zipalign = os.path.join(build_tools, "zipalign.exe" if os.name == "nt" else "zipalign")
    apksigner = os.path.join(build_tools, "apksigner.bat" if os.name == "nt" else "apksigner")

    # Temp build dir
    temp_build_dir = os.path.join(script_dir, f"temp_provider_{slug}")
    if os.path.exists(temp_build_dir):
        shutil.rmtree(temp_build_dir, ignore_errors=True)

    os.makedirs(os.path.join(temp_build_dir, "gen", "app", "aethernovel"), exist_ok=True)
    os.makedirs(os.path.join(temp_build_dir, "bin"), exist_ok=True)

    # Copy res and assets
    shutil.copytree(os.path.join(script_dir, "res"), os.path.join(temp_build_dir, "res"))
    shutil.copytree(os.path.join(script_dir, "assets"), os.path.join(temp_build_dir, "assets"))

    # Write provider definition JSON into assets
    provider_meta = {
        "id": f"provider_{slug}",
        "name": f"{site_name} Provider",
        "siteUrl": site_url,
        "contentSelector": selector,
        "icon": icon,
        "version": "1.0.0",
        "packageName": package_name,
        "isExtensionApk": True,
        "generatedAt": os.path.getmtime(android_jar)
    }
    with open(os.path.join(temp_build_dir, "assets", "provider.json"), "w", encoding="utf-8") as fp:
        json.dump(provider_meta, fp, indent=2)

    # Customize AndroidManifest.xml
    manifest_template = os.path.join(script_dir, "AndroidManifest.xml")
    with open(manifest_template, "r", encoding="utf-8") as fp:
        manifest_content = fp.read()

    manifest_content = manifest_content.replace('package="app.aethernovel"', f'package="{package_name}"')

    # Update strings.xml for app name
    strings_path = os.path.join(temp_build_dir, "res", "values", "strings.xml")
    with open(strings_path, "w", encoding="utf-8") as fp:
        fp.write(f'''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">{site_name} Provider</string>
</resources>''')

    manifest_path = os.path.join(temp_build_dir, "AndroidManifest.xml")
    with open(manifest_path, "w", encoding="utf-8") as fp:
        fp.write(manifest_content)

    # Copy Java sources
    src_dir = os.path.join(temp_build_dir, "src", "app", "aethernovel")
    os.makedirs(src_dir, exist_ok=True)
    shutil.copy(os.path.join(script_dir, "src", "app", "aethernovel", "AndroidBridge.java"), src_dir)
    shutil.copy(os.path.join(script_dir, "src", "app", "aethernovel", "MainActivity.java"), src_dir)

    try:
        # 1. AAPT package
        cmd_aapt_gen = [
            aapt, "package", "-f", "-m",
            "--custom-package", "app.aethernovel",
            "-J", os.path.join(temp_build_dir, "gen"),
            "-M", manifest_path,
            "-S", os.path.join(temp_build_dir, "res"),
            "-I", android_jar
        ]
        res = subprocess.run(cmd_aapt_gen, capture_output=True, text=True)
        if res.returncode != 0:
            raise RuntimeError(f"AAPT R.java generation failed: {res.stderr}")

        # 2. Compile Java with javac
        java_files = []
        for root, _, files in os.walk(os.path.join(temp_build_dir, "gen")):
            for f in files:
                if f.endswith(".java"):
                    java_files.append(os.path.join(root, f))
        for root, _, files in os.walk(src_dir):
            for f in files:
                if f.endswith(".java"):
                    java_files.append(os.path.join(root, f))
        cmd_javac = [
            "javac", "-source", "8", "-target", "8",
            "-bootclasspath", android_jar,
            "-d", os.path.join(temp_build_dir, "bin"),
            "-classpath", android_jar
        ] + java_files
        res = subprocess.run(cmd_javac, capture_output=True, text=True)
        if res.returncode != 0:
            raise RuntimeError(f"javac compilation failed: {res.stderr}")

        # 3. D8 bytecode convert
        class_files = []
        for root, _, files in os.walk(os.path.join(temp_build_dir, "bin")):
            for f in files:
                if f.endswith(".class"):
                    class_files.append(os.path.join(root, f))

        cmd_d8 = [
            d8, "--output", os.path.join(temp_build_dir, "bin"),
            "--lib", android_jar
        ] + class_files
        res = subprocess.run(cmd_d8, capture_output=True, text=True)
        if res.returncode != 0:
            raise RuntimeError(f"D8 dex failed: {res.stderr}")

        # 4. Package unaligned APK
        unaligned_apk = os.path.join(temp_build_dir, "bin", "app-unaligned.apk")
        cmd_aapt_pack = [
            aapt, "package", "-f",
            "-M", manifest_path,
            "-S", os.path.join(temp_build_dir, "res"),
            "-A", os.path.join(temp_build_dir, "assets"),
            "-I", android_jar,
            "-F", unaligned_apk
        ]
        res = subprocess.run(cmd_aapt_pack, capture_output=True, text=True)
        if res.returncode != 0:
            raise RuntimeError(f"AAPT unaligned packaging failed: {res.stderr}")

        # Add classes.dex
        prev_cwd = os.getcwd()
        os.chdir(os.path.join(temp_build_dir, "bin"))
        subprocess.run([aapt, "add", "app-unaligned.apk", "classes.dex"], capture_output=True)
        os.chdir(prev_cwd)

        # 5. Zipalign
        aligned_apk = os.path.join(temp_build_dir, "bin", "app-aligned.apk")
        res = subprocess.run([zipalign, "-f", "-p", "4", unaligned_apk, aligned_apk], capture_output=True, text=True)
        if res.returncode != 0:
            raise RuntimeError(f"zipalign failed: {res.stderr}")

        # 6. Sign APK
        keystore = os.path.join(script_dir, "release.keystore")
        if not os.path.exists(keystore):
            cmd_keytool = [
                "keytool", "-genkeypair", "-v",
                "-keystore", keystore,
                "-alias", "aethernovel",
                "-keyalg", "RSA", "-keysize", "2048",
                "-validity", "10000",
                "-storepass", "aethernovel123",
                "-keypass", "aethernovel123",
                "-dname", "CN=AetherNovel, OU=Mobile, O=AetherNovel, L=San Francisco, ST=CA, C=US"
            ]
            subprocess.run(cmd_keytool, capture_output=True)

        public_providers_dir = os.path.join(workspace_dir, "public", "providers")
        os.makedirs(public_providers_dir, exist_ok=True)
        output_apk = os.path.join(public_providers_dir, f"{slug}-provider.apk")

        cmd_sign = [
            apksigner, "sign",
            "--ks", keystore,
            "--ks-pass", "pass:aethernovel123",
            "--key-pass", "pass:aethernovel123",
            "--out", output_apk,
            aligned_apk
        ]
        res = subprocess.run(cmd_sign, capture_output=True, text=True)
        if res.returncode != 0:
            raise RuntimeError(f"apksigner failed: {res.stderr}")

        apk_size_kb = round(os.path.getsize(output_apk) / 1024, 2)
        print(json.dumps({
            "success": True,
            "siteName": site_name,
            "siteUrl": site_url,
            "slug": slug,
            "packageName": package_name,
            "apkFileName": f"{slug}-provider.apk",
            "apkUrl": f"/providers/{slug}-provider.apk",
            "sizeKb": apk_size_kb
        }))

    finally:
        # Cleanup temp directory
        try:
            shutil.rmtree(temp_build_dir, ignore_errors=True)
        except Exception:
            pass

if __name__ == "__main__":
    main()
