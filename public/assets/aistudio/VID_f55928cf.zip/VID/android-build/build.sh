#!/bin/bash
set -e

WORKSPACE_DIR="$(pwd)"
BUILD_DIR="$WORKSPACE_DIR/android-build"
ANDROID_JAR="/usr/lib/android-sdk/platforms/android-23/android.jar"

echo "[1/6] Building production web assets..."
npm run build
rm -rf "$BUILD_DIR/assets"
mkdir -p "$BUILD_DIR/assets"
cp -r "$WORKSPACE_DIR/dist"/* "$BUILD_DIR/assets/"

echo "[2/6] Generating R.java with aapt..."
cd "$BUILD_DIR"
rm -rf gen bin
mkdir -p gen/app/aethernovel bin

aapt package -f -m \
  -J gen \
  -M AndroidManifest.xml \
  -S res \
  -I "$ANDROID_JAR"

echo "[3/6] Compiling Java sources with javac..."
javac -source 1.8 -target 1.8 \
  -bootclasspath "$ANDROID_JAR" \
  -d bin \
  -classpath "$ANDROID_JAR" \
  gen/app/aethernovel/R.java \
  src/app/aethernovel/AndroidBridge.java \
  src/app/aethernovel/MainActivity.java

echo "[4/6] Creating Dalvik dex bytecode with dalvik-exchange..."
dalvik-exchange --dex --output=bin/classes.dex bin

echo "[5/6] Packaging unaligned APK with aapt..."
aapt package -f \
  -M AndroidManifest.xml \
  -S res \
  -A assets \
  -I "$ANDROID_JAR" \
  -F bin/app-unaligned.apk

# Add classes.dex to the root of the apk
cd bin
aapt add app-unaligned.apk classes.dex
cd "$BUILD_DIR"

echo "[6/6] Aligning & Signing APK with apksigner..."
mkdir -p "$WORKSPACE_DIR/public"
OUTPUT_APK="$WORKSPACE_DIR/public/aethernovel.apk"

zipalign -f -p 4 bin/app-unaligned.apk bin/app-aligned.apk

# Generate keystore if not exists
KEYSTORE="$BUILD_DIR/release.keystore"
if [ ! -f "$KEYSTORE" ]; then
  keytool -genkeypair -v \
    -keystore "$KEYSTORE" \
    -alias aethernovel \
    -keyalg RSA \
    -keysize 2048 \
    -validity 10000 \
    -storepass aethernovel123 \
    -keypass aethernovel123 \
    -dname "CN=AetherNovel, OU=Mobile, O=AetherNovel, L=San Francisco, ST=CA, C=US"
fi

apksigner sign \
  --ks "$KEYSTORE" \
  --ks-pass pass:aethernovel123 \
  --key-pass pass:aethernovel123 \
  --out "$OUTPUT_APK" \
  bin/app-aligned.apk

apksigner verify "$OUTPUT_APK"

echo "========================================="
echo "SUCCESS: APK built and signed successfully!"
ls -lh "$OUTPUT_APK"
echo "========================================="
