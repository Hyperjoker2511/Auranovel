@echo off
setlocal
echo Starting AetherNovel Android APK Build...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1"
if %ERRORLEVEL% neq 0 (
    echo.
    echo [ERROR] Build failed with exit code %ERRORLEVEL%
    pause
    exit /b %ERRORLEVEL%
)
echo.
echo [DONE] Android APK built successfully.
pause
