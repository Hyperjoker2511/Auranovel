/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "402b66900e731ca748771b6fc5e7a068"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "7971895c04e246545e255e5f0979c592"
  }, {
    "url": "pwa-512x512.png",
    "revision": "7971895c04e246545e255e5f0979c592"
  }, {
    "url": "pwa-192x192.png",
    "revision": "7a30f7a03f6a8d6e6e831daf8e451f80"
  }, {
    "url": "privacy.html",
    "revision": "c983e82e77e2a00764a07dce33497e77"
  }, {
    "url": "index.html",
    "revision": "3a8fc47082ce6082b79ae0ffb7090a9a"
  }, {
    "url": "icon.svg",
    "revision": "bc58fb74d40b981d374da1c3d0a8bc9d"
  }, {
    "url": "favicon.ico",
    "revision": "7a30f7a03f6a8d6e6e831daf8e451f80"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "7a30f7a03f6a8d6e6e831daf8e451f80"
  }, {
    "url": "assets/index-aUMwPbFm.js",
    "revision": null
  }, {
    "url": "assets/index-DMZSQKuz.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "7a30f7a03f6a8d6e6e831daf8e451f80"
  }, {
    "url": "favicon.ico",
    "revision": "7a30f7a03f6a8d6e6e831daf8e451f80"
  }, {
    "url": "icon.svg",
    "revision": "bc58fb74d40b981d374da1c3d0a8bc9d"
  }, {
    "url": "pwa-192x192.png",
    "revision": "7a30f7a03f6a8d6e6e831daf8e451f80"
  }, {
    "url": "pwa-512x512.png",
    "revision": "7971895c04e246545e255e5f0979c592"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "7971895c04e246545e255e5f0979c592"
  }, {
    "url": "manifest.webmanifest",
    "revision": "b33af2d53ea397091c54bcdfd0152c13"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
