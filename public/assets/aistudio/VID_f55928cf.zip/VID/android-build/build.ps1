param(
    [string]$SdkPath = ""
)

$ErrorActionPreference = "Stop"

$WorkspaceDir = (Get-Item -Path "$PSScriptRoot\..").FullName
$BuildDir = "$WorkspaceDir\android-build"

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  AetherNovel Native Android Build Tool   " -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan

# 1. Resolve Android SDK
if (-not $SdkPath) {
    if ($env:ANDROID_HOME -and (Test-Path $env:ANDROID_HOME)) {
        $SdkPath = $env:ANDROID_HOME
    } elseif ($env:ANDROID_SDK_ROOT -and (Test-Path $env:ANDROID_SDK_ROOT)) {
        $SdkPath = $env:ANDROID_SDK_ROOT
    } elseif (Test-Path "$env:LOCALAPPDATA\Android\Sdk") {
        $SdkPath = "$env:LOCALAPPDATA\Android\Sdk"
    } else {
        Write-Error "Android SDK not found! Please specify -SdkPath or set ANDROID_HOME."
        exit 1
    }
}

Write-Host "Using Android SDK: $SdkPath" -ForegroundColor Green

# Locate Build Tools
$buildToolsDir = Get-ChildItem -Path "$SdkPath\build-tools" -Directory | Sort-Object Name -Descending | Select-Object -First 1
if (-not $buildToolsDir) {
    Write-Error "No build-tools found in $SdkPath\build-tools"
    exit 1
}
$BuildTools = $buildToolsDir.FullName
Write-Host "Using Build-Tools: $BuildTools" -ForegroundColor Green

# Locate Platform SDK (android.jar)
$platformDir = Get-ChildItem -Path "$SdkPath\platforms" -Directory | Sort-Object Name -Descending | Select-Object -First 1
if (-not $platformDir) {
    Write-Error "No platforms found in $SdkPath\platforms"
    exit 1
}
$AndroidJar = "$($platformDir.FullName)\android.jar"
if (-not (Test-Path $AndroidJar)) {
    Write-Error "android.jar not found at $AndroidJar"
    exit 1
}
Write-Host "Using Platform: $($platformDir.Name) ($AndroidJar)" -ForegroundColor Green

# Locate Tools
$Aapt = "$BuildTools\aapt.exe"
$D8 = "$BuildTools\d8.bat"
$Zipalign = "$BuildTools\zipalign.exe"
$Apksigner = "$BuildTools\apksigner.bat"

# Verify tool existence
foreach ($tool in @($Aapt, $D8, $Zipalign, $Apksigner)) {
    if (-not (Test-Path $tool)) {
        Write-Error "Required tool missing: $tool"
        exit 1
    }
}

Set-Location -Path $BuildDir

# 2. Clean & Prepare output directories
Write-Host "`n[1/6] Cleaning build outputs..." -ForegroundColor Yellow
if (Test-Path "gen") { Remove-Item -Path "gen" -Recurse -Force }
if (Test-Path "bin") { Remove-Item -Path "bin" -Recurse -Force }
New-Item -ItemType Directory -Path "gen\app\aethernovel" -Force | Out-Null
New-Item -ItemType Directory -Path "bin" -Force | Out-Null

# 3. Generate R.java with AAPT
Write-Host "[2/6] Generating R.java with AAPT..." -ForegroundColor Yellow
& "$Aapt" package -f -m -J gen -M AndroidManifest.xml -S res -I "$AndroidJar"
if ($LASTEXITCODE -ne 0) {
    Write-Error "AAPT package failed during R.java generation."
    exit $LASTEXITCODE
}

# 4. Compile Java sources with javac
Write-Host "[3/6] Compiling Java sources with javac..." -ForegroundColor Yellow
$javaSources = @(
    "gen\app\aethernovel\R.java",
    "src\app\aethernovel\AndroidBridge.java",
    "src\app\aethernovel\MainActivity.java"
)
& javac -source 8 -target 8 -bootclasspath "$AndroidJar" -d bin -classpath "$AndroidJar" $javaSources
if ($LASTEXITCODE -ne 0) {
    Write-Error "javac compilation failed."
    exit $LASTEXITCODE
}

# 5. Convert class files to Dalvik DEX using D8
Write-Host "[4/6] Converting bytecode to Dalvik DEX with D8..." -ForegroundColor Yellow
$classFiles = Get-ChildItem -Path "bin" -Filter "*.class" -Recurse | Select-Object -ExpandProperty FullName
& "$D8" --output bin --lib "$AndroidJar" $classFiles
if ($LASTEXITCODE -ne 0) {
    Write-Error "D8 failed to generate classes.dex."
    exit $LASTEXITCODE
}

# 6. Package unaligned APK with AAPT
Write-Host "[5/6] Packaging unaligned APK..." -ForegroundColor Yellow
& "$Aapt" package -f -M AndroidManifest.xml -S res -A assets -I "$AndroidJar" -F bin\app-unaligned.apk
if ($LASTEXITCODE -ne 0) {
    Write-Error "AAPT packaging failed."
    exit $LASTEXITCODE
}

# Add classes.dex to APK root
Push-Location bin
& "$Aapt" add app-unaligned.apk classes.dex
Pop-Location

# 7. Align APK with zipalign
Write-Host "[6/6] Aligning & Signing APK..." -ForegroundColor Yellow
& "$Zipalign" -f -p 4 bin\app-unaligned.apk bin\app-aligned.apk
if ($LASTEXITCODE -ne 0) {
    Write-Error "zipalign failed."
    exit $LASTEXITCODE
}

# Keystore check / generation
$Keystore = "$BuildDir\release.keystore"
if (-not (Test-Path $Keystore)) {
    Write-Host "Creating release keystore..." -ForegroundColor Cyan
    & keytool -genkeypair -v `
        -keystore "$Keystore" `
        -alias aethernovel `
        -keyalg RSA `
        -keysize 2048 `
        -validity 10000 `
        -storepass aethernovel123 `
        -keypass aethernovel123 `
        -dname "CN=AetherNovel, OU=Mobile, O=AetherNovel, L=San Francisco, ST=CA, C=US"
}

# Output locations
$PublicDir = "$WorkspaceDir\public"
if (-not (Test-Path $PublicDir)) { New-Item -ItemType Directory -Path $PublicDir -Force | Out-Null }
$OutputApk = "$PublicDir\aethernovel.apk"

# Sign APK with apksigner
& "$Apksigner" sign `
    --ks "$Keystore" `
    --ks-pass pass:aethernovel123 `
    --key-pass pass:aethernovel123 `
    --out "$OutputApk" `
    bin\app-aligned.apk
if ($LASTEXITCODE -ne 0) {
    Write-Error "apksigner failed."
    exit $LASTEXITCODE
}

# Verify Signature
Write-Host "`nVerifying APK cryptographic signature:" -ForegroundColor Cyan
& "$Apksigner" verify --verbose "$OutputApk"

$apkInfo = Get-Item $OutputApk
Write-Host "`n========================================================" -ForegroundColor Green
Write-Host "  SUCCESS! Signed Android APK Built Successfully!       " -ForegroundColor Green
Write-Host "  Location: $OutputApk" -ForegroundColor Green
Write-Host "  Size: $([math]::Round($apkInfo.Length / 1KB, 2)) KB" -ForegroundColor Green
Write-Host "========================================================`n" -ForegroundColor Green
