package app.aethernovel;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Vibrator;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

public class AndroidBridge {

    private final Activity activity;
    private final Vibrator vibrator;
    public String pendingEpubBase64 = null;
    public String pendingEpubFileName = null;
    public String pendingEpubUri = null;

    public AndroidBridge(Activity activity) {
        this.activity = activity;
        this.vibrator = (Vibrator) activity.getSystemService(Context.VIBRATOR_SERVICE);
    }

    @JavascriptInterface
    public boolean isNativeApp() {
        return true;
    }

    @JavascriptInterface
    public String getAppVersion() {
        return "1.0.0";
    }

    @JavascriptInterface
    public void triggerHaptic(final String type) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (vibrator == null || !vibrator.hasVibrator()) return;
                try {
                    String t = (type != null) ? type.toLowerCase() : "light";
                    if ("heavy".equals(t)) {
                        vibrator.vibrate(45);
                    } else if ("medium".equals(t)) {
                        vibrator.vibrate(24);
                    } else if ("success".equals(t)) {
                        vibrator.vibrate(new long[]{0, 15, 60, 25}, -1);
                    } else {
                        vibrator.vibrate(15);
                    }
                } catch (Exception ignored) {}
            }
        });
    }

    @JavascriptInterface
    public void setKeepScreenOn(final boolean keepOn) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Window window = activity.getWindow();
                    if (keepOn) {
                        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    } else {
                        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    }
                } catch (Exception ignored) {}
            }
        });
    }

    @JavascriptInterface
    public void setStatusBarTheme(final boolean darkIcons, final String hexColor) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        Window window = activity.getWindow();
                        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                        window.setStatusBarColor(Color.parseColor(hexColor));
                        window.setNavigationBarColor(Color.parseColor(hexColor));
                    }
                } catch (Exception ignored) {}
            }
        });
    }

    @JavascriptInterface
    public void shareNovel(final String title, final String url) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("text/plain");
                    intent.putExtra(Intent.EXTRA_SUBJECT, title);
                    intent.putExtra(Intent.EXTRA_TEXT, "Read \"" + title + "\" on AetherNovel:\n" + url);
                    activity.startActivity(Intent.createChooser(intent, "Share Novel"));
                } catch (Exception ignored) {}
            }
        });
    }

    @JavascriptInterface
    public void showToast(final String message) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(activity, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @JavascriptInterface
    public void startAudioPlayback(final String title, final String chapter) {
        // Native audio service trigger
    }

    @JavascriptInterface
    public void stopAudioPlayback() {
        // Native audio service stop
    }

    @JavascriptInterface
    public boolean hasNativeAudioService() {
        return false;
    }

    @JavascriptInterface
    public boolean hasCloudflareResolver() {
        return false;
    }

    @JavascriptInterface
    public void openCloudflareResolver(final String url) {
        // Cloudflare solver hook
    }

    @JavascriptInterface
    public String getPendingEpub() {
        String base64 = (pendingEpubBase64 != null) ? pendingEpubBase64 : "";
        String fileName = (pendingEpubFileName != null) ? pendingEpubFileName : "";
        String uri = (pendingEpubUri != null) ? pendingEpubUri : "";
        return "{\"uri\":\"" + uri + "\",\"fileName\":\"" + fileName + "\",\"base64\":\"" + base64 + "\"}";
    }

    @JavascriptInterface
    public void clearPendingEpub() {
        pendingEpubBase64 = null;
        pendingEpubFileName = null;
        pendingEpubUri = null;
    }
}
